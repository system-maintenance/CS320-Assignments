
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	2b813103          	ld	sp,696(sp) # 8000a2b8 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	03e000ef          	jal	80000054 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000022:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000026:	577d                	li	a4,-1
    80000028:	177e                	slli	a4,a4,0x3f
    8000002a:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002c:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000030:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000034:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    80000038:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003c:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000040:	000f4737          	lui	a4,0xf4
    80000044:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000048:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004a:	14d79073          	csrw	stimecmp,a5
}
    8000004e:	6422                	ld	s0,8(sp)
    80000050:	0141                	addi	sp,sp,16
    80000052:	8082                	ret

0000000080000054 <start>:
{
    80000054:	1141                	addi	sp,sp,-16
    80000056:	e406                	sd	ra,8(sp)
    80000058:	e022                	sd	s0,0(sp)
    8000005a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    8000005c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000060:	7779                	lui	a4,0xffffe
    80000062:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdaddf>
    80000066:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000068:	6705                	lui	a4,0x1
    8000006a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000006e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000070:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000074:	00001797          	auipc	a5,0x1
    80000078:	d7a78793          	addi	a5,a5,-646 # 80000dee <main>
    8000007c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000080:	4781                	li	a5,0
    80000082:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    80000086:	67c1                	lui	a5,0x10
    80000088:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    8000008e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000092:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    80000096:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009a:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    8000009e:	57fd                	li	a5,-1
    800000a0:	83a9                	srli	a5,a5,0xa
    800000a2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000a6:	47bd                	li	a5,15
    800000a8:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000ac:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b0:	4705                	li	a4,1
    800000b2:	1776                	slli	a4,a4,0x3d
    800000b4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000b6:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000ba:	f63ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000be:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c2:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c6:	30200073          	mret
}
    800000ca:	60a2                	ld	ra,8(sp)
    800000cc:	6402                	ld	s0,0(sp)
    800000ce:	0141                	addi	sp,sp,16
    800000d0:	8082                	ret

00000000800000d2 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d2:	7119                	addi	sp,sp,-128
    800000d4:	fc86                	sd	ra,120(sp)
    800000d6:	f8a2                	sd	s0,112(sp)
    800000d8:	f4a6                	sd	s1,104(sp)
    800000da:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000dc:	06c05a63          	blez	a2,80000150 <consolewrite+0x7e>
    800000e0:	f0ca                	sd	s2,96(sp)
    800000e2:	ecce                	sd	s3,88(sp)
    800000e4:	e8d2                	sd	s4,80(sp)
    800000e6:	e4d6                	sd	s5,72(sp)
    800000e8:	e0da                	sd	s6,64(sp)
    800000ea:	fc5e                	sd	s7,56(sp)
    800000ec:	f862                	sd	s8,48(sp)
    800000ee:	f466                	sd	s9,40(sp)
    800000f0:	8aaa                	mv	s5,a0
    800000f2:	8b2e                	mv	s6,a1
    800000f4:	8a32                	mv	s4,a2
  int i = 0;
    800000f6:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000f8:	02000c13          	li	s8,32
    800000fc:	02000c93          	li	s9,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000100:	5bfd                	li	s7,-1
    80000102:	a035                	j	8000012e <consolewrite+0x5c>
    if (nn > n - i)
    80000104:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000108:	86ce                	mv	a3,s3
    8000010a:	01648633          	add	a2,s1,s6
    8000010e:	85d6                	mv	a1,s5
    80000110:	f8040513          	addi	a0,s0,-128
    80000114:	1c0020ef          	jal	800022d4 <either_copyin>
    80000118:	03750e63          	beq	a0,s7,80000154 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011c:	85ce                	mv	a1,s3
    8000011e:	f8040513          	addi	a0,s0,-128
    80000122:	786000ef          	jal	800008a8 <uartwrite>
    i += nn;
    80000126:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    8000012a:	0144da63          	bge	s1,s4,8000013e <consolewrite+0x6c>
    if (nn > n - i)
    8000012e:	409a093b          	subw	s2,s4,s1
    80000132:	0009079b          	sext.w	a5,s2
    80000136:	fcfc57e3          	bge	s8,a5,80000104 <consolewrite+0x32>
    8000013a:	8966                	mv	s2,s9
    8000013c:	b7e1                	j	80000104 <consolewrite+0x32>
    8000013e:	7906                	ld	s2,96(sp)
    80000140:	69e6                	ld	s3,88(sp)
    80000142:	6a46                	ld	s4,80(sp)
    80000144:	6aa6                	ld	s5,72(sp)
    80000146:	6b06                	ld	s6,64(sp)
    80000148:	7be2                	ld	s7,56(sp)
    8000014a:	7c42                	ld	s8,48(sp)
    8000014c:	7ca2                	ld	s9,40(sp)
    8000014e:	a819                	j	80000164 <consolewrite+0x92>
  int i = 0;
    80000150:	4481                	li	s1,0
    80000152:	a809                	j	80000164 <consolewrite+0x92>
    80000154:	7906                	ld	s2,96(sp)
    80000156:	69e6                	ld	s3,88(sp)
    80000158:	6a46                	ld	s4,80(sp)
    8000015a:	6aa6                	ld	s5,72(sp)
    8000015c:	6b06                	ld	s6,64(sp)
    8000015e:	7be2                	ld	s7,56(sp)
    80000160:	7c42                	ld	s8,48(sp)
    80000162:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000164:	8526                	mv	a0,s1
    80000166:	70e6                	ld	ra,120(sp)
    80000168:	7446                	ld	s0,112(sp)
    8000016a:	74a6                	ld	s1,104(sp)
    8000016c:	6109                	addi	sp,sp,128
    8000016e:	8082                	ret

0000000080000170 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000170:	711d                	addi	sp,sp,-96
    80000172:	ec86                	sd	ra,88(sp)
    80000174:	e8a2                	sd	s0,80(sp)
    80000176:	e4a6                	sd	s1,72(sp)
    80000178:	e0ca                	sd	s2,64(sp)
    8000017a:	fc4e                	sd	s3,56(sp)
    8000017c:	f852                	sd	s4,48(sp)
    8000017e:	f456                	sd	s5,40(sp)
    80000180:	f05a                	sd	s6,32(sp)
    80000182:	1080                	addi	s0,sp,96
    80000184:	8aaa                	mv	s5,a0
    80000186:	8a2e                	mv	s4,a1
    80000188:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000018a:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018e:	00012517          	auipc	a0,0x12
    80000192:	17250513          	addi	a0,a0,370 # 80012300 <cons>
    80000196:	1fb000ef          	jal	80000b90 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    8000019a:	00012497          	auipc	s1,0x12
    8000019e:	16648493          	addi	s1,s1,358 # 80012300 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a2:	00012917          	auipc	s2,0x12
    800001a6:	1f690913          	addi	s2,s2,502 # 80012398 <cons+0x98>
  while (n > 0) {
    800001aa:	0d305463          	blez	s3,80000272 <consoleread+0x102>
    while (cons.r == cons.w) {
    800001ae:	0984a783          	lw	a5,152(s1)
    800001b2:	09c4a703          	lw	a4,156(s1)
    800001b6:	0af71963          	bne	a4,a5,80000268 <consoleread+0xf8>
      if (killed(myproc())) {
    800001ba:	6e8010ef          	jal	800018a2 <myproc>
    800001be:	791010ef          	jal	8000214e <killed>
    800001c2:	e925                	bnez	a0,80000232 <consoleread+0xc2>
      sleep_prepare(&cons.r);
    800001c4:	854a                	mv	a0,s2
    800001c6:	52f010ef          	jal	80001ef4 <sleep_prepare>
      release(&cons.lock);
    800001ca:	8526                	mv	a0,s1
    800001cc:	251000ef          	jal	80000c1c <release>
      sleep();
    800001d0:	561010ef          	jal	80001f30 <sleep>
      acquire(&cons.lock);
    800001d4:	8526                	mv	a0,s1
    800001d6:	1bb000ef          	jal	80000b90 <acquire>
    while (cons.r == cons.w) {
    800001da:	0984a783          	lw	a5,152(s1)
    800001de:	09c4a703          	lw	a4,156(s1)
    800001e2:	fcf70ce3          	beq	a4,a5,800001ba <consoleread+0x4a>
    800001e6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e8:	00012717          	auipc	a4,0x12
    800001ec:	11870713          	addi	a4,a4,280 # 80012300 <cons>
    800001f0:	0017869b          	addiw	a3,a5,1
    800001f4:	08d72c23          	sw	a3,152(a4)
    800001f8:	07f7f693          	andi	a3,a5,127
    800001fc:	9736                	add	a4,a4,a3
    800001fe:	01874703          	lbu	a4,24(a4)
    80000202:	00070b9b          	sext.w	s7,a4

    if (c == C('D')) { // end-of-file
    80000206:	4691                	li	a3,4
    80000208:	04db8663          	beq	s7,a3,80000254 <consoleread+0xe4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020c:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000210:	4685                	li	a3,1
    80000212:	faf40613          	addi	a2,s0,-81
    80000216:	85d2                	mv	a1,s4
    80000218:	8556                	mv	a0,s5
    8000021a:	06e020ef          	jal	80002288 <either_copyout>
    8000021e:	57fd                	li	a5,-1
    80000220:	04f50863          	beq	a0,a5,80000270 <consoleread+0x100>
      break;

    dst++;
    80000224:	0a05                	addi	s4,s4,1
    --n;
    80000226:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    80000228:	47a9                	li	a5,10
    8000022a:	04fb8d63          	beq	s7,a5,80000284 <consoleread+0x114>
    8000022e:	6be2                	ld	s7,24(sp)
    80000230:	bfad                	j	800001aa <consoleread+0x3a>
        release(&cons.lock);
    80000232:	00012517          	auipc	a0,0x12
    80000236:	0ce50513          	addi	a0,a0,206 # 80012300 <cons>
    8000023a:	1e3000ef          	jal	80000c1c <release>
        return -1;
    8000023e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000240:	60e6                	ld	ra,88(sp)
    80000242:	6446                	ld	s0,80(sp)
    80000244:	64a6                	ld	s1,72(sp)
    80000246:	6906                	ld	s2,64(sp)
    80000248:	79e2                	ld	s3,56(sp)
    8000024a:	7a42                	ld	s4,48(sp)
    8000024c:	7aa2                	ld	s5,40(sp)
    8000024e:	7b02                	ld	s6,32(sp)
    80000250:	6125                	addi	sp,sp,96
    80000252:	8082                	ret
      if (n < target) {
    80000254:	0009871b          	sext.w	a4,s3
    80000258:	01677a63          	bgeu	a4,s6,8000026c <consoleread+0xfc>
        cons.r--;
    8000025c:	00012717          	auipc	a4,0x12
    80000260:	12f72e23          	sw	a5,316(a4) # 80012398 <cons+0x98>
    80000264:	6be2                	ld	s7,24(sp)
    80000266:	a031                	j	80000272 <consoleread+0x102>
    80000268:	ec5e                	sd	s7,24(sp)
    8000026a:	bfbd                	j	800001e8 <consoleread+0x78>
    8000026c:	6be2                	ld	s7,24(sp)
    8000026e:	a011                	j	80000272 <consoleread+0x102>
    80000270:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000272:	00012517          	auipc	a0,0x12
    80000276:	08e50513          	addi	a0,a0,142 # 80012300 <cons>
    8000027a:	1a3000ef          	jal	80000c1c <release>
  return target - n;
    8000027e:	413b053b          	subw	a0,s6,s3
    80000282:	bf7d                	j	80000240 <consoleread+0xd0>
    80000284:	6be2                	ld	s7,24(sp)
    80000286:	b7f5                	j	80000272 <consoleread+0x102>

0000000080000288 <consputc>:
{
    80000288:	1141                	addi	sp,sp,-16
    8000028a:	e406                	sd	ra,8(sp)
    8000028c:	e022                	sd	s0,0(sp)
    8000028e:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000290:	10000793          	li	a5,256
    80000294:	00f50863          	beq	a0,a5,800002a4 <consputc+0x1c>
    uartputc_sync(c);
    80000298:	696000ef          	jal	8000092e <uartputc_sync>
}
    8000029c:	60a2                	ld	ra,8(sp)
    8000029e:	6402                	ld	s0,0(sp)
    800002a0:	0141                	addi	sp,sp,16
    800002a2:	8082                	ret
    uartputc_sync('\b');
    800002a4:	4521                	li	a0,8
    800002a6:	688000ef          	jal	8000092e <uartputc_sync>
    uartputc_sync(' ');
    800002aa:	02000513          	li	a0,32
    800002ae:	680000ef          	jal	8000092e <uartputc_sync>
    uartputc_sync('\b');
    800002b2:	4521                	li	a0,8
    800002b4:	67a000ef          	jal	8000092e <uartputc_sync>
    800002b8:	b7d5                	j	8000029c <consputc+0x14>

00000000800002ba <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ba:	1101                	addi	sp,sp,-32
    800002bc:	ec06                	sd	ra,24(sp)
    800002be:	e822                	sd	s0,16(sp)
    800002c0:	e426                	sd	s1,8(sp)
    800002c2:	1000                	addi	s0,sp,32
    800002c4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c6:	00012517          	auipc	a0,0x12
    800002ca:	03a50513          	addi	a0,a0,58 # 80012300 <cons>
    800002ce:	0c3000ef          	jal	80000b90 <acquire>

  switch (c) {
    800002d2:	47d5                	li	a5,21
    800002d4:	08f48f63          	beq	s1,a5,80000372 <consoleintr+0xb8>
    800002d8:	0297c563          	blt	a5,s1,80000302 <consoleintr+0x48>
    800002dc:	47a1                	li	a5,8
    800002de:	0ef48463          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    800002e2:	47c1                	li	a5,16
    800002e4:	10f49563          	bne	s1,a5,800003ee <consoleintr+0x134>
  case C('P'): // Print process list.
    procdump();
    800002e8:	038020ef          	jal	80002320 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ec:	00012517          	auipc	a0,0x12
    800002f0:	01450513          	addi	a0,a0,20 # 80012300 <cons>
    800002f4:	129000ef          	jal	80000c1c <release>
}
    800002f8:	60e2                	ld	ra,24(sp)
    800002fa:	6442                	ld	s0,16(sp)
    800002fc:	64a2                	ld	s1,8(sp)
    800002fe:	6105                	addi	sp,sp,32
    80000300:	8082                	ret
  switch (c) {
    80000302:	07f00793          	li	a5,127
    80000306:	0cf48063          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030a:	00012717          	auipc	a4,0x12
    8000030e:	ff670713          	addi	a4,a4,-10 # 80012300 <cons>
    80000312:	0a072783          	lw	a5,160(a4)
    80000316:	09872703          	lw	a4,152(a4)
    8000031a:	9f99                	subw	a5,a5,a4
    8000031c:	07f00713          	li	a4,127
    80000320:	fcf766e3          	bltu	a4,a5,800002ec <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000324:	47b5                	li	a5,13
    80000326:	0cf48763          	beq	s1,a5,800003f4 <consoleintr+0x13a>
      consputc(c);
    8000032a:	8526                	mv	a0,s1
    8000032c:	f5dff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000330:	00012797          	auipc	a5,0x12
    80000334:	fd078793          	addi	a5,a5,-48 # 80012300 <cons>
    80000338:	0a07a683          	lw	a3,160(a5)
    8000033c:	0016871b          	addiw	a4,a3,1
    80000340:	0007061b          	sext.w	a2,a4
    80000344:	0ae7a023          	sw	a4,160(a5)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	97b6                	add	a5,a5,a3
    8000034e:	00978c23          	sb	s1,24(a5)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	47a9                	li	a5,10
    80000354:	0cf48563          	beq	s1,a5,8000041e <consoleintr+0x164>
    80000358:	4791                	li	a5,4
    8000035a:	0cf48263          	beq	s1,a5,8000041e <consoleintr+0x164>
    8000035e:	00012797          	auipc	a5,0x12
    80000362:	03a7a783          	lw	a5,58(a5) # 80012398 <cons+0x98>
    80000366:	9f1d                	subw	a4,a4,a5
    80000368:	08000793          	li	a5,128
    8000036c:	f8f710e3          	bne	a4,a5,800002ec <consoleintr+0x32>
    80000370:	a07d                	j	8000041e <consoleintr+0x164>
    80000372:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000374:	00012717          	auipc	a4,0x12
    80000378:	f8c70713          	addi	a4,a4,-116 # 80012300 <cons>
    8000037c:	0a072783          	lw	a5,160(a4)
    80000380:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000384:	00012497          	auipc	s1,0x12
    80000388:	f7c48493          	addi	s1,s1,-132 # 80012300 <cons>
    while (cons.e != cons.w &&
    8000038c:	4929                	li	s2,10
    8000038e:	02f70863          	beq	a4,a5,800003be <consoleintr+0x104>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000392:	37fd                	addiw	a5,a5,-1
    80000394:	07f7f713          	andi	a4,a5,127
    80000398:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    8000039a:	01874703          	lbu	a4,24(a4)
    8000039e:	03270263          	beq	a4,s2,800003c2 <consoleintr+0x108>
      cons.e--;
    800003a2:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a6:	10000513          	li	a0,256
    800003aa:	edfff0ef          	jal	80000288 <consputc>
    while (cons.e != cons.w &&
    800003ae:	0a04a783          	lw	a5,160(s1)
    800003b2:	09c4a703          	lw	a4,156(s1)
    800003b6:	fcf71ee3          	bne	a4,a5,80000392 <consoleintr+0xd8>
    800003ba:	6902                	ld	s2,0(sp)
    800003bc:	bf05                	j	800002ec <consoleintr+0x32>
    800003be:	6902                	ld	s2,0(sp)
    800003c0:	b735                	j	800002ec <consoleintr+0x32>
    800003c2:	6902                	ld	s2,0(sp)
    800003c4:	b725                	j	800002ec <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c6:	00012717          	auipc	a4,0x12
    800003ca:	f3a70713          	addi	a4,a4,-198 # 80012300 <cons>
    800003ce:	0a072783          	lw	a5,160(a4)
    800003d2:	09c72703          	lw	a4,156(a4)
    800003d6:	f0f70be3          	beq	a4,a5,800002ec <consoleintr+0x32>
      cons.e--;
    800003da:	37fd                	addiw	a5,a5,-1
    800003dc:	00012717          	auipc	a4,0x12
    800003e0:	fcf72223          	sw	a5,-60(a4) # 800123a0 <cons+0xa0>
      consputc(BACKSPACE);
    800003e4:	10000513          	li	a0,256
    800003e8:	ea1ff0ef          	jal	80000288 <consputc>
    800003ec:	b701                	j	800002ec <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ee:	ee048fe3          	beqz	s1,800002ec <consoleintr+0x32>
    800003f2:	bf21                	j	8000030a <consoleintr+0x50>
      consputc(c);
    800003f4:	4529                	li	a0,10
    800003f6:	e93ff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003fa:	00012797          	auipc	a5,0x12
    800003fe:	f0678793          	addi	a5,a5,-250 # 80012300 <cons>
    80000402:	0a07a703          	lw	a4,160(a5)
    80000406:	0017069b          	addiw	a3,a4,1
    8000040a:	0006861b          	sext.w	a2,a3
    8000040e:	0ad7a023          	sw	a3,160(a5)
    80000412:	07f77713          	andi	a4,a4,127
    80000416:	97ba                	add	a5,a5,a4
    80000418:	4729                	li	a4,10
    8000041a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041e:	00012797          	auipc	a5,0x12
    80000422:	f6c7af23          	sw	a2,-130(a5) # 8001239c <cons+0x9c>
        wakeup(&cons.r);
    80000426:	00012517          	auipc	a0,0x12
    8000042a:	f7250513          	addi	a0,a0,-142 # 80012398 <cons+0x98>
    8000042e:	333010ef          	jal	80001f60 <wakeup>
    80000432:	bd6d                	j	800002ec <consoleintr+0x32>

0000000080000434 <consoleinit>:

void
consoleinit(void)
{
    80000434:	1141                	addi	sp,sp,-16
    80000436:	e406                	sd	ra,8(sp)
    80000438:	e022                	sd	s0,0(sp)
    8000043a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000043c:	00007597          	auipc	a1,0x7
    80000440:	bc458593          	addi	a1,a1,-1084 # 80007000 <etext>
    80000444:	00012517          	auipc	a0,0x12
    80000448:	ebc50513          	addi	a0,a0,-324 # 80012300 <cons>
    8000044c:	6ce000ef          	jal	80000b1a <initlock>

  uartinit();
    80000450:	400000ef          	jal	80000850 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000454:	00022797          	auipc	a5,0x22
    80000458:	43478793          	addi	a5,a5,1076 # 80022888 <devsw>
    8000045c:	00000717          	auipc	a4,0x0
    80000460:	d1470713          	addi	a4,a4,-748 # 80000170 <consoleread>
    80000464:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000466:	00000717          	auipc	a4,0x0
    8000046a:	c6c70713          	addi	a4,a4,-916 # 800000d2 <consolewrite>
    8000046e:	ef98                	sd	a4,24(a5)
}
    80000470:	60a2                	ld	ra,8(sp)
    80000472:	6402                	ld	s0,0(sp)
    80000474:	0141                	addi	sp,sp,16
    80000476:	8082                	ret

0000000080000478 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000478:	7139                	addi	sp,sp,-64
    8000047a:	fc06                	sd	ra,56(sp)
    8000047c:	f822                	sd	s0,48(sp)
    8000047e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000480:	c219                	beqz	a2,80000486 <printint+0xe>
    80000482:	08054063          	bltz	a0,80000502 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000486:	4881                	li	a7,0
    80000488:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000048c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00007617          	auipc	a2,0x7
    80000492:	2a260613          	addi	a2,a2,674 # 80007730 <digits>
    80000496:	883e                	mv	a6,a5
    80000498:	2785                	addiw	a5,a5,1
    8000049a:	02b57733          	remu	a4,a0,a1
    8000049e:	9732                	add	a4,a4,a2
    800004a0:	00074703          	lbu	a4,0(a4)
    800004a4:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    800004a8:	872a                	mv	a4,a0
    800004aa:	02b55533          	divu	a0,a0,a1
    800004ae:	0685                	addi	a3,a3,1
    800004b0:	feb773e3          	bgeu	a4,a1,80000496 <printint+0x1e>

  if (sign)
    800004b4:	00088a63          	beqz	a7,800004c8 <printint+0x50>
    buf[i++] = '-';
    800004b8:	1781                	addi	a5,a5,-32
    800004ba:	97a2                	add	a5,a5,s0
    800004bc:	02d00713          	li	a4,45
    800004c0:	fee78423          	sb	a4,-24(a5)
    800004c4:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    800004c8:	02f05963          	blez	a5,800004fa <printint+0x82>
    800004cc:	f426                	sd	s1,40(sp)
    800004ce:	f04a                	sd	s2,32(sp)
    800004d0:	fc840713          	addi	a4,s0,-56
    800004d4:	00f704b3          	add	s1,a4,a5
    800004d8:	fff70913          	addi	s2,a4,-1
    800004dc:	993e                	add	s2,s2,a5
    800004de:	37fd                	addiw	a5,a5,-1
    800004e0:	1782                	slli	a5,a5,0x20
    800004e2:	9381                	srli	a5,a5,0x20
    800004e4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004e8:	fff4c503          	lbu	a0,-1(s1)
    800004ec:	d9dff0ef          	jal	80000288 <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x70>
    800004f6:	74a2                	ld	s1,40(sp)
    800004f8:	7902                	ld	s2,32(sp)
}
    800004fa:	70e2                	ld	ra,56(sp)
    800004fc:	7442                	ld	s0,48(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4885                	li	a7,1
    x = -xx;
    80000508:	b741                	j	80000488 <printint+0x10>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	e8d2                	sd	s4,80(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	8a2a                	mv	s4,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000a797          	auipc	a5,0xa
    8000052c:	dac7a783          	lw	a5,-596(a5) # 8000a2d4 <panicking>
    80000530:	c3a1                	beqz	a5,80000570 <printk+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	000a4503          	lbu	a0,0(s4)
    8000053e:	28050763          	beqz	a0,800007cc <printk+0x2c2>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	f0ca                	sd	s2,96(sp)
    80000546:	ecce                	sd	s3,88(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	f862                	sd	s8,48(sp)
    8000054e:	f466                	sd	s9,40(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4981                	li	s3,0
    if (cx != '%') {
    80000556:	02500a93          	li	s5,37
    c1 = c2 = 0;
    if (c0)
      c1 = fmt[i + 1] & 0xff;
    if (c1)
      c2 = fmt[i + 2] & 0xff;
    if (c0 == 'd') {
    8000055a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if (c0 == 'l' && c1 == 'd') {
    8000055e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000562:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000566:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    8000056a:	07000d93          	li	s11,112
    8000056e:	a01d                	j	80000594 <printk+0x8a>
    acquire(&pr.lock);
    80000570:	00012517          	auipc	a0,0x12
    80000574:	e3850513          	addi	a0,a0,-456 # 800123a8 <pr>
    80000578:	618000ef          	jal	80000b90 <acquire>
    8000057c:	bf5d                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057e:	d0bff0ef          	jal	80000288 <consputc>
      continue;
    80000582:	84ce                	mv	s1,s3
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000584:	0014899b          	addiw	s3,s1,1
    80000588:	013a07b3          	add	a5,s4,s3
    8000058c:	0007c503          	lbu	a0,0(a5)
    80000590:	20050b63          	beqz	a0,800007a6 <printk+0x29c>
    if (cx != '%') {
    80000594:	ff5515e3          	bne	a0,s5,8000057e <printk+0x74>
    i++;
    80000598:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i + 0] & 0xff;
    8000059c:	009a07b3          	add	a5,s4,s1
    800005a0:	0007c903          	lbu	s2,0(a5)
    if (c0)
    800005a4:	20090b63          	beqz	s2,800007ba <printk+0x2b0>
      c1 = fmt[i + 1] & 0xff;
    800005a8:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    800005ac:	86be                	mv	a3,a5
    if (c1)
    800005ae:	c789                	beqz	a5,800005b8 <printk+0xae>
      c2 = fmt[i + 2] & 0xff;
    800005b0:	009a0733          	add	a4,s4,s1
    800005b4:	00274683          	lbu	a3,2(a4)
    if (c0 == 'd') {
    800005b8:	03690963          	beq	s2,s6,800005ea <printk+0xe0>
    } else if (c0 == 'l' && c1 == 'd') {
    800005bc:	05890363          	beq	s2,s8,80000602 <printk+0xf8>
    } else if (c0 == 'u') {
    800005c0:	0d990663          	beq	s2,s9,8000068c <printk+0x182>
    } else if (c0 == 'x') {
    800005c4:	11a90d63          	beq	s2,s10,800006de <printk+0x1d4>
    } else if (c0 == 'p') {
    800005c8:	15b90663          	beq	s2,s11,80000714 <printk+0x20a>
      printptr(va_arg(ap, uint64));
    } else if (c0 == 'c') {
    800005cc:	06300793          	li	a5,99
    800005d0:	18f90563          	beq	s2,a5,8000075a <printk+0x250>
      consputc(va_arg(ap, uint));
    } else if (c0 == 's') {
    800005d4:	07300793          	li	a5,115
    800005d8:	18f90b63          	beq	s2,a5,8000076e <printk+0x264>
      if ((s = va_arg(ap, char *)) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
    } else if (c0 == '%') {
    800005dc:	03591b63          	bne	s2,s5,80000612 <printk+0x108>
      consputc('%');
    800005e0:	02500513          	li	a0,37
    800005e4:	ca5ff0ef          	jal	80000288 <consputc>
    800005e8:	bf71                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005ea:	f8843783          	ld	a5,-120(s0)
    800005ee:	00878713          	addi	a4,a5,8
    800005f2:	f8e43423          	sd	a4,-120(s0)
    800005f6:	4605                	li	a2,1
    800005f8:	45a9                	li	a1,10
    800005fa:	4388                	lw	a0,0(a5)
    800005fc:	e7dff0ef          	jal	80000478 <printint>
    80000600:	b751                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'd') {
    80000602:	01678f63          	beq	a5,s6,80000620 <printk+0x116>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    80000606:	03878b63          	beq	a5,s8,8000063c <printk+0x132>
    } else if (c0 == 'l' && c1 == 'u') {
    8000060a:	09978e63          	beq	a5,s9,800006a6 <printk+0x19c>
    } else if (c0 == 'l' && c1 == 'x') {
    8000060e:	0fa78563          	beq	a5,s10,800006f8 <printk+0x1ee>
    } else if (c0 == 0) {
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000612:	8556                	mv	a0,s5
    80000614:	c75ff0ef          	jal	80000288 <consputc>
      consputc(c0);
    80000618:	854a                	mv	a0,s2
    8000061a:	c6fff0ef          	jal	80000288 <consputc>
    8000061e:	b79d                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000620:	f8843783          	ld	a5,-120(s0)
    80000624:	00878713          	addi	a4,a5,8
    80000628:	f8e43423          	sd	a4,-120(s0)
    8000062c:	4605                	li	a2,1
    8000062e:	45a9                	li	a1,10
    80000630:	6388                	ld	a0,0(a5)
    80000632:	e47ff0ef          	jal	80000478 <printint>
      i += 1;
    80000636:	0029849b          	addiw	s1,s3,2
    8000063a:	b7a9                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000063c:	06400793          	li	a5,100
    80000640:	02f68863          	beq	a3,a5,80000670 <printk+0x166>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    80000644:	07500793          	li	a5,117
    80000648:	06f68d63          	beq	a3,a5,800006c2 <printk+0x1b8>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000064c:	07800793          	li	a5,120
    80000650:	fcf691e3          	bne	a3,a5,80000612 <printk+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000654:	f8843783          	ld	a5,-120(s0)
    80000658:	00878713          	addi	a4,a5,8
    8000065c:	f8e43423          	sd	a4,-120(s0)
    80000660:	4601                	li	a2,0
    80000662:	45c1                	li	a1,16
    80000664:	6388                	ld	a0,0(a5)
    80000666:	e13ff0ef          	jal	80000478 <printint>
      i += 2;
    8000066a:	0039849b          	addiw	s1,s3,3
    8000066e:	bf19                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	4605                	li	a2,1
    8000067e:	45a9                	li	a1,10
    80000680:	6388                	ld	a0,0(a5)
    80000682:	df7ff0ef          	jal	80000478 <printint>
      i += 2;
    80000686:	0039849b          	addiw	s1,s3,3
    8000068a:	bded                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000068c:	f8843783          	ld	a5,-120(s0)
    80000690:	00878713          	addi	a4,a5,8
    80000694:	f8e43423          	sd	a4,-120(s0)
    80000698:	4601                	li	a2,0
    8000069a:	45a9                	li	a1,10
    8000069c:	0007e503          	lwu	a0,0(a5)
    800006a0:	dd9ff0ef          	jal	80000478 <printint>
    800006a4:	b5c5                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006a6:	f8843783          	ld	a5,-120(s0)
    800006aa:	00878713          	addi	a4,a5,8
    800006ae:	f8e43423          	sd	a4,-120(s0)
    800006b2:	4601                	li	a2,0
    800006b4:	45a9                	li	a1,10
    800006b6:	6388                	ld	a0,0(a5)
    800006b8:	dc1ff0ef          	jal	80000478 <printint>
      i += 1;
    800006bc:	0029849b          	addiw	s1,s3,2
    800006c0:	b5d1                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006c2:	f8843783          	ld	a5,-120(s0)
    800006c6:	00878713          	addi	a4,a5,8
    800006ca:	f8e43423          	sd	a4,-120(s0)
    800006ce:	4601                	li	a2,0
    800006d0:	45a9                	li	a1,10
    800006d2:	6388                	ld	a0,0(a5)
    800006d4:	da5ff0ef          	jal	80000478 <printint>
      i += 2;
    800006d8:	0039849b          	addiw	s1,s3,3
    800006dc:	b565                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006de:	f8843783          	ld	a5,-120(s0)
    800006e2:	00878713          	addi	a4,a5,8
    800006e6:	f8e43423          	sd	a4,-120(s0)
    800006ea:	4601                	li	a2,0
    800006ec:	45c1                	li	a1,16
    800006ee:	0007e503          	lwu	a0,0(a5)
    800006f2:	d87ff0ef          	jal	80000478 <printint>
    800006f6:	b579                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006f8:	f8843783          	ld	a5,-120(s0)
    800006fc:	00878713          	addi	a4,a5,8
    80000700:	f8e43423          	sd	a4,-120(s0)
    80000704:	4601                	li	a2,0
    80000706:	45c1                	li	a1,16
    80000708:	6388                	ld	a0,0(a5)
    8000070a:	d6fff0ef          	jal	80000478 <printint>
      i += 1;
    8000070e:	0029849b          	addiw	s1,s3,2
    80000712:	bd8d                	j	80000584 <printk+0x7a>
    80000714:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000716:	f8843783          	ld	a5,-120(s0)
    8000071a:	00878713          	addi	a4,a5,8
    8000071e:	f8e43423          	sd	a4,-120(s0)
    80000722:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000726:	03000513          	li	a0,48
    8000072a:	b5fff0ef          	jal	80000288 <consputc>
  consputc('x');
    8000072e:	07800513          	li	a0,120
    80000732:	b57ff0ef          	jal	80000288 <consputc>
    80000736:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000738:	00007b97          	auipc	s7,0x7
    8000073c:	ff8b8b93          	addi	s7,s7,-8 # 80007730 <digits>
    80000740:	03c9d793          	srli	a5,s3,0x3c
    80000744:	97de                	add	a5,a5,s7
    80000746:	0007c503          	lbu	a0,0(a5)
    8000074a:	b3fff0ef          	jal	80000288 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000074e:	0992                	slli	s3,s3,0x4
    80000750:	397d                	addiw	s2,s2,-1
    80000752:	fe0917e3          	bnez	s2,80000740 <printk+0x236>
    80000756:	7be2                	ld	s7,56(sp)
    80000758:	b535                	j	80000584 <printk+0x7a>
      consputc(va_arg(ap, uint));
    8000075a:	f8843783          	ld	a5,-120(s0)
    8000075e:	00878713          	addi	a4,a5,8
    80000762:	f8e43423          	sd	a4,-120(s0)
    80000766:	4388                	lw	a0,0(a5)
    80000768:	b21ff0ef          	jal	80000288 <consputc>
    8000076c:	bd21                	j	80000584 <printk+0x7a>
      if ((s = va_arg(ap, char *)) == 0)
    8000076e:	f8843783          	ld	a5,-120(s0)
    80000772:	00878713          	addi	a4,a5,8
    80000776:	f8e43423          	sd	a4,-120(s0)
    8000077a:	0007b903          	ld	s2,0(a5)
    8000077e:	00090d63          	beqz	s2,80000798 <printk+0x28e>
      for (; *s; s++)
    80000782:	00094503          	lbu	a0,0(s2)
    80000786:	de050fe3          	beqz	a0,80000584 <printk+0x7a>
        consputc(*s);
    8000078a:	affff0ef          	jal	80000288 <consputc>
      for (; *s; s++)
    8000078e:	0905                	addi	s2,s2,1
    80000790:	00094503          	lbu	a0,0(s2)
    80000794:	f97d                	bnez	a0,8000078a <printk+0x280>
    80000796:	b3fd                	j	80000584 <printk+0x7a>
        s = "(null)";
    80000798:	00007917          	auipc	s2,0x7
    8000079c:	87090913          	addi	s2,s2,-1936 # 80007008 <etext+0x8>
      for (; *s; s++)
    800007a0:	02800513          	li	a0,40
    800007a4:	b7dd                	j	8000078a <printk+0x280>
    800007a6:	74a6                	ld	s1,104(sp)
    800007a8:	7906                	ld	s2,96(sp)
    800007aa:	69e6                	ld	s3,88(sp)
    800007ac:	6aa6                	ld	s5,72(sp)
    800007ae:	6b06                	ld	s6,64(sp)
    800007b0:	7c42                	ld	s8,48(sp)
    800007b2:	7ca2                	ld	s9,40(sp)
    800007b4:	7d02                	ld	s10,32(sp)
    800007b6:	6de2                	ld	s11,24(sp)
    800007b8:	a811                	j	800007cc <printk+0x2c2>
    800007ba:	74a6                	ld	s1,104(sp)
    800007bc:	7906                	ld	s2,96(sp)
    800007be:	69e6                	ld	s3,88(sp)
    800007c0:	6aa6                	ld	s5,72(sp)
    800007c2:	6b06                	ld	s6,64(sp)
    800007c4:	7c42                	ld	s8,48(sp)
    800007c6:	7ca2                	ld	s9,40(sp)
    800007c8:	7d02                	ld	s10,32(sp)
    800007ca:	6de2                	ld	s11,24(sp)
    }
  }
  va_end(ap);

  if (panicking == 0)
    800007cc:	0000a797          	auipc	a5,0xa
    800007d0:	b087a783          	lw	a5,-1272(a5) # 8000a2d4 <panicking>
    800007d4:	c799                	beqz	a5,800007e2 <printk+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007d6:	4501                	li	a0,0
    800007d8:	70e6                	ld	ra,120(sp)
    800007da:	7446                	ld	s0,112(sp)
    800007dc:	6a46                	ld	s4,80(sp)
    800007de:	6129                	addi	sp,sp,192
    800007e0:	8082                	ret
    release(&pr.lock);
    800007e2:	00012517          	auipc	a0,0x12
    800007e6:	bc650513          	addi	a0,a0,-1082 # 800123a8 <pr>
    800007ea:	432000ef          	jal	80000c1c <release>
  return 0;
    800007ee:	b7e5                	j	800007d6 <printk+0x2cc>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	e04a                	sd	s2,0(sp)
    800007fa:	1000                	addi	s0,sp,32
    800007fc:	84aa                	mv	s1,a0
  panicking = 1;
    800007fe:	4905                	li	s2,1
    80000800:	0000a797          	auipc	a5,0xa
    80000804:	ad27aa23          	sw	s2,-1324(a5) # 8000a2d4 <panicking>
  printk("panic: ");
    80000808:	00007517          	auipc	a0,0x7
    8000080c:	81050513          	addi	a0,a0,-2032 # 80007018 <etext+0x18>
    80000810:	cfbff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000814:	85a6                	mv	a1,s1
    80000816:	00007517          	auipc	a0,0x7
    8000081a:	80a50513          	addi	a0,a0,-2038 # 80007020 <etext+0x20>
    8000081e:	cedff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000822:	0000a797          	auipc	a5,0xa
    80000826:	ab27a723          	sw	s2,-1362(a5) # 8000a2d0 <panicked>
  for (;;)
    8000082a:	a001                	j	8000082a <panic+0x3a>

000000008000082c <printkinit>:
    ;
}

void
printkinit(void)
{
    8000082c:	1141                	addi	sp,sp,-16
    8000082e:	e406                	sd	ra,8(sp)
    80000830:	e022                	sd	s0,0(sp)
    80000832:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000834:	00006597          	auipc	a1,0x6
    80000838:	7f458593          	addi	a1,a1,2036 # 80007028 <etext+0x28>
    8000083c:	00012517          	auipc	a0,0x12
    80000840:	b6c50513          	addi	a0,a0,-1172 # 800123a8 <pr>
    80000844:	2d6000ef          	jal	80000b1a <initlock>
}
    80000848:	60a2                	ld	ra,8(sp)
    8000084a:	6402                	ld	s0,0(sp)
    8000084c:	0141                	addi	sp,sp,16
    8000084e:	8082                	ret

0000000080000850 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000850:	1141                	addi	sp,sp,-16
    80000852:	e406                	sd	ra,8(sp)
    80000854:	e022                	sd	s0,0(sp)
    80000856:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000858:	100007b7          	lui	a5,0x10000
    8000085c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000860:	10000737          	lui	a4,0x10000
    80000864:	f8000693          	li	a3,-128
    80000868:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000086c:	468d                	li	a3,3
    8000086e:	10000637          	lui	a2,0x10000
    80000872:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000876:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000087a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000087e:	10000737          	lui	a4,0x10000
    80000882:	461d                	li	a2,7
    80000884:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000888:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    8000088c:	00006597          	auipc	a1,0x6
    80000890:	7a458593          	addi	a1,a1,1956 # 80007030 <etext+0x30>
    80000894:	00012517          	auipc	a0,0x12
    80000898:	b2c50513          	addi	a0,a0,-1236 # 800123c0 <tx_lock>
    8000089c:	7c0030ef          	jal	8000405c <initsleeplock>
}
    800008a0:	60a2                	ld	ra,8(sp)
    800008a2:	6402                	ld	s0,0(sp)
    800008a4:	0141                	addi	sp,sp,16
    800008a6:	8082                	ret

00000000800008a8 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008a8:	7139                	addi	sp,sp,-64
    800008aa:	fc06                	sd	ra,56(sp)
    800008ac:	f822                	sd	s0,48(sp)
    800008ae:	f04a                	sd	s2,32(sp)
    800008b0:	e456                	sd	s5,8(sp)
    800008b2:	0080                	addi	s0,sp,64
    800008b4:	8aaa                	mv	s5,a0
    800008b6:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    800008b8:	00012517          	auipc	a0,0x12
    800008bc:	b0850513          	addi	a0,a0,-1272 # 800123c0 <tx_lock>
    800008c0:	7d2030ef          	jal	80004092 <acquiresleep>

  int i = 0;
  while (i < n) {
    800008c4:	05205963          	blez	s2,80000916 <uartwrite+0x6e>
    800008c8:	f426                	sd	s1,40(sp)
    800008ca:	ec4e                	sd	s3,24(sp)
    800008cc:	e852                	sd	s4,16(sp)
    800008ce:	e05a                	sd	s6,0(sp)
  int i = 0;
    800008d0:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    800008d2:	0000aa17          	auipc	s4,0xa
    800008d6:	a06a0a13          	addi	s4,s4,-1530 # 8000a2d8 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008da:	100009b7          	lui	s3,0x10000
    800008de:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    800008e0:	10000b37          	lui	s6,0x10000
    800008e4:	a811                	j	800008f8 <uartwrite+0x50>
    800008e6:	009a87b3          	add	a5,s5,s1
    800008ea:	0007c783          	lbu	a5,0(a5)
    800008ee:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    800008f2:	2485                	addiw	s1,s1,1
  while (i < n) {
    800008f4:	0124dd63          	bge	s1,s2,8000090e <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    800008f8:	8552                	mv	a0,s4
    800008fa:	5fa010ef          	jal	80001ef4 <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008fe:	0009c783          	lbu	a5,0(s3)
    80000902:	0207f793          	andi	a5,a5,32
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x3e>
    } else {
      sleep();
    80000908:	628010ef          	jal	80001f30 <sleep>
    8000090c:	b7e5                	j	800008f4 <uartwrite+0x4c>
    8000090e:	74a2                	ld	s1,40(sp)
    80000910:	69e2                	ld	s3,24(sp)
    80000912:	6a42                	ld	s4,16(sp)
    80000914:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    80000916:	00012517          	auipc	a0,0x12
    8000091a:	aaa50513          	addi	a0,a0,-1366 # 800123c0 <tx_lock>
    8000091e:	7c8030ef          	jal	800040e6 <releasesleep>
}
    80000922:	70e2                	ld	ra,56(sp)
    80000924:	7442                	ld	s0,48(sp)
    80000926:	7902                	ld	s2,32(sp)
    80000928:	6aa2                	ld	s5,8(sp)
    8000092a:	6121                	addi	sp,sp,64
    8000092c:	8082                	ret

000000008000092e <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092e:	1101                	addi	sp,sp,-32
    80000930:	ec06                	sd	ra,24(sp)
    80000932:	e822                	sd	s0,16(sp)
    80000934:	e426                	sd	s1,8(sp)
    80000936:	1000                	addi	s0,sp,32
    80000938:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000093a:	0000a797          	auipc	a5,0xa
    8000093e:	99a7a783          	lw	a5,-1638(a5) # 8000a2d4 <panicking>
    80000942:	cf95                	beqz	a5,8000097e <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000944:	0000a797          	auipc	a5,0xa
    80000948:	98c7a783          	lw	a5,-1652(a5) # 8000a2d0 <panicked>
    8000094c:	ef85                	bnez	a5,80000984 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094e:	10000737          	lui	a4,0x10000
    80000952:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000954:	00074783          	lbu	a5,0(a4)
    80000958:	0207f793          	andi	a5,a5,32
    8000095c:	dfe5                	beqz	a5,80000954 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095e:	0ff4f513          	zext.b	a0,s1
    80000962:	100007b7          	lui	a5,0x10000
    80000966:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    8000096a:	0000a797          	auipc	a5,0xa
    8000096e:	96a7a783          	lw	a5,-1686(a5) # 8000a2d4 <panicking>
    80000972:	cb91                	beqz	a5,80000986 <uartputc_sync+0x58>
    pop_off();
}
    80000974:	60e2                	ld	ra,24(sp)
    80000976:	6442                	ld	s0,16(sp)
    80000978:	64a2                	ld	s1,8(sp)
    8000097a:	6105                	addi	sp,sp,32
    8000097c:	8082                	ret
    push_off();
    8000097e:	1dc000ef          	jal	80000b5a <push_off>
    80000982:	b7c9                	j	80000944 <uartputc_sync+0x16>
    for (;;)
    80000984:	a001                	j	80000984 <uartputc_sync+0x56>
    pop_off();
    80000986:	24a000ef          	jal	80000bd0 <pop_off>
}
    8000098a:	b7ed                	j	80000974 <uartputc_sync+0x46>

000000008000098c <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000098c:	1101                	addi	sp,sp,-32
    8000098e:	ec06                	sd	ra,24(sp)
    80000990:	e822                	sd	s0,16(sp)
    80000992:	e426                	sd	s1,8(sp)
    80000994:	e04a                	sd	s2,0(sp)
    80000996:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000998:	100007b7          	lui	a5,0x10000
    8000099c:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    8000099e:	0007c783          	lbu	a5,0(a5)

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009a8:	0007c783          	lbu	a5,0(a5)
    800009ac:	0207f793          	andi	a5,a5,32
    800009b0:	ef99                	bnez	a5,800009ce <uartintr+0x42>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009b2:	100004b7          	lui	s1,0x10000
    800009b6:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009b8:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009bc:	0004c783          	lbu	a5,0(s1)
    800009c0:	8b85                	andi	a5,a5,1
    800009c2:	cf89                	beqz	a5,800009dc <uartintr+0x50>
    return ReadReg(RHR);
    800009c4:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    800009c8:	8f3ff0ef          	jal	800002ba <consoleintr>
  while (1) {
    800009cc:	bfc5                	j	800009bc <uartintr+0x30>
    wakeup(&tx_chan);
    800009ce:	0000a517          	auipc	a0,0xa
    800009d2:	90a50513          	addi	a0,a0,-1782 # 8000a2d8 <tx_chan>
    800009d6:	58a010ef          	jal	80001f60 <wakeup>
    800009da:	bfe1                	j	800009b2 <uartintr+0x26>
  }
}
    800009dc:	60e2                	ld	ra,24(sp)
    800009de:	6442                	ld	s0,16(sp)
    800009e0:	64a2                	ld	s1,8(sp)
    800009e2:	6902                	ld	s2,0(sp)
    800009e4:	6105                	addi	sp,sp,32
    800009e6:	8082                	ret

00000000800009e8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009e8:	1101                	addi	sp,sp,-32
    800009ea:	ec06                	sd	ra,24(sp)
    800009ec:	e822                	sd	s0,16(sp)
    800009ee:	e426                	sd	s1,8(sp)
    800009f0:	e04a                	sd	s2,0(sp)
    800009f2:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    800009f4:	03451793          	slli	a5,a0,0x34
    800009f8:	e7a9                	bnez	a5,80000a42 <kfree+0x5a>
    800009fa:	84aa                	mv	s1,a0
    800009fc:	00023797          	auipc	a5,0x23
    80000a00:	02478793          	addi	a5,a5,36 # 80023a20 <end>
    80000a04:	02f56f63          	bltu	a0,a5,80000a42 <kfree+0x5a>
    80000a08:	47c5                	li	a5,17
    80000a0a:	07ee                	slli	a5,a5,0x1b
    80000a0c:	02f57b63          	bgeu	a0,a5,80000a42 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a10:	6605                	lui	a2,0x1
    80000a12:	4585                	li	a1,1
    80000a14:	240000ef          	jal	80000c54 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a18:	00012917          	auipc	s2,0x12
    80000a1c:	9d890913          	addi	s2,s2,-1576 # 800123f0 <kmem>
    80000a20:	854a                	mv	a0,s2
    80000a22:	16e000ef          	jal	80000b90 <acquire>
  r->next = kmem.freelist;
    80000a26:	01893783          	ld	a5,24(s2)
    80000a2a:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a2c:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a30:	854a                	mv	a0,s2
    80000a32:	1ea000ef          	jal	80000c1c <release>
}
    80000a36:	60e2                	ld	ra,24(sp)
    80000a38:	6442                	ld	s0,16(sp)
    80000a3a:	64a2                	ld	s1,8(sp)
    80000a3c:	6902                	ld	s2,0(sp)
    80000a3e:	6105                	addi	sp,sp,32
    80000a40:	8082                	ret
    panic("kfree");
    80000a42:	00006517          	auipc	a0,0x6
    80000a46:	5f650513          	addi	a0,a0,1526 # 80007038 <etext+0x38>
    80000a4a:	da7ff0ef          	jal	800007f0 <panic>

0000000080000a4e <freerange>:
{
    80000a4e:	7179                	addi	sp,sp,-48
    80000a50:	f406                	sd	ra,40(sp)
    80000a52:	f022                	sd	s0,32(sp)
    80000a54:	ec26                	sd	s1,24(sp)
    80000a56:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a58:	6785                	lui	a5,0x1
    80000a5a:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a5e:	00e504b3          	add	s1,a0,a4
    80000a62:	777d                	lui	a4,0xfffff
    80000a64:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a66:	94be                	add	s1,s1,a5
    80000a68:	0295e263          	bltu	a1,s1,80000a8c <freerange+0x3e>
    80000a6c:	e84a                	sd	s2,16(sp)
    80000a6e:	e44e                	sd	s3,8(sp)
    80000a70:	e052                	sd	s4,0(sp)
    80000a72:	892e                	mv	s2,a1
    kfree(p);
    80000a74:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a76:	6985                	lui	s3,0x1
    kfree(p);
    80000a78:	01448533          	add	a0,s1,s4
    80000a7c:	f6dff0ef          	jal	800009e8 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a80:	94ce                	add	s1,s1,s3
    80000a82:	fe997be3          	bgeu	s2,s1,80000a78 <freerange+0x2a>
    80000a86:	6942                	ld	s2,16(sp)
    80000a88:	69a2                	ld	s3,8(sp)
    80000a8a:	6a02                	ld	s4,0(sp)
}
    80000a8c:	70a2                	ld	ra,40(sp)
    80000a8e:	7402                	ld	s0,32(sp)
    80000a90:	64e2                	ld	s1,24(sp)
    80000a92:	6145                	addi	sp,sp,48
    80000a94:	8082                	ret

0000000080000a96 <kinit>:
{
    80000a96:	1141                	addi	sp,sp,-16
    80000a98:	e406                	sd	ra,8(sp)
    80000a9a:	e022                	sd	s0,0(sp)
    80000a9c:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000a9e:	00006597          	auipc	a1,0x6
    80000aa2:	5a258593          	addi	a1,a1,1442 # 80007040 <etext+0x40>
    80000aa6:	00012517          	auipc	a0,0x12
    80000aaa:	94a50513          	addi	a0,a0,-1718 # 800123f0 <kmem>
    80000aae:	06c000ef          	jal	80000b1a <initlock>
  freerange(end, (void *)PHYSTOP);
    80000ab2:	45c5                	li	a1,17
    80000ab4:	05ee                	slli	a1,a1,0x1b
    80000ab6:	00023517          	auipc	a0,0x23
    80000aba:	f6a50513          	addi	a0,a0,-150 # 80023a20 <end>
    80000abe:	f91ff0ef          	jal	80000a4e <freerange>
}
    80000ac2:	60a2                	ld	ra,8(sp)
    80000ac4:	6402                	ld	s0,0(sp)
    80000ac6:	0141                	addi	sp,sp,16
    80000ac8:	8082                	ret

0000000080000aca <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000aca:	1101                	addi	sp,sp,-32
    80000acc:	ec06                	sd	ra,24(sp)
    80000ace:	e822                	sd	s0,16(sp)
    80000ad0:	e426                	sd	s1,8(sp)
    80000ad2:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000ad4:	00012497          	auipc	s1,0x12
    80000ad8:	91c48493          	addi	s1,s1,-1764 # 800123f0 <kmem>
    80000adc:	8526                	mv	a0,s1
    80000ade:	0b2000ef          	jal	80000b90 <acquire>
  r = kmem.freelist;
    80000ae2:	6c84                	ld	s1,24(s1)
  if (r)
    80000ae4:	c485                	beqz	s1,80000b0c <kalloc+0x42>
    kmem.freelist = r->next;
    80000ae6:	609c                	ld	a5,0(s1)
    80000ae8:	00012517          	auipc	a0,0x12
    80000aec:	90850513          	addi	a0,a0,-1784 # 800123f0 <kmem>
    80000af0:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000af2:	12a000ef          	jal	80000c1c <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000af6:	6605                	lui	a2,0x1
    80000af8:	4595                	li	a1,5
    80000afa:	8526                	mv	a0,s1
    80000afc:	158000ef          	jal	80000c54 <memset>
  return (void *)r;
}
    80000b00:	8526                	mv	a0,s1
    80000b02:	60e2                	ld	ra,24(sp)
    80000b04:	6442                	ld	s0,16(sp)
    80000b06:	64a2                	ld	s1,8(sp)
    80000b08:	6105                	addi	sp,sp,32
    80000b0a:	8082                	ret
  release(&kmem.lock);
    80000b0c:	00012517          	auipc	a0,0x12
    80000b10:	8e450513          	addi	a0,a0,-1820 # 800123f0 <kmem>
    80000b14:	108000ef          	jal	80000c1c <release>
  if (r)
    80000b18:	b7e5                	j	80000b00 <kalloc+0x36>

0000000080000b1a <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b1a:	1141                	addi	sp,sp,-16
    80000b1c:	e422                	sd	s0,8(sp)
    80000b1e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b20:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b22:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b26:	00053823          	sd	zero,16(a0)
}
    80000b2a:	6422                	ld	s0,8(sp)
    80000b2c:	0141                	addi	sp,sp,16
    80000b2e:	8082                	ret

0000000080000b30 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b30:	411c                	lw	a5,0(a0)
    80000b32:	e399                	bnez	a5,80000b38 <holding+0x8>
    80000b34:	4501                	li	a0,0
  return r;
}
    80000b36:	8082                	ret
{
    80000b38:	1101                	addi	sp,sp,-32
    80000b3a:	ec06                	sd	ra,24(sp)
    80000b3c:	e822                	sd	s0,16(sp)
    80000b3e:	e426                	sd	s1,8(sp)
    80000b40:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b42:	6904                	ld	s1,16(a0)
    80000b44:	543000ef          	jal	80001886 <mycpu>
    80000b48:	40a48533          	sub	a0,s1,a0
    80000b4c:	00153513          	seqz	a0,a0
}
    80000b50:	60e2                	ld	ra,24(sp)
    80000b52:	6442                	ld	s0,16(sp)
    80000b54:	64a2                	ld	s1,8(sp)
    80000b56:	6105                	addi	sp,sp,32
    80000b58:	8082                	ret

0000000080000b5a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b5a:	1101                	addi	sp,sp,-32
    80000b5c:	ec06                	sd	ra,24(sp)
    80000b5e:	e822                	sd	s0,16(sp)
    80000b60:	e426                	sd	s1,8(sp)
    80000b62:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000b64:	100174f3          	csrrci	s1,sstatus,2
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000b68:	51f000ef          	jal	80001886 <mycpu>
    80000b6c:	5d3c                	lw	a5,120(a0)
    80000b6e:	cb99                	beqz	a5,80000b84 <push_off+0x2a>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000b70:	517000ef          	jal	80001886 <mycpu>
    80000b74:	5d3c                	lw	a5,120(a0)
    80000b76:	2785                	addiw	a5,a5,1
    80000b78:	dd3c                	sw	a5,120(a0)
}
    80000b7a:	60e2                	ld	ra,24(sp)
    80000b7c:	6442                	ld	s0,16(sp)
    80000b7e:	64a2                	ld	s1,8(sp)
    80000b80:	6105                	addi	sp,sp,32
    80000b82:	8082                	ret
    mycpu()->intena = old;
    80000b84:	503000ef          	jal	80001886 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000b88:	8085                	srli	s1,s1,0x1
    80000b8a:	8885                	andi	s1,s1,1
    mycpu()->intena = old;
    80000b8c:	dd64                	sw	s1,124(a0)
    80000b8e:	b7cd                	j	80000b70 <push_off+0x16>

0000000080000b90 <acquire>:
{
    80000b90:	1101                	addi	sp,sp,-32
    80000b92:	ec06                	sd	ra,24(sp)
    80000b94:	e822                	sd	s0,16(sp)
    80000b96:	e426                	sd	s1,8(sp)
    80000b98:	1000                	addi	s0,sp,32
    80000b9a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000b9c:	fbfff0ef          	jal	80000b5a <push_off>
  if (holding(lk))
    80000ba0:	8526                	mv	a0,s1
    80000ba2:	f8fff0ef          	jal	80000b30 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000ba6:	4705                	li	a4,1
  if (holding(lk))
    80000ba8:	ed11                	bnez	a0,80000bc4 <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000baa:	87ba                	mv	a5,a4
    80000bac:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bb0:	2781                	sext.w	a5,a5
    80000bb2:	ffe5                	bnez	a5,80000baa <acquire+0x1a>
  lk->cpu = mycpu();
    80000bb4:	4d3000ef          	jal	80001886 <mycpu>
    80000bb8:	e888                	sd	a0,16(s1)
}
    80000bba:	60e2                	ld	ra,24(sp)
    80000bbc:	6442                	ld	s0,16(sp)
    80000bbe:	64a2                	ld	s1,8(sp)
    80000bc0:	6105                	addi	sp,sp,32
    80000bc2:	8082                	ret
    panic("acquire");
    80000bc4:	00006517          	auipc	a0,0x6
    80000bc8:	48450513          	addi	a0,a0,1156 # 80007048 <etext+0x48>
    80000bcc:	c25ff0ef          	jal	800007f0 <panic>

0000000080000bd0 <pop_off>:

void
pop_off(void)
{
    80000bd0:	1141                	addi	sp,sp,-16
    80000bd2:	e406                	sd	ra,8(sp)
    80000bd4:	e022                	sd	s0,0(sp)
    80000bd6:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000bd8:	4af000ef          	jal	80001886 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000bdc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000be0:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000be2:	e38d                	bnez	a5,80000c04 <pop_off+0x34>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000be4:	5d3c                	lw	a5,120(a0)
    80000be6:	02f05563          	blez	a5,80000c10 <pop_off+0x40>
    panic("pop_off");
  c->noff -= 1;
    80000bea:	37fd                	addiw	a5,a5,-1
    80000bec:	0007871b          	sext.w	a4,a5
    80000bf0:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000bf2:	e709                	bnez	a4,80000bfc <pop_off+0x2c>
    80000bf4:	5d7c                	lw	a5,124(a0)
    80000bf6:	c399                	beqz	a5,80000bfc <pop_off+0x2c>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000bf8:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000bfc:	60a2                	ld	ra,8(sp)
    80000bfe:	6402                	ld	s0,0(sp)
    80000c00:	0141                	addi	sp,sp,16
    80000c02:	8082                	ret
    panic("pop_off - interruptible");
    80000c04:	00006517          	auipc	a0,0x6
    80000c08:	44c50513          	addi	a0,a0,1100 # 80007050 <etext+0x50>
    80000c0c:	be5ff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000c10:	00006517          	auipc	a0,0x6
    80000c14:	45850513          	addi	a0,a0,1112 # 80007068 <etext+0x68>
    80000c18:	bd9ff0ef          	jal	800007f0 <panic>

0000000080000c1c <release>:
{
    80000c1c:	1101                	addi	sp,sp,-32
    80000c1e:	ec06                	sd	ra,24(sp)
    80000c20:	e822                	sd	s0,16(sp)
    80000c22:	e426                	sd	s1,8(sp)
    80000c24:	1000                	addi	s0,sp,32
    80000c26:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c28:	f09ff0ef          	jal	80000b30 <holding>
    80000c2c:	cd11                	beqz	a0,80000c48 <release+0x2c>
  lk->cpu = 0;
    80000c2e:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c32:	0310000f          	fence	rw,w
    80000c36:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c3a:	f97ff0ef          	jal	80000bd0 <pop_off>
}
    80000c3e:	60e2                	ld	ra,24(sp)
    80000c40:	6442                	ld	s0,16(sp)
    80000c42:	64a2                	ld	s1,8(sp)
    80000c44:	6105                	addi	sp,sp,32
    80000c46:	8082                	ret
    panic("release");
    80000c48:	00006517          	auipc	a0,0x6
    80000c4c:	42850513          	addi	a0,a0,1064 # 80007070 <etext+0x70>
    80000c50:	ba1ff0ef          	jal	800007f0 <panic>

0000000080000c54 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000c54:	1141                	addi	sp,sp,-16
    80000c56:	e422                	sd	s0,8(sp)
    80000c58:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000c5a:	ca19                	beqz	a2,80000c70 <memset+0x1c>
    80000c5c:	87aa                	mv	a5,a0
    80000c5e:	1602                	slli	a2,a2,0x20
    80000c60:	9201                	srli	a2,a2,0x20
    80000c62:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000c66:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000c6a:	0785                	addi	a5,a5,1
    80000c6c:	fee79de3          	bne	a5,a4,80000c66 <memset+0x12>
  }
  return dst;
}
    80000c70:	6422                	ld	s0,8(sp)
    80000c72:	0141                	addi	sp,sp,16
    80000c74:	8082                	ret

0000000080000c76 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000c76:	1141                	addi	sp,sp,-16
    80000c78:	e422                	sd	s0,8(sp)
    80000c7a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000c7c:	ca05                	beqz	a2,80000cac <memcmp+0x36>
    80000c7e:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000c82:	1682                	slli	a3,a3,0x20
    80000c84:	9281                	srli	a3,a3,0x20
    80000c86:	0685                	addi	a3,a3,1
    80000c88:	96aa                	add	a3,a3,a0
    if (*s1 != *s2)
    80000c8a:	00054783          	lbu	a5,0(a0)
    80000c8e:	0005c703          	lbu	a4,0(a1)
    80000c92:	00e79863          	bne	a5,a4,80000ca2 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000c96:	0505                	addi	a0,a0,1
    80000c98:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000c9a:	fed518e3          	bne	a0,a3,80000c8a <memcmp+0x14>
  }

  return 0;
    80000c9e:	4501                	li	a0,0
    80000ca0:	a019                	j	80000ca6 <memcmp+0x30>
      return *s1 - *s2;
    80000ca2:	40e7853b          	subw	a0,a5,a4
}
    80000ca6:	6422                	ld	s0,8(sp)
    80000ca8:	0141                	addi	sp,sp,16
    80000caa:	8082                	ret
  return 0;
    80000cac:	4501                	li	a0,0
    80000cae:	bfe5                	j	80000ca6 <memcmp+0x30>

0000000080000cb0 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000cb0:	1141                	addi	sp,sp,-16
    80000cb2:	e422                	sd	s0,8(sp)
    80000cb4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000cb6:	c205                	beqz	a2,80000cd6 <memmove+0x26>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000cb8:	02a5e263          	bltu	a1,a0,80000cdc <memmove+0x2c>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000cbc:	1602                	slli	a2,a2,0x20
    80000cbe:	9201                	srli	a2,a2,0x20
    80000cc0:	00c587b3          	add	a5,a1,a2
{
    80000cc4:	872a                	mv	a4,a0
      *d++ = *s++;
    80000cc6:	0585                	addi	a1,a1,1
    80000cc8:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdb5e1>
    80000cca:	fff5c683          	lbu	a3,-1(a1)
    80000cce:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000cd2:	feb79ae3          	bne	a5,a1,80000cc6 <memmove+0x16>

  return dst;
}
    80000cd6:	6422                	ld	s0,8(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
  if (s < d && s + n > d) {
    80000cdc:	02061693          	slli	a3,a2,0x20
    80000ce0:	9281                	srli	a3,a3,0x20
    80000ce2:	00d58733          	add	a4,a1,a3
    80000ce6:	fce57be3          	bgeu	a0,a4,80000cbc <memmove+0xc>
    d += n;
    80000cea:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000cec:	fff6079b          	addiw	a5,a2,-1
    80000cf0:	1782                	slli	a5,a5,0x20
    80000cf2:	9381                	srli	a5,a5,0x20
    80000cf4:	fff7c793          	not	a5,a5
    80000cf8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000cfa:	177d                	addi	a4,a4,-1
    80000cfc:	16fd                	addi	a3,a3,-1
    80000cfe:	00074603          	lbu	a2,0(a4)
    80000d02:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d06:	fef71ae3          	bne	a4,a5,80000cfa <memmove+0x4a>
    80000d0a:	b7f1                	j	80000cd6 <memmove+0x26>

0000000080000d0c <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d0c:	1141                	addi	sp,sp,-16
    80000d0e:	e406                	sd	ra,8(sp)
    80000d10:	e022                	sd	s0,0(sp)
    80000d12:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d14:	f9dff0ef          	jal	80000cb0 <memmove>
}
    80000d18:	60a2                	ld	ra,8(sp)
    80000d1a:	6402                	ld	s0,0(sp)
    80000d1c:	0141                	addi	sp,sp,16
    80000d1e:	8082                	ret

0000000080000d20 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d20:	1141                	addi	sp,sp,-16
    80000d22:	e422                	sd	s0,8(sp)
    80000d24:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d26:	ce11                	beqz	a2,80000d42 <strncmp+0x22>
    80000d28:	00054783          	lbu	a5,0(a0)
    80000d2c:	cf89                	beqz	a5,80000d46 <strncmp+0x26>
    80000d2e:	0005c703          	lbu	a4,0(a1)
    80000d32:	00f71a63          	bne	a4,a5,80000d46 <strncmp+0x26>
    n--, p++, q++;
    80000d36:	367d                	addiw	a2,a2,-1
    80000d38:	0505                	addi	a0,a0,1
    80000d3a:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d3c:	f675                	bnez	a2,80000d28 <strncmp+0x8>
  if (n == 0)
    return 0;
    80000d3e:	4501                	li	a0,0
    80000d40:	a801                	j	80000d50 <strncmp+0x30>
    80000d42:	4501                	li	a0,0
    80000d44:	a031                	j	80000d50 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000d46:	00054503          	lbu	a0,0(a0)
    80000d4a:	0005c783          	lbu	a5,0(a1)
    80000d4e:	9d1d                	subw	a0,a0,a5
}
    80000d50:	6422                	ld	s0,8(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e422                	sd	s0,8(sp)
    80000d5a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000d5c:	87aa                	mv	a5,a0
    80000d5e:	86b2                	mv	a3,a2
    80000d60:	367d                	addiw	a2,a2,-1
    80000d62:	02d05563          	blez	a3,80000d8c <strncpy+0x36>
    80000d66:	0785                	addi	a5,a5,1
    80000d68:	0005c703          	lbu	a4,0(a1)
    80000d6c:	fee78fa3          	sb	a4,-1(a5)
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	f775                	bnez	a4,80000d5e <strncpy+0x8>
    ;
  while (n-- > 0)
    80000d74:	873e                	mv	a4,a5
    80000d76:	9fb5                	addw	a5,a5,a3
    80000d78:	37fd                	addiw	a5,a5,-1
    80000d7a:	00c05963          	blez	a2,80000d8c <strncpy+0x36>
    *s++ = 0;
    80000d7e:	0705                	addi	a4,a4,1
    80000d80:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000d84:	40e786bb          	subw	a3,a5,a4
    80000d88:	fed04be3          	bgtz	a3,80000d7e <strncpy+0x28>
  return os;
}
    80000d8c:	6422                	ld	s0,8(sp)
    80000d8e:	0141                	addi	sp,sp,16
    80000d90:	8082                	ret

0000000080000d92 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000d92:	1141                	addi	sp,sp,-16
    80000d94:	e422                	sd	s0,8(sp)
    80000d96:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000d98:	02c05363          	blez	a2,80000dbe <safestrcpy+0x2c>
    80000d9c:	fff6069b          	addiw	a3,a2,-1
    80000da0:	1682                	slli	a3,a3,0x20
    80000da2:	9281                	srli	a3,a3,0x20
    80000da4:	96ae                	add	a3,a3,a1
    80000da6:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000da8:	00d58963          	beq	a1,a3,80000dba <safestrcpy+0x28>
    80000dac:	0585                	addi	a1,a1,1
    80000dae:	0785                	addi	a5,a5,1
    80000db0:	fff5c703          	lbu	a4,-1(a1)
    80000db4:	fee78fa3          	sb	a4,-1(a5)
    80000db8:	fb65                	bnez	a4,80000da8 <safestrcpy+0x16>
    ;
  *s = 0;
    80000dba:	00078023          	sb	zero,0(a5)
  return os;
}
    80000dbe:	6422                	ld	s0,8(sp)
    80000dc0:	0141                	addi	sp,sp,16
    80000dc2:	8082                	ret

0000000080000dc4 <strlen>:

int
strlen(const char *s)
{
    80000dc4:	1141                	addi	sp,sp,-16
    80000dc6:	e422                	sd	s0,8(sp)
    80000dc8:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000dca:	00054783          	lbu	a5,0(a0)
    80000dce:	cf91                	beqz	a5,80000dea <strlen+0x26>
    80000dd0:	0505                	addi	a0,a0,1
    80000dd2:	87aa                	mv	a5,a0
    80000dd4:	86be                	mv	a3,a5
    80000dd6:	0785                	addi	a5,a5,1
    80000dd8:	fff7c703          	lbu	a4,-1(a5)
    80000ddc:	ff65                	bnez	a4,80000dd4 <strlen+0x10>
    80000dde:	40a6853b          	subw	a0,a3,a0
    80000de2:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000de4:	6422                	ld	s0,8(sp)
    80000de6:	0141                	addi	sp,sp,16
    80000de8:	8082                	ret
  for (n = 0; s[n]; n++)
    80000dea:	4501                	li	a0,0
    80000dec:	bfe5                	j	80000de4 <strlen+0x20>

0000000080000dee <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000dee:	1141                	addi	sp,sp,-16
    80000df0:	e406                	sd	ra,8(sp)
    80000df2:	e022                	sd	s0,0(sp)
    80000df4:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000df6:	281000ef          	jal	80001876 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000dfa:	00009717          	auipc	a4,0x9
    80000dfe:	4e270713          	addi	a4,a4,1250 # 8000a2dc <started>
  if (cpuid() == 0) {
    80000e02:	c51d                	beqz	a0,80000e30 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e04:	431c                	lw	a5,0(a4)
    80000e06:	0230000f          	fence	r,rw
    80000e0a:	2781                	sext.w	a5,a5
    80000e0c:	dfe5                	beqz	a5,80000e04 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e0e:	269000ef          	jal	80001876 <cpuid>
    80000e12:	85aa                	mv	a1,a0
    80000e14:	00006517          	auipc	a0,0x6
    80000e18:	28450513          	addi	a0,a0,644 # 80007098 <etext+0x98>
    80000e1c:	eeeff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000e20:	082000ef          	jal	80000ea2 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e24:	6e6010ef          	jal	8000250a <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e28:	0c1040ef          	jal	800056e8 <plicinithart>
  }

  scheduler();
    80000e2c:	6ef000ef          	jal	80001d1a <scheduler>
    consoleinit();
    80000e30:	e04ff0ef          	jal	80000434 <consoleinit>
    printkinit();
    80000e34:	9f9ff0ef          	jal	8000082c <printkinit>
    printk("\n");
    80000e38:	00006517          	auipc	a0,0x6
    80000e3c:	24050513          	addi	a0,a0,576 # 80007078 <etext+0x78>
    80000e40:	ecaff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000e44:	00006517          	auipc	a0,0x6
    80000e48:	23c50513          	addi	a0,a0,572 # 80007080 <etext+0x80>
    80000e4c:	ebeff0ef          	jal	8000050a <printk>
    printk("\n");
    80000e50:	00006517          	auipc	a0,0x6
    80000e54:	22850513          	addi	a0,a0,552 # 80007078 <etext+0x78>
    80000e58:	eb2ff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000e5c:	c3bff0ef          	jal	80000a96 <kinit>
    kvminit();          // create kernel page table
    80000e60:	2cc000ef          	jal	8000112c <kvminit>
    kvminithart();      // turn on paging
    80000e64:	03e000ef          	jal	80000ea2 <kvminithart>
    procinit();         // process table
    80000e68:	159000ef          	jal	800017c0 <procinit>
    trapinit();         // trap vectors
    80000e6c:	67a010ef          	jal	800024e6 <trapinit>
    trapinithart();     // install kernel trap vector
    80000e70:	69a010ef          	jal	8000250a <trapinithart>
    plicinit();         // set up interrupt controller
    80000e74:	05b040ef          	jal	800056ce <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000e78:	071040ef          	jal	800056e8 <plicinithart>
    binit();            // buffer cache
    80000e7c:	56f010ef          	jal	80002bea <binit>
    iinit();            // inode table
    80000e80:	2f4020ef          	jal	80003174 <iinit>
    fileinit();         // file table
    80000e84:	2e4030ef          	jal	80004168 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000e88:	159040ef          	jal	800057e0 <virtio_disk_init>
    userinit();         // first user process
    80000e8c:	4e3000ef          	jal	80001b6e <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000e90:	00009797          	auipc	a5,0x9
    80000e94:	44c78793          	addi	a5,a5,1100 # 8000a2dc <started>
    80000e98:	4705                	li	a4,1
    80000e9a:	0310000f          	fence	rw,w
    80000e9e:	c398                	sw	a4,0(a5)
    80000ea0:	b771                	j	80000e2c <main+0x3e>

0000000080000ea2 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000ea2:	1141                	addi	sp,sp,-16
    80000ea4:	e422                	sd	s0,8(sp)
    80000ea6:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000ea8:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000eac:	00009797          	auipc	a5,0x9
    80000eb0:	4347b783          	ld	a5,1076(a5) # 8000a2e0 <kernel_pagetable>
    80000eb4:	83b1                	srli	a5,a5,0xc
    80000eb6:	577d                	li	a4,-1
    80000eb8:	177e                	slli	a4,a4,0x3f
    80000eba:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000ebc:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000ec0:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000ec4:	6422                	ld	s0,8(sp)
    80000ec6:	0141                	addi	sp,sp,16
    80000ec8:	8082                	ret

0000000080000eca <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000eca:	7139                	addi	sp,sp,-64
    80000ecc:	fc06                	sd	ra,56(sp)
    80000ece:	f822                	sd	s0,48(sp)
    80000ed0:	f426                	sd	s1,40(sp)
    80000ed2:	f04a                	sd	s2,32(sp)
    80000ed4:	ec4e                	sd	s3,24(sp)
    80000ed6:	e852                	sd	s4,16(sp)
    80000ed8:	e456                	sd	s5,8(sp)
    80000eda:	e05a                	sd	s6,0(sp)
    80000edc:	0080                	addi	s0,sp,64
    80000ede:	84aa                	mv	s1,a0
    80000ee0:	89ae                	mv	s3,a1
    80000ee2:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    80000ee4:	57fd                	li	a5,-1
    80000ee6:	83e9                	srli	a5,a5,0x1a
    80000ee8:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000eea:	4b31                	li	s6,12
  if (va >= MAXVA)
    80000eec:	02b7fc63          	bgeu	a5,a1,80000f24 <walk+0x5a>
    panic("walk");
    80000ef0:	00006517          	auipc	a0,0x6
    80000ef4:	1c050513          	addi	a0,a0,448 # 800070b0 <etext+0xb0>
    80000ef8:	8f9ff0ef          	jal	800007f0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000efc:	060a8263          	beqz	s5,80000f60 <walk+0x96>
    80000f00:	bcbff0ef          	jal	80000aca <kalloc>
    80000f04:	84aa                	mv	s1,a0
    80000f06:	c139                	beqz	a0,80000f4c <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f08:	6605                	lui	a2,0x1
    80000f0a:	4581                	li	a1,0
    80000f0c:	d49ff0ef          	jal	80000c54 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f10:	00c4d793          	srli	a5,s1,0xc
    80000f14:	07aa                	slli	a5,a5,0xa
    80000f16:	0017e793          	ori	a5,a5,1
    80000f1a:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000f1e:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdb5d7>
    80000f20:	036a0063          	beq	s4,s6,80000f40 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f24:	0149d933          	srl	s2,s3,s4
    80000f28:	1ff97913          	andi	s2,s2,511
    80000f2c:	090e                	slli	s2,s2,0x3
    80000f2e:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f30:	00093483          	ld	s1,0(s2)
    80000f34:	0014f793          	andi	a5,s1,1
    80000f38:	d3f1                	beqz	a5,80000efc <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f3a:	80a9                	srli	s1,s1,0xa
    80000f3c:	04b2                	slli	s1,s1,0xc
    80000f3e:	b7c5                	j	80000f1e <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f40:	00c9d513          	srli	a0,s3,0xc
    80000f44:	1ff57513          	andi	a0,a0,511
    80000f48:	050e                	slli	a0,a0,0x3
    80000f4a:	9526                	add	a0,a0,s1
}
    80000f4c:	70e2                	ld	ra,56(sp)
    80000f4e:	7442                	ld	s0,48(sp)
    80000f50:	74a2                	ld	s1,40(sp)
    80000f52:	7902                	ld	s2,32(sp)
    80000f54:	69e2                	ld	s3,24(sp)
    80000f56:	6a42                	ld	s4,16(sp)
    80000f58:	6aa2                	ld	s5,8(sp)
    80000f5a:	6b02                	ld	s6,0(sp)
    80000f5c:	6121                	addi	sp,sp,64
    80000f5e:	8082                	ret
        return 0;
    80000f60:	4501                	li	a0,0
    80000f62:	b7ed                	j	80000f4c <walk+0x82>

0000000080000f64 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000f64:	57fd                	li	a5,-1
    80000f66:	83e9                	srli	a5,a5,0x1a
    80000f68:	00b7f463          	bgeu	a5,a1,80000f70 <walkaddr+0xc>
    return 0;
    80000f6c:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000f6e:	8082                	ret
{
    80000f70:	1141                	addi	sp,sp,-16
    80000f72:	e406                	sd	ra,8(sp)
    80000f74:	e022                	sd	s0,0(sp)
    80000f76:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000f78:	4601                	li	a2,0
    80000f7a:	f51ff0ef          	jal	80000eca <walk>
  if (pte == 0)
    80000f7e:	c105                	beqz	a0,80000f9e <walkaddr+0x3a>
  if ((*pte & PTE_V) == 0)
    80000f80:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000f82:	0117f693          	andi	a3,a5,17
    80000f86:	4745                	li	a4,17
    return 0;
    80000f88:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80000f8a:	00e68663          	beq	a3,a4,80000f96 <walkaddr+0x32>
}
    80000f8e:	60a2                	ld	ra,8(sp)
    80000f90:	6402                	ld	s0,0(sp)
    80000f92:	0141                	addi	sp,sp,16
    80000f94:	8082                	ret
  pa = PTE2PA(*pte);
    80000f96:	83a9                	srli	a5,a5,0xa
    80000f98:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000f9c:	bfcd                	j	80000f8e <walkaddr+0x2a>
    return 0;
    80000f9e:	4501                	li	a0,0
    80000fa0:	b7fd                	j	80000f8e <walkaddr+0x2a>

0000000080000fa2 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fa2:	715d                	addi	sp,sp,-80
    80000fa4:	e486                	sd	ra,72(sp)
    80000fa6:	e0a2                	sd	s0,64(sp)
    80000fa8:	fc26                	sd	s1,56(sp)
    80000faa:	f84a                	sd	s2,48(sp)
    80000fac:	f44e                	sd	s3,40(sp)
    80000fae:	f052                	sd	s4,32(sp)
    80000fb0:	ec56                	sd	s5,24(sp)
    80000fb2:	e85a                	sd	s6,16(sp)
    80000fb4:	e45e                	sd	s7,8(sp)
    80000fb6:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80000fb8:	03459793          	slli	a5,a1,0x34
    80000fbc:	e7a9                	bnez	a5,80001006 <mappages+0x64>
    80000fbe:	8aaa                	mv	s5,a0
    80000fc0:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80000fc2:	03461793          	slli	a5,a2,0x34
    80000fc6:	e7b1                	bnez	a5,80001012 <mappages+0x70>
    panic("mappages: size not aligned");

  if (size == 0)
    80000fc8:	ca39                	beqz	a2,8000101e <mappages+0x7c>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80000fca:	77fd                	lui	a5,0xfffff
    80000fcc:	963e                	add	a2,a2,a5
    80000fce:	00b609b3          	add	s3,a2,a1
  a = va;
    80000fd2:	892e                	mv	s2,a1
    80000fd4:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80000fd8:	6b85                	lui	s7,0x1
    80000fda:	014904b3          	add	s1,s2,s4
    if ((pte = walk(pagetable, a, 1)) == 0)
    80000fde:	4605                	li	a2,1
    80000fe0:	85ca                	mv	a1,s2
    80000fe2:	8556                	mv	a0,s5
    80000fe4:	ee7ff0ef          	jal	80000eca <walk>
    80000fe8:	c539                	beqz	a0,80001036 <mappages+0x94>
    if (*pte & PTE_V)
    80000fea:	611c                	ld	a5,0(a0)
    80000fec:	8b85                	andi	a5,a5,1
    80000fee:	ef95                	bnez	a5,8000102a <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000ff0:	80b1                	srli	s1,s1,0xc
    80000ff2:	04aa                	slli	s1,s1,0xa
    80000ff4:	0164e4b3          	or	s1,s1,s6
    80000ff8:	0014e493          	ori	s1,s1,1
    80000ffc:	e104                	sd	s1,0(a0)
    if (a == last)
    80000ffe:	05390863          	beq	s2,s3,8000104e <mappages+0xac>
    a += PGSIZE;
    80001002:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001004:	bfd9                	j	80000fda <mappages+0x38>
    panic("mappages: va not aligned");
    80001006:	00006517          	auipc	a0,0x6
    8000100a:	0b250513          	addi	a0,a0,178 # 800070b8 <etext+0xb8>
    8000100e:	fe2ff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    80001012:	00006517          	auipc	a0,0x6
    80001016:	0c650513          	addi	a0,a0,198 # 800070d8 <etext+0xd8>
    8000101a:	fd6ff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    8000101e:	00006517          	auipc	a0,0x6
    80001022:	0da50513          	addi	a0,a0,218 # 800070f8 <etext+0xf8>
    80001026:	fcaff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    8000102a:	00006517          	auipc	a0,0x6
    8000102e:	0de50513          	addi	a0,a0,222 # 80007108 <etext+0x108>
    80001032:	fbeff0ef          	jal	800007f0 <panic>
      return -1;
    80001036:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001038:	60a6                	ld	ra,72(sp)
    8000103a:	6406                	ld	s0,64(sp)
    8000103c:	74e2                	ld	s1,56(sp)
    8000103e:	7942                	ld	s2,48(sp)
    80001040:	79a2                	ld	s3,40(sp)
    80001042:	7a02                	ld	s4,32(sp)
    80001044:	6ae2                	ld	s5,24(sp)
    80001046:	6b42                	ld	s6,16(sp)
    80001048:	6ba2                	ld	s7,8(sp)
    8000104a:	6161                	addi	sp,sp,80
    8000104c:	8082                	ret
  return 0;
    8000104e:	4501                	li	a0,0
    80001050:	b7e5                	j	80001038 <mappages+0x96>

0000000080001052 <kvmmap>:
{
    80001052:	1141                	addi	sp,sp,-16
    80001054:	e406                	sd	ra,8(sp)
    80001056:	e022                	sd	s0,0(sp)
    80001058:	0800                	addi	s0,sp,16
    8000105a:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000105c:	86b2                	mv	a3,a2
    8000105e:	863e                	mv	a2,a5
    80001060:	f43ff0ef          	jal	80000fa2 <mappages>
    80001064:	e509                	bnez	a0,8000106e <kvmmap+0x1c>
}
    80001066:	60a2                	ld	ra,8(sp)
    80001068:	6402                	ld	s0,0(sp)
    8000106a:	0141                	addi	sp,sp,16
    8000106c:	8082                	ret
    panic("kvmmap");
    8000106e:	00006517          	auipc	a0,0x6
    80001072:	0aa50513          	addi	a0,a0,170 # 80007118 <etext+0x118>
    80001076:	f7aff0ef          	jal	800007f0 <panic>

000000008000107a <kvmmake>:
{
    8000107a:	1101                	addi	sp,sp,-32
    8000107c:	ec06                	sd	ra,24(sp)
    8000107e:	e822                	sd	s0,16(sp)
    80001080:	e426                	sd	s1,8(sp)
    80001082:	e04a                	sd	s2,0(sp)
    80001084:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    80001086:	a45ff0ef          	jal	80000aca <kalloc>
    8000108a:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000108c:	6605                	lui	a2,0x1
    8000108e:	4581                	li	a1,0
    80001090:	bc5ff0ef          	jal	80000c54 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001094:	4719                	li	a4,6
    80001096:	6685                	lui	a3,0x1
    80001098:	10000637          	lui	a2,0x10000
    8000109c:	100005b7          	lui	a1,0x10000
    800010a0:	8526                	mv	a0,s1
    800010a2:	fb1ff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010a6:	4719                	li	a4,6
    800010a8:	6685                	lui	a3,0x1
    800010aa:	10001637          	lui	a2,0x10001
    800010ae:	100015b7          	lui	a1,0x10001
    800010b2:	8526                	mv	a0,s1
    800010b4:	f9fff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800010b8:	4719                	li	a4,6
    800010ba:	040006b7          	lui	a3,0x4000
    800010be:	0c000637          	lui	a2,0xc000
    800010c2:	0c0005b7          	lui	a1,0xc000
    800010c6:	8526                	mv	a0,s1
    800010c8:	f8bff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    800010cc:	00006917          	auipc	s2,0x6
    800010d0:	f3490913          	addi	s2,s2,-204 # 80007000 <etext>
    800010d4:	4729                	li	a4,10
    800010d6:	80006697          	auipc	a3,0x80006
    800010da:	f2a68693          	addi	a3,a3,-214 # 7000 <_entry-0x7fff9000>
    800010de:	4605                	li	a2,1
    800010e0:	067e                	slli	a2,a2,0x1f
    800010e2:	85b2                	mv	a1,a2
    800010e4:	8526                	mv	a0,s1
    800010e6:	f6dff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    800010ea:	46c5                	li	a3,17
    800010ec:	06ee                	slli	a3,a3,0x1b
    800010ee:	4719                	li	a4,6
    800010f0:	412686b3          	sub	a3,a3,s2
    800010f4:	864a                	mv	a2,s2
    800010f6:	85ca                	mv	a1,s2
    800010f8:	8526                	mv	a0,s1
    800010fa:	f59ff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800010fe:	4729                	li	a4,10
    80001100:	6685                	lui	a3,0x1
    80001102:	00005617          	auipc	a2,0x5
    80001106:	efe60613          	addi	a2,a2,-258 # 80006000 <_trampoline>
    8000110a:	040005b7          	lui	a1,0x4000
    8000110e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001110:	05b2                	slli	a1,a1,0xc
    80001112:	8526                	mv	a0,s1
    80001114:	f3fff0ef          	jal	80001052 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001118:	8526                	mv	a0,s1
    8000111a:	60e000ef          	jal	80001728 <proc_mapstacks>
}
    8000111e:	8526                	mv	a0,s1
    80001120:	60e2                	ld	ra,24(sp)
    80001122:	6442                	ld	s0,16(sp)
    80001124:	64a2                	ld	s1,8(sp)
    80001126:	6902                	ld	s2,0(sp)
    80001128:	6105                	addi	sp,sp,32
    8000112a:	8082                	ret

000000008000112c <kvminit>:
{
    8000112c:	1141                	addi	sp,sp,-16
    8000112e:	e406                	sd	ra,8(sp)
    80001130:	e022                	sd	s0,0(sp)
    80001132:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001134:	f47ff0ef          	jal	8000107a <kvmmake>
    80001138:	00009797          	auipc	a5,0x9
    8000113c:	1aa7b423          	sd	a0,424(a5) # 8000a2e0 <kernel_pagetable>
}
    80001140:	60a2                	ld	ra,8(sp)
    80001142:	6402                	ld	s0,0(sp)
    80001144:	0141                	addi	sp,sp,16
    80001146:	8082                	ret

0000000080001148 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001148:	1101                	addi	sp,sp,-32
    8000114a:	ec06                	sd	ra,24(sp)
    8000114c:	e822                	sd	s0,16(sp)
    8000114e:	e426                	sd	s1,8(sp)
    80001150:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001152:	979ff0ef          	jal	80000aca <kalloc>
    80001156:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001158:	c509                	beqz	a0,80001162 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000115a:	6605                	lui	a2,0x1
    8000115c:	4581                	li	a1,0
    8000115e:	af7ff0ef          	jal	80000c54 <memset>
  return pagetable;
}
    80001162:	8526                	mv	a0,s1
    80001164:	60e2                	ld	ra,24(sp)
    80001166:	6442                	ld	s0,16(sp)
    80001168:	64a2                	ld	s1,8(sp)
    8000116a:	6105                	addi	sp,sp,32
    8000116c:	8082                	ret

000000008000116e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000116e:	7139                	addi	sp,sp,-64
    80001170:	fc06                	sd	ra,56(sp)
    80001172:	f822                	sd	s0,48(sp)
    80001174:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001176:	03459793          	slli	a5,a1,0x34
    8000117a:	e38d                	bnez	a5,8000119c <uvmunmap+0x2e>
    8000117c:	f04a                	sd	s2,32(sp)
    8000117e:	ec4e                	sd	s3,24(sp)
    80001180:	e852                	sd	s4,16(sp)
    80001182:	e456                	sd	s5,8(sp)
    80001184:	e05a                	sd	s6,0(sp)
    80001186:	8a2a                	mv	s4,a0
    80001188:	892e                	mv	s2,a1
    8000118a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000118c:	0632                	slli	a2,a2,0xc
    8000118e:	00b609b3          	add	s3,a2,a1
    80001192:	6b05                	lui	s6,0x1
    80001194:	0535f963          	bgeu	a1,s3,800011e6 <uvmunmap+0x78>
    80001198:	f426                	sd	s1,40(sp)
    8000119a:	a015                	j	800011be <uvmunmap+0x50>
    8000119c:	f426                	sd	s1,40(sp)
    8000119e:	f04a                	sd	s2,32(sp)
    800011a0:	ec4e                	sd	s3,24(sp)
    800011a2:	e852                	sd	s4,16(sp)
    800011a4:	e456                	sd	s5,8(sp)
    800011a6:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011a8:	00006517          	auipc	a0,0x6
    800011ac:	f7850513          	addi	a0,a0,-136 # 80007120 <etext+0x120>
    800011b0:	e40ff0ef          	jal	800007f0 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    800011b4:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011b8:	995a                	add	s2,s2,s6
    800011ba:	03397563          	bgeu	s2,s3,800011e4 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800011be:	4601                	li	a2,0
    800011c0:	85ca                	mv	a1,s2
    800011c2:	8552                	mv	a0,s4
    800011c4:	d07ff0ef          	jal	80000eca <walk>
    800011c8:	84aa                	mv	s1,a0
    800011ca:	d57d                	beqz	a0,800011b8 <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    800011cc:	611c                	ld	a5,0(a0)
    800011ce:	0017f713          	andi	a4,a5,1
    800011d2:	d37d                	beqz	a4,800011b8 <uvmunmap+0x4a>
    if (do_free) {
    800011d4:	fe0a80e3          	beqz	s5,800011b4 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800011d8:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    800011da:	00c79513          	slli	a0,a5,0xc
    800011de:	80bff0ef          	jal	800009e8 <kfree>
    800011e2:	bfc9                	j	800011b4 <uvmunmap+0x46>
    800011e4:	74a2                	ld	s1,40(sp)
    800011e6:	7902                	ld	s2,32(sp)
    800011e8:	69e2                	ld	s3,24(sp)
    800011ea:	6a42                	ld	s4,16(sp)
    800011ec:	6aa2                	ld	s5,8(sp)
    800011ee:	6b02                	ld	s6,0(sp)
  }
}
    800011f0:	70e2                	ld	ra,56(sp)
    800011f2:	7442                	ld	s0,48(sp)
    800011f4:	6121                	addi	sp,sp,64
    800011f6:	8082                	ret

00000000800011f8 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800011f8:	1101                	addi	sp,sp,-32
    800011fa:	ec06                	sd	ra,24(sp)
    800011fc:	e822                	sd	s0,16(sp)
    800011fe:	e426                	sd	s1,8(sp)
    80001200:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001202:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    80001204:	00b67d63          	bgeu	a2,a1,8000121e <uvmdealloc+0x26>
    80001208:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    8000120a:	6785                	lui	a5,0x1
    8000120c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000120e:	00f60733          	add	a4,a2,a5
    80001212:	76fd                	lui	a3,0xfffff
    80001214:	8f75                	and	a4,a4,a3
    80001216:	97ae                	add	a5,a5,a1
    80001218:	8ff5                	and	a5,a5,a3
    8000121a:	00f76863          	bltu	a4,a5,8000122a <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    8000121e:	8526                	mv	a0,s1
    80001220:	60e2                	ld	ra,24(sp)
    80001222:	6442                	ld	s0,16(sp)
    80001224:	64a2                	ld	s1,8(sp)
    80001226:	6105                	addi	sp,sp,32
    80001228:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000122a:	8f99                	sub	a5,a5,a4
    8000122c:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000122e:	4685                	li	a3,1
    80001230:	0007861b          	sext.w	a2,a5
    80001234:	85ba                	mv	a1,a4
    80001236:	f39ff0ef          	jal	8000116e <uvmunmap>
    8000123a:	b7d5                	j	8000121e <uvmdealloc+0x26>

000000008000123c <uvmalloc>:
  if (newsz < oldsz)
    8000123c:	08b66f63          	bltu	a2,a1,800012da <uvmalloc+0x9e>
{
    80001240:	7139                	addi	sp,sp,-64
    80001242:	fc06                	sd	ra,56(sp)
    80001244:	f822                	sd	s0,48(sp)
    80001246:	ec4e                	sd	s3,24(sp)
    80001248:	e852                	sd	s4,16(sp)
    8000124a:	e456                	sd	s5,8(sp)
    8000124c:	0080                	addi	s0,sp,64
    8000124e:	8aaa                	mv	s5,a0
    80001250:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001252:	6785                	lui	a5,0x1
    80001254:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001256:	95be                	add	a1,a1,a5
    80001258:	77fd                	lui	a5,0xfffff
    8000125a:	00f5f9b3          	and	s3,a1,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    8000125e:	08c9f063          	bgeu	s3,a2,800012de <uvmalloc+0xa2>
    80001262:	f426                	sd	s1,40(sp)
    80001264:	f04a                	sd	s2,32(sp)
    80001266:	e05a                	sd	s6,0(sp)
    80001268:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000126a:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000126e:	85dff0ef          	jal	80000aca <kalloc>
    80001272:	84aa                	mv	s1,a0
    if (mem == 0) {
    80001274:	c515                	beqz	a0,800012a0 <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001276:	6605                	lui	a2,0x1
    80001278:	4581                	li	a1,0
    8000127a:	9dbff0ef          	jal	80000c54 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000127e:	875a                	mv	a4,s6
    80001280:	86a6                	mv	a3,s1
    80001282:	6605                	lui	a2,0x1
    80001284:	85ca                	mv	a1,s2
    80001286:	8556                	mv	a0,s5
    80001288:	d1bff0ef          	jal	80000fa2 <mappages>
    8000128c:	e915                	bnez	a0,800012c0 <uvmalloc+0x84>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    8000128e:	6785                	lui	a5,0x1
    80001290:	993e                	add	s2,s2,a5
    80001292:	fd496ee3          	bltu	s2,s4,8000126e <uvmalloc+0x32>
  return newsz;
    80001296:	8552                	mv	a0,s4
    80001298:	74a2                	ld	s1,40(sp)
    8000129a:	7902                	ld	s2,32(sp)
    8000129c:	6b02                	ld	s6,0(sp)
    8000129e:	a811                	j	800012b2 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012a0:	864e                	mv	a2,s3
    800012a2:	85ca                	mv	a1,s2
    800012a4:	8556                	mv	a0,s5
    800012a6:	f53ff0ef          	jal	800011f8 <uvmdealloc>
      return 0;
    800012aa:	4501                	li	a0,0
    800012ac:	74a2                	ld	s1,40(sp)
    800012ae:	7902                	ld	s2,32(sp)
    800012b0:	6b02                	ld	s6,0(sp)
}
    800012b2:	70e2                	ld	ra,56(sp)
    800012b4:	7442                	ld	s0,48(sp)
    800012b6:	69e2                	ld	s3,24(sp)
    800012b8:	6a42                	ld	s4,16(sp)
    800012ba:	6aa2                	ld	s5,8(sp)
    800012bc:	6121                	addi	sp,sp,64
    800012be:	8082                	ret
      kfree(mem);
    800012c0:	8526                	mv	a0,s1
    800012c2:	f26ff0ef          	jal	800009e8 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800012c6:	864e                	mv	a2,s3
    800012c8:	85ca                	mv	a1,s2
    800012ca:	8556                	mv	a0,s5
    800012cc:	f2dff0ef          	jal	800011f8 <uvmdealloc>
      return 0;
    800012d0:	4501                	li	a0,0
    800012d2:	74a2                	ld	s1,40(sp)
    800012d4:	7902                	ld	s2,32(sp)
    800012d6:	6b02                	ld	s6,0(sp)
    800012d8:	bfe9                	j	800012b2 <uvmalloc+0x76>
    return oldsz;
    800012da:	852e                	mv	a0,a1
}
    800012dc:	8082                	ret
  return newsz;
    800012de:	8532                	mv	a0,a2
    800012e0:	bfc9                	j	800012b2 <uvmalloc+0x76>

00000000800012e2 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800012e2:	7179                	addi	sp,sp,-48
    800012e4:	f406                	sd	ra,40(sp)
    800012e6:	f022                	sd	s0,32(sp)
    800012e8:	ec26                	sd	s1,24(sp)
    800012ea:	e84a                	sd	s2,16(sp)
    800012ec:	e44e                	sd	s3,8(sp)
    800012ee:	e052                	sd	s4,0(sp)
    800012f0:	1800                	addi	s0,sp,48
    800012f2:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    800012f4:	84aa                	mv	s1,a0
    800012f6:	6905                	lui	s2,0x1
    800012f8:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800012fa:	4985                	li	s3,1
    800012fc:	a819                	j	80001312 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800012fe:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001300:	00c79513          	slli	a0,a5,0xc
    80001304:	fdfff0ef          	jal	800012e2 <freewalk>
      pagetable[i] = 0;
    80001308:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++) {
    8000130c:	04a1                	addi	s1,s1,8
    8000130e:	01248f63          	beq	s1,s2,8000132c <freewalk+0x4a>
    pte_t pte = pagetable[i];
    80001312:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001314:	00f7f713          	andi	a4,a5,15
    80001318:	ff3703e3          	beq	a4,s3,800012fe <freewalk+0x1c>
    } else if (pte & PTE_V) {
    8000131c:	8b85                	andi	a5,a5,1
    8000131e:	d7fd                	beqz	a5,8000130c <freewalk+0x2a>
      panic("freewalk: leaf");
    80001320:	00006517          	auipc	a0,0x6
    80001324:	e1850513          	addi	a0,a0,-488 # 80007138 <etext+0x138>
    80001328:	cc8ff0ef          	jal	800007f0 <panic>
    }
  }
  kfree((void *)pagetable);
    8000132c:	8552                	mv	a0,s4
    8000132e:	ebaff0ef          	jal	800009e8 <kfree>
}
    80001332:	70a2                	ld	ra,40(sp)
    80001334:	7402                	ld	s0,32(sp)
    80001336:	64e2                	ld	s1,24(sp)
    80001338:	6942                	ld	s2,16(sp)
    8000133a:	69a2                	ld	s3,8(sp)
    8000133c:	6a02                	ld	s4,0(sp)
    8000133e:	6145                	addi	sp,sp,48
    80001340:	8082                	ret

0000000080001342 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001342:	1101                	addi	sp,sp,-32
    80001344:	ec06                	sd	ra,24(sp)
    80001346:	e822                	sd	s0,16(sp)
    80001348:	e426                	sd	s1,8(sp)
    8000134a:	1000                	addi	s0,sp,32
    8000134c:	84aa                	mv	s1,a0
  if (sz > 0)
    8000134e:	e989                	bnez	a1,80001360 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001350:	8526                	mv	a0,s1
    80001352:	f91ff0ef          	jal	800012e2 <freewalk>
}
    80001356:	60e2                	ld	ra,24(sp)
    80001358:	6442                	ld	s0,16(sp)
    8000135a:	64a2                	ld	s1,8(sp)
    8000135c:	6105                	addi	sp,sp,32
    8000135e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001360:	6785                	lui	a5,0x1
    80001362:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001364:	95be                	add	a1,a1,a5
    80001366:	4685                	li	a3,1
    80001368:	00c5d613          	srli	a2,a1,0xc
    8000136c:	4581                	li	a1,0
    8000136e:	e01ff0ef          	jal	8000116e <uvmunmap>
    80001372:	bff9                	j	80001350 <uvmfree+0xe>

0000000080001374 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    80001374:	ce49                	beqz	a2,8000140e <uvmcopy+0x9a>
{
    80001376:	715d                	addi	sp,sp,-80
    80001378:	e486                	sd	ra,72(sp)
    8000137a:	e0a2                	sd	s0,64(sp)
    8000137c:	fc26                	sd	s1,56(sp)
    8000137e:	f84a                	sd	s2,48(sp)
    80001380:	f44e                	sd	s3,40(sp)
    80001382:	f052                	sd	s4,32(sp)
    80001384:	ec56                	sd	s5,24(sp)
    80001386:	e85a                	sd	s6,16(sp)
    80001388:	e45e                	sd	s7,8(sp)
    8000138a:	0880                	addi	s0,sp,80
    8000138c:	8aaa                	mv	s5,a0
    8000138e:	8b2e                	mv	s6,a1
    80001390:	8a32                	mv	s4,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001392:	4481                	li	s1,0
    80001394:	a029                	j	8000139e <uvmcopy+0x2a>
    80001396:	6785                	lui	a5,0x1
    80001398:	94be                	add	s1,s1,a5
    8000139a:	0544fe63          	bgeu	s1,s4,800013f6 <uvmcopy+0x82>
    if ((pte = walk(old, i, 0)) == 0)
    8000139e:	4601                	li	a2,0
    800013a0:	85a6                	mv	a1,s1
    800013a2:	8556                	mv	a0,s5
    800013a4:	b27ff0ef          	jal	80000eca <walk>
    800013a8:	d57d                	beqz	a0,80001396 <uvmcopy+0x22>
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0)
    800013aa:	6118                	ld	a4,0(a0)
    800013ac:	00177793          	andi	a5,a4,1
    800013b0:	d3fd                	beqz	a5,80001396 <uvmcopy+0x22>
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013b2:	00a75593          	srli	a1,a4,0xa
    800013b6:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800013ba:	3ff77913          	andi	s2,a4,1023
    if ((mem = kalloc()) == 0)
    800013be:	f0cff0ef          	jal	80000aca <kalloc>
    800013c2:	89aa                	mv	s3,a0
    800013c4:	c105                	beqz	a0,800013e4 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800013c6:	6605                	lui	a2,0x1
    800013c8:	85de                	mv	a1,s7
    800013ca:	8e7ff0ef          	jal	80000cb0 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    800013ce:	874a                	mv	a4,s2
    800013d0:	86ce                	mv	a3,s3
    800013d2:	6605                	lui	a2,0x1
    800013d4:	85a6                	mv	a1,s1
    800013d6:	855a                	mv	a0,s6
    800013d8:	bcbff0ef          	jal	80000fa2 <mappages>
    800013dc:	dd4d                	beqz	a0,80001396 <uvmcopy+0x22>
      kfree(mem);
    800013de:	854e                	mv	a0,s3
    800013e0:	e08ff0ef          	jal	800009e8 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800013e4:	4685                	li	a3,1
    800013e6:	00c4d613          	srli	a2,s1,0xc
    800013ea:	4581                	li	a1,0
    800013ec:	855a                	mv	a0,s6
    800013ee:	d81ff0ef          	jal	8000116e <uvmunmap>
  return -1;
    800013f2:	557d                	li	a0,-1
    800013f4:	a011                	j	800013f8 <uvmcopy+0x84>
  return 0;
    800013f6:	4501                	li	a0,0
}
    800013f8:	60a6                	ld	ra,72(sp)
    800013fa:	6406                	ld	s0,64(sp)
    800013fc:	74e2                	ld	s1,56(sp)
    800013fe:	7942                	ld	s2,48(sp)
    80001400:	79a2                	ld	s3,40(sp)
    80001402:	7a02                	ld	s4,32(sp)
    80001404:	6ae2                	ld	s5,24(sp)
    80001406:	6b42                	ld	s6,16(sp)
    80001408:	6ba2                	ld	s7,8(sp)
    8000140a:	6161                	addi	sp,sp,80
    8000140c:	8082                	ret
  return 0;
    8000140e:	4501                	li	a0,0
}
    80001410:	8082                	ret

0000000080001412 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001412:	1141                	addi	sp,sp,-16
    80001414:	e406                	sd	ra,8(sp)
    80001416:	e022                	sd	s0,0(sp)
    80001418:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    8000141a:	4601                	li	a2,0
    8000141c:	aafff0ef          	jal	80000eca <walk>
  if (pte == 0)
    80001420:	c901                	beqz	a0,80001430 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001422:	611c                	ld	a5,0(a0)
    80001424:	9bbd                	andi	a5,a5,-17
    80001426:	e11c                	sd	a5,0(a0)
}
    80001428:	60a2                	ld	ra,8(sp)
    8000142a:	6402                	ld	s0,0(sp)
    8000142c:	0141                	addi	sp,sp,16
    8000142e:	8082                	ret
    panic("uvmclear");
    80001430:	00006517          	auipc	a0,0x6
    80001434:	d1850513          	addi	a0,a0,-744 # 80007148 <etext+0x148>
    80001438:	bb8ff0ef          	jal	800007f0 <panic>

000000008000143c <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    8000143c:	1141                	addi	sp,sp,-16
    8000143e:	e406                	sd	ra,8(sp)
    80001440:	e022                	sd	s0,0(sp)
    80001442:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001444:	4601                	li	a2,0
    80001446:	a85ff0ef          	jal	80000eca <walk>
  if (pte == 0) {
    8000144a:	c519                	beqz	a0,80001458 <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V) {
    8000144c:	6108                	ld	a0,0(a0)
    8000144e:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001450:	60a2                	ld	ra,8(sp)
    80001452:	6402                	ld	s0,0(sp)
    80001454:	0141                	addi	sp,sp,16
    80001456:	8082                	ret
    return 0;
    80001458:	4501                	li	a0,0
    8000145a:	bfdd                	j	80001450 <ismapped+0x14>

000000008000145c <vmfault>:
{
    8000145c:	7179                	addi	sp,sp,-48
    8000145e:	f406                	sd	ra,40(sp)
    80001460:	f022                	sd	s0,32(sp)
    80001462:	e44e                	sd	s3,8(sp)
    80001464:	1800                	addi	s0,sp,48
    return 0;
    80001466:	4981                	li	s3,0
  if (va >= psz)
    80001468:	00b66863          	bltu	a2,a1,80001478 <vmfault+0x1c>
}
    8000146c:	854e                	mv	a0,s3
    8000146e:	70a2                	ld	ra,40(sp)
    80001470:	7402                	ld	s0,32(sp)
    80001472:	69a2                	ld	s3,8(sp)
    80001474:	6145                	addi	sp,sp,48
    80001476:	8082                	ret
    80001478:	ec26                	sd	s1,24(sp)
    8000147a:	e84a                	sd	s2,16(sp)
    8000147c:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000147e:	77fd                	lui	a5,0xfffff
    80001480:	00f674b3          	and	s1,a2,a5
  if (ismapped(pagetable, va)) {
    80001484:	85a6                	mv	a1,s1
    80001486:	fb7ff0ef          	jal	8000143c <ismapped>
    return 0;
    8000148a:	4981                	li	s3,0
  if (ismapped(pagetable, va)) {
    8000148c:	c501                	beqz	a0,80001494 <vmfault+0x38>
    8000148e:	64e2                	ld	s1,24(sp)
    80001490:	6942                	ld	s2,16(sp)
    80001492:	bfe9                	j	8000146c <vmfault+0x10>
    80001494:	e052                	sd	s4,0(sp)
  mem = (uint64)kalloc();
    80001496:	e34ff0ef          	jal	80000aca <kalloc>
    8000149a:	8a2a                	mv	s4,a0
  if (mem == 0)
    8000149c:	c915                	beqz	a0,800014d0 <vmfault+0x74>
  mem = (uint64)kalloc();
    8000149e:	89aa                	mv	s3,a0
  memset((void *)mem, 0, PGSIZE);
    800014a0:	6605                	lui	a2,0x1
    800014a2:	4581                	li	a1,0
    800014a4:	fb0ff0ef          	jal	80000c54 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    800014a8:	4759                	li	a4,22
    800014aa:	86d2                	mv	a3,s4
    800014ac:	6605                	lui	a2,0x1
    800014ae:	85a6                	mv	a1,s1
    800014b0:	854a                	mv	a0,s2
    800014b2:	af1ff0ef          	jal	80000fa2 <mappages>
    800014b6:	e509                	bnez	a0,800014c0 <vmfault+0x64>
    800014b8:	64e2                	ld	s1,24(sp)
    800014ba:	6942                	ld	s2,16(sp)
    800014bc:	6a02                	ld	s4,0(sp)
    800014be:	b77d                	j	8000146c <vmfault+0x10>
    kfree((void *)mem);
    800014c0:	8552                	mv	a0,s4
    800014c2:	d26ff0ef          	jal	800009e8 <kfree>
    return 0;
    800014c6:	4981                	li	s3,0
    800014c8:	64e2                	ld	s1,24(sp)
    800014ca:	6942                	ld	s2,16(sp)
    800014cc:	6a02                	ld	s4,0(sp)
    800014ce:	bf79                	j	8000146c <vmfault+0x10>
    800014d0:	64e2                	ld	s1,24(sp)
    800014d2:	6942                	ld	s2,16(sp)
    800014d4:	6a02                	ld	s4,0(sp)
    800014d6:	bf59                	j	8000146c <vmfault+0x10>

00000000800014d8 <copyout>:
  while (len > 0) {
    800014d8:	c745                	beqz	a4,80001580 <copyout+0xa8>
{
    800014da:	7159                	addi	sp,sp,-112
    800014dc:	f486                	sd	ra,104(sp)
    800014de:	f0a2                	sd	s0,96(sp)
    800014e0:	eca6                	sd	s1,88(sp)
    800014e2:	e0d2                	sd	s4,64(sp)
    800014e4:	f85a                	sd	s6,48(sp)
    800014e6:	f45e                	sd	s7,40(sp)
    800014e8:	f062                	sd	s8,32(sp)
    800014ea:	e46e                	sd	s11,8(sp)
    800014ec:	1880                	addi	s0,sp,112
    800014ee:	8c2a                	mv	s8,a0
    800014f0:	8dae                	mv	s11,a1
    800014f2:	8b32                	mv	s6,a2
    800014f4:	8bb6                	mv	s7,a3
    800014f6:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(dstva);
    800014f8:	74fd                	lui	s1,0xfffff
    800014fa:	8cf1                	and	s1,s1,a2
    if (va0 >= MAXVA)
    800014fc:	57fd                	li	a5,-1
    800014fe:	83e9                	srli	a5,a5,0x1a
    80001500:	0897e263          	bltu	a5,s1,80001584 <copyout+0xac>
    80001504:	e8ca                	sd	s2,80(sp)
    80001506:	e4ce                	sd	s3,72(sp)
    80001508:	fc56                	sd	s5,56(sp)
    8000150a:	ec66                	sd	s9,24(sp)
    8000150c:	e86a                	sd	s10,16(sp)
    8000150e:	6d05                	lui	s10,0x1
    80001510:	8cbe                	mv	s9,a5
    80001512:	a015                	j	80001536 <copyout+0x5e>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001514:	409b0533          	sub	a0,s6,s1
    80001518:	0009861b          	sext.w	a2,s3
    8000151c:	85de                	mv	a1,s7
    8000151e:	954a                	add	a0,a0,s2
    80001520:	f90ff0ef          	jal	80000cb0 <memmove>
    len -= n;
    80001524:	413a0a33          	sub	s4,s4,s3
    src += n;
    80001528:	9bce                	add	s7,s7,s3
  while (len > 0) {
    8000152a:	040a0463          	beqz	s4,80001572 <copyout+0x9a>
    if (va0 >= MAXVA)
    8000152e:	055ced63          	bltu	s9,s5,80001588 <copyout+0xb0>
    80001532:	84d6                	mv	s1,s5
    80001534:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001536:	85a6                	mv	a1,s1
    80001538:	8562                	mv	a0,s8
    8000153a:	a2bff0ef          	jal	80000f64 <walkaddr>
    8000153e:	892a                	mv	s2,a0
    if (pa0 == 0) {
    80001540:	e909                	bnez	a0,80001552 <copyout+0x7a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    80001542:	4681                	li	a3,0
    80001544:	8626                	mv	a2,s1
    80001546:	85ee                	mv	a1,s11
    80001548:	8562                	mv	a0,s8
    8000154a:	f13ff0ef          	jal	8000145c <vmfault>
    8000154e:	892a                	mv	s2,a0
    80001550:	c139                	beqz	a0,80001596 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    80001552:	4601                	li	a2,0
    80001554:	85a6                	mv	a1,s1
    80001556:	8562                	mv	a0,s8
    80001558:	973ff0ef          	jal	80000eca <walk>
    if ((*pte & PTE_W) == 0)
    8000155c:	611c                	ld	a5,0(a0)
    8000155e:	8b91                	andi	a5,a5,4
    80001560:	c3b1                	beqz	a5,800015a4 <copyout+0xcc>
    n = PGSIZE - (dstva - va0);
    80001562:	01a48ab3          	add	s5,s1,s10
    80001566:	416a89b3          	sub	s3,s5,s6
    if (n > len)
    8000156a:	fb3a75e3          	bgeu	s4,s3,80001514 <copyout+0x3c>
    8000156e:	89d2                	mv	s3,s4
    80001570:	b755                	j	80001514 <copyout+0x3c>
  return 0;
    80001572:	4501                	li	a0,0
    80001574:	6946                	ld	s2,80(sp)
    80001576:	69a6                	ld	s3,72(sp)
    80001578:	7ae2                	ld	s5,56(sp)
    8000157a:	6ce2                	ld	s9,24(sp)
    8000157c:	6d42                	ld	s10,16(sp)
    8000157e:	a80d                	j	800015b0 <copyout+0xd8>
    80001580:	4501                	li	a0,0
}
    80001582:	8082                	ret
      return -1;
    80001584:	557d                	li	a0,-1
    80001586:	a02d                	j	800015b0 <copyout+0xd8>
    80001588:	557d                	li	a0,-1
    8000158a:	6946                	ld	s2,80(sp)
    8000158c:	69a6                	ld	s3,72(sp)
    8000158e:	7ae2                	ld	s5,56(sp)
    80001590:	6ce2                	ld	s9,24(sp)
    80001592:	6d42                	ld	s10,16(sp)
    80001594:	a831                	j	800015b0 <copyout+0xd8>
        return -1;
    80001596:	557d                	li	a0,-1
    80001598:	6946                	ld	s2,80(sp)
    8000159a:	69a6                	ld	s3,72(sp)
    8000159c:	7ae2                	ld	s5,56(sp)
    8000159e:	6ce2                	ld	s9,24(sp)
    800015a0:	6d42                	ld	s10,16(sp)
    800015a2:	a039                	j	800015b0 <copyout+0xd8>
      return -1;
    800015a4:	557d                	li	a0,-1
    800015a6:	6946                	ld	s2,80(sp)
    800015a8:	69a6                	ld	s3,72(sp)
    800015aa:	7ae2                	ld	s5,56(sp)
    800015ac:	6ce2                	ld	s9,24(sp)
    800015ae:	6d42                	ld	s10,16(sp)
}
    800015b0:	70a6                	ld	ra,104(sp)
    800015b2:	7406                	ld	s0,96(sp)
    800015b4:	64e6                	ld	s1,88(sp)
    800015b6:	6a06                	ld	s4,64(sp)
    800015b8:	7b42                	ld	s6,48(sp)
    800015ba:	7ba2                	ld	s7,40(sp)
    800015bc:	7c02                	ld	s8,32(sp)
    800015be:	6da2                	ld	s11,8(sp)
    800015c0:	6165                	addi	sp,sp,112
    800015c2:	8082                	ret

00000000800015c4 <copyin>:
  while (len > 0) {
    800015c4:	cb49                	beqz	a4,80001656 <copyin+0x92>
{
    800015c6:	711d                	addi	sp,sp,-96
    800015c8:	ec86                	sd	ra,88(sp)
    800015ca:	e8a2                	sd	s0,80(sp)
    800015cc:	e4a6                	sd	s1,72(sp)
    800015ce:	e0ca                	sd	s2,64(sp)
    800015d0:	fc4e                	sd	s3,56(sp)
    800015d2:	f852                	sd	s4,48(sp)
    800015d4:	f456                	sd	s5,40(sp)
    800015d6:	f05a                	sd	s6,32(sp)
    800015d8:	ec5e                	sd	s7,24(sp)
    800015da:	e862                	sd	s8,16(sp)
    800015dc:	e466                	sd	s9,8(sp)
    800015de:	1080                	addi	s0,sp,96
    800015e0:	8baa                	mv	s7,a0
    800015e2:	8cae                	mv	s9,a1
    800015e4:	8ab2                	mv	s5,a2
    800015e6:	8936                	mv	s2,a3
    800015e8:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800015ea:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800015ec:	6b05                	lui	s6,0x1
    800015ee:	a035                	j	8000161a <copyin+0x56>
    800015f0:	412984b3          	sub	s1,s3,s2
    800015f4:	94da                	add	s1,s1,s6
    if (n > len)
    800015f6:	009a7363          	bgeu	s4,s1,800015fc <copyin+0x38>
    800015fa:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800015fc:	413905b3          	sub	a1,s2,s3
    80001600:	0004861b          	sext.w	a2,s1
    80001604:	95aa                	add	a1,a1,a0
    80001606:	8556                	mv	a0,s5
    80001608:	ea8ff0ef          	jal	80000cb0 <memmove>
    len -= n;
    8000160c:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001610:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001612:	01698933          	add	s2,s3,s6
  while (len > 0) {
    80001616:	020a0263          	beqz	s4,8000163a <copyin+0x76>
    va0 = PGROUNDDOWN(srcva);
    8000161a:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000161e:	85ce                	mv	a1,s3
    80001620:	855e                	mv	a0,s7
    80001622:	943ff0ef          	jal	80000f64 <walkaddr>
    if (pa0 == 0) {
    80001626:	f569                	bnez	a0,800015f0 <copyin+0x2c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001628:	4685                	li	a3,1
    8000162a:	864e                	mv	a2,s3
    8000162c:	85e6                	mv	a1,s9
    8000162e:	855e                	mv	a0,s7
    80001630:	e2dff0ef          	jal	8000145c <vmfault>
    80001634:	fd55                	bnez	a0,800015f0 <copyin+0x2c>
        return -1;
    80001636:	557d                	li	a0,-1
    80001638:	a011                	j	8000163c <copyin+0x78>
  return 0;
    8000163a:	4501                	li	a0,0
}
    8000163c:	60e6                	ld	ra,88(sp)
    8000163e:	6446                	ld	s0,80(sp)
    80001640:	64a6                	ld	s1,72(sp)
    80001642:	6906                	ld	s2,64(sp)
    80001644:	79e2                	ld	s3,56(sp)
    80001646:	7a42                	ld	s4,48(sp)
    80001648:	7aa2                	ld	s5,40(sp)
    8000164a:	7b02                	ld	s6,32(sp)
    8000164c:	6be2                	ld	s7,24(sp)
    8000164e:	6c42                	ld	s8,16(sp)
    80001650:	6ca2                	ld	s9,8(sp)
    80001652:	6125                	addi	sp,sp,96
    80001654:	8082                	ret
  return 0;
    80001656:	4501                	li	a0,0
}
    80001658:	8082                	ret

000000008000165a <copyinstr>:
  while (got_null == 0 && max > 0) {
    8000165a:	c371                	beqz	a4,8000171e <copyinstr+0xc4>
{
    8000165c:	715d                	addi	sp,sp,-80
    8000165e:	e486                	sd	ra,72(sp)
    80001660:	e0a2                	sd	s0,64(sp)
    80001662:	fc26                	sd	s1,56(sp)
    80001664:	f84a                	sd	s2,48(sp)
    80001666:	f44e                	sd	s3,40(sp)
    80001668:	f052                	sd	s4,32(sp)
    8000166a:	ec56                	sd	s5,24(sp)
    8000166c:	e85a                	sd	s6,16(sp)
    8000166e:	e45e                	sd	s7,8(sp)
    80001670:	e062                	sd	s8,0(sp)
    80001672:	0880                	addi	s0,sp,80
    80001674:	8a2a                	mv	s4,a0
    80001676:	8b2e                	mv	s6,a1
    80001678:	8bb2                	mv	s7,a2
    8000167a:	8c36                	mv	s8,a3
    8000167c:	893a                	mv	s2,a4
    va0 = PGROUNDDOWN(srcva);
    8000167e:	7afd                	lui	s5,0xfffff
    n = PGSIZE - (srcva - va0);
    80001680:	6985                	lui	s3,0x1
    80001682:	a0b1                	j	800016ce <copyinstr+0x74>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001684:	4685                	li	a3,1
    80001686:	8626                	mv	a2,s1
    80001688:	85da                	mv	a1,s6
    8000168a:	8552                	mv	a0,s4
    8000168c:	dd1ff0ef          	jal	8000145c <vmfault>
    80001690:	e531                	bnez	a0,800016dc <copyinstr+0x82>
        return -1;
    80001692:	557d                	li	a0,-1
    80001694:	a039                	j	800016a2 <copyinstr+0x48>
        *dst = '\0';
    80001696:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb5e0>
    8000169a:	4785                	li	a5,1
  if (got_null) {
    8000169c:	37fd                	addiw	a5,a5,-1
    8000169e:	0007851b          	sext.w	a0,a5
}
    800016a2:	60a6                	ld	ra,72(sp)
    800016a4:	6406                	ld	s0,64(sp)
    800016a6:	74e2                	ld	s1,56(sp)
    800016a8:	7942                	ld	s2,48(sp)
    800016aa:	79a2                	ld	s3,40(sp)
    800016ac:	7a02                	ld	s4,32(sp)
    800016ae:	6ae2                	ld	s5,24(sp)
    800016b0:	6b42                	ld	s6,16(sp)
    800016b2:	6ba2                	ld	s7,8(sp)
    800016b4:	6c02                	ld	s8,0(sp)
    800016b6:	6161                	addi	sp,sp,80
    800016b8:	8082                	ret
    800016ba:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800016be:	972a                	add	a4,a4,a0
      --max;
    800016c0:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800016c4:	01348c33          	add	s8,s1,s3
  while (got_null == 0 && max > 0) {
    800016c8:	04e58563          	beq	a1,a4,80001712 <copyinstr+0xb8>
{
    800016cc:	8bbe                	mv	s7,a5
    va0 = PGROUNDDOWN(srcva);
    800016ce:	015c74b3          	and	s1,s8,s5
    pa0 = walkaddr(pagetable, va0);
    800016d2:	85a6                	mv	a1,s1
    800016d4:	8552                	mv	a0,s4
    800016d6:	88fff0ef          	jal	80000f64 <walkaddr>
    if (pa0 == 0) {
    800016da:	d54d                	beqz	a0,80001684 <copyinstr+0x2a>
    n = PGSIZE - (srcva - va0);
    800016dc:	41848633          	sub	a2,s1,s8
    800016e0:	964e                	add	a2,a2,s3
    if (n > max)
    800016e2:	00c97363          	bgeu	s2,a2,800016e8 <copyinstr+0x8e>
    800016e6:	864a                	mv	a2,s2
    char *p = (char *)(pa0 + (srcva - va0));
    800016e8:	409c0c33          	sub	s8,s8,s1
    800016ec:	9c2a                	add	s8,s8,a0
    while (n > 0) {
    800016ee:	c605                	beqz	a2,80001716 <copyinstr+0xbc>
    800016f0:	87de                	mv	a5,s7
    800016f2:	855e                	mv	a0,s7
      if (*p == '\0') {
    800016f4:	417c0733          	sub	a4,s8,s7
    while (n > 0) {
    800016f8:	965e                	add	a2,a2,s7
    800016fa:	85be                	mv	a1,a5
      if (*p == '\0') {
    800016fc:	00f706b3          	add	a3,a4,a5
    80001700:	0006c683          	lbu	a3,0(a3) # fffffffffffff000 <end+0xffffffff7ffdb5e0>
    80001704:	dac9                	beqz	a3,80001696 <copyinstr+0x3c>
        *dst = *p;
    80001706:	00d78023          	sb	a3,0(a5)
      dst++;
    8000170a:	0785                	addi	a5,a5,1
    while (n > 0) {
    8000170c:	fec797e3          	bne	a5,a2,800016fa <copyinstr+0xa0>
    80001710:	b76d                	j	800016ba <copyinstr+0x60>
    80001712:	4781                	li	a5,0
    80001714:	b761                	j	8000169c <copyinstr+0x42>
    srcva = va0 + PGSIZE;
    80001716:	6c05                	lui	s8,0x1
    80001718:	9c26                	add	s8,s8,s1
    8000171a:	87de                	mv	a5,s7
    8000171c:	bf45                	j	800016cc <copyinstr+0x72>
  int got_null = 0;
    8000171e:	4781                	li	a5,0
  if (got_null) {
    80001720:	37fd                	addiw	a5,a5,-1
    80001722:	0007851b          	sext.w	a0,a5
}
    80001726:	8082                	ret

0000000080001728 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001728:	7139                	addi	sp,sp,-64
    8000172a:	fc06                	sd	ra,56(sp)
    8000172c:	f822                	sd	s0,48(sp)
    8000172e:	f426                	sd	s1,40(sp)
    80001730:	f04a                	sd	s2,32(sp)
    80001732:	ec4e                	sd	s3,24(sp)
    80001734:	e852                	sd	s4,16(sp)
    80001736:	e456                	sd	s5,8(sp)
    80001738:	e05a                	sd	s6,0(sp)
    8000173a:	0080                	addi	s0,sp,64
    8000173c:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000173e:	00011497          	auipc	s1,0x11
    80001742:	10248493          	addi	s1,s1,258 # 80012840 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    80001746:	8b26                	mv	s6,s1
    80001748:	00a36937          	lui	s2,0xa36
    8000174c:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    80001750:	0932                	slli	s2,s2,0xc
    80001752:	46d90913          	addi	s2,s2,1133
    80001756:	0936                	slli	s2,s2,0xd
    80001758:	df590913          	addi	s2,s2,-523
    8000175c:	093a                	slli	s2,s2,0xe
    8000175e:	6cf90913          	addi	s2,s2,1743
    80001762:	040009b7          	lui	s3,0x4000
    80001766:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001768:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000176a:	00017a97          	auipc	s5,0x17
    8000176e:	ed6a8a93          	addi	s5,s5,-298 # 80018640 <tickslock>
    char *pa = kalloc();
    80001772:	b58ff0ef          	jal	80000aca <kalloc>
    80001776:	862a                	mv	a2,a0
    if (pa == 0)
    80001778:	cd15                	beqz	a0,800017b4 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int)(p - proc));
    8000177a:	416485b3          	sub	a1,s1,s6
    8000177e:	858d                	srai	a1,a1,0x3
    80001780:	032585b3          	mul	a1,a1,s2
    80001784:	2585                	addiw	a1,a1,1
    80001786:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000178a:	4719                	li	a4,6
    8000178c:	6685                	lui	a3,0x1
    8000178e:	40b985b3          	sub	a1,s3,a1
    80001792:	8552                	mv	a0,s4
    80001794:	8bfff0ef          	jal	80001052 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001798:	17848493          	addi	s1,s1,376
    8000179c:	fd549be3          	bne	s1,s5,80001772 <proc_mapstacks+0x4a>
  }
}
    800017a0:	70e2                	ld	ra,56(sp)
    800017a2:	7442                	ld	s0,48(sp)
    800017a4:	74a2                	ld	s1,40(sp)
    800017a6:	7902                	ld	s2,32(sp)
    800017a8:	69e2                	ld	s3,24(sp)
    800017aa:	6a42                	ld	s4,16(sp)
    800017ac:	6aa2                	ld	s5,8(sp)
    800017ae:	6b02                	ld	s6,0(sp)
    800017b0:	6121                	addi	sp,sp,64
    800017b2:	8082                	ret
      panic("kalloc");
    800017b4:	00006517          	auipc	a0,0x6
    800017b8:	9a450513          	addi	a0,a0,-1628 # 80007158 <etext+0x158>
    800017bc:	834ff0ef          	jal	800007f0 <panic>

00000000800017c0 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017c0:	7139                	addi	sp,sp,-64
    800017c2:	fc06                	sd	ra,56(sp)
    800017c4:	f822                	sd	s0,48(sp)
    800017c6:	f426                	sd	s1,40(sp)
    800017c8:	f04a                	sd	s2,32(sp)
    800017ca:	ec4e                	sd	s3,24(sp)
    800017cc:	e852                	sd	s4,16(sp)
    800017ce:	e456                	sd	s5,8(sp)
    800017d0:	e05a                	sd	s6,0(sp)
    800017d2:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800017d4:	00006597          	auipc	a1,0x6
    800017d8:	98c58593          	addi	a1,a1,-1652 # 80007160 <etext+0x160>
    800017dc:	00011517          	auipc	a0,0x11
    800017e0:	c3450513          	addi	a0,a0,-972 # 80012410 <pid_lock>
    800017e4:	b36ff0ef          	jal	80000b1a <initlock>
  initlock(&wait_lock, "wait_lock");
    800017e8:	00006597          	auipc	a1,0x6
    800017ec:	98058593          	addi	a1,a1,-1664 # 80007168 <etext+0x168>
    800017f0:	00011517          	auipc	a0,0x11
    800017f4:	c3850513          	addi	a0,a0,-968 # 80012428 <wait_lock>
    800017f8:	b22ff0ef          	jal	80000b1a <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017fc:	00011497          	auipc	s1,0x11
    80001800:	04448493          	addi	s1,s1,68 # 80012840 <proc>
    initlock(&p->lock, "proc");
    80001804:	00006b17          	auipc	s6,0x6
    80001808:	974b0b13          	addi	s6,s6,-1676 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    8000180c:	8aa6                	mv	s5,s1
    8000180e:	00a36937          	lui	s2,0xa36
    80001812:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    80001816:	0932                	slli	s2,s2,0xc
    80001818:	46d90913          	addi	s2,s2,1133
    8000181c:	0936                	slli	s2,s2,0xd
    8000181e:	df590913          	addi	s2,s2,-523
    80001822:	093a                	slli	s2,s2,0xe
    80001824:	6cf90913          	addi	s2,s2,1743
    80001828:	040009b7          	lui	s3,0x4000
    8000182c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000182e:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001830:	00017a17          	auipc	s4,0x17
    80001834:	e10a0a13          	addi	s4,s4,-496 # 80018640 <tickslock>
    initlock(&p->lock, "proc");
    80001838:	85da                	mv	a1,s6
    8000183a:	8526                	mv	a0,s1
    8000183c:	adeff0ef          	jal	80000b1a <initlock>
    p->state = UNUSED;
    80001840:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    80001844:	415487b3          	sub	a5,s1,s5
    80001848:	878d                	srai	a5,a5,0x3
    8000184a:	032787b3          	mul	a5,a5,s2
    8000184e:	2785                	addiw	a5,a5,1
    80001850:	00d7979b          	slliw	a5,a5,0xd
    80001854:	40f987b3          	sub	a5,s3,a5
    80001858:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    8000185a:	17848493          	addi	s1,s1,376
    8000185e:	fd449de3          	bne	s1,s4,80001838 <procinit+0x78>
  }
}
    80001862:	70e2                	ld	ra,56(sp)
    80001864:	7442                	ld	s0,48(sp)
    80001866:	74a2                	ld	s1,40(sp)
    80001868:	7902                	ld	s2,32(sp)
    8000186a:	69e2                	ld	s3,24(sp)
    8000186c:	6a42                	ld	s4,16(sp)
    8000186e:	6aa2                	ld	s5,8(sp)
    80001870:	6b02                	ld	s6,0(sp)
    80001872:	6121                	addi	sp,sp,64
    80001874:	8082                	ret

0000000080001876 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001876:	1141                	addi	sp,sp,-16
    80001878:	e422                	sd	s0,8(sp)
    8000187a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    8000187c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    8000187e:	2501                	sext.w	a0,a0
    80001880:	6422                	ld	s0,8(sp)
    80001882:	0141                	addi	sp,sp,16
    80001884:	8082                	ret

0000000080001886 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    80001886:	1141                	addi	sp,sp,-16
    80001888:	e422                	sd	s0,8(sp)
    8000188a:	0800                	addi	s0,sp,16
    8000188c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000188e:	2781                	sext.w	a5,a5
    80001890:	079e                	slli	a5,a5,0x7
  return c;
}
    80001892:	00011517          	auipc	a0,0x11
    80001896:	bae50513          	addi	a0,a0,-1106 # 80012440 <cpus>
    8000189a:	953e                	add	a0,a0,a5
    8000189c:	6422                	ld	s0,8(sp)
    8000189e:	0141                	addi	sp,sp,16
    800018a0:	8082                	ret

00000000800018a2 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800018a2:	1101                	addi	sp,sp,-32
    800018a4:	ec06                	sd	ra,24(sp)
    800018a6:	e822                	sd	s0,16(sp)
    800018a8:	e426                	sd	s1,8(sp)
    800018aa:	1000                	addi	s0,sp,32
  push_off();
    800018ac:	aaeff0ef          	jal	80000b5a <push_off>
    800018b0:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018b2:	2781                	sext.w	a5,a5
    800018b4:	079e                	slli	a5,a5,0x7
    800018b6:	00011717          	auipc	a4,0x11
    800018ba:	b5a70713          	addi	a4,a4,-1190 # 80012410 <pid_lock>
    800018be:	97ba                	add	a5,a5,a4
    800018c0:	7b84                	ld	s1,48(a5)
  pop_off();
    800018c2:	b0eff0ef          	jal	80000bd0 <pop_off>
  return p;
}
    800018c6:	8526                	mv	a0,s1
    800018c8:	60e2                	ld	ra,24(sp)
    800018ca:	6442                	ld	s0,16(sp)
    800018cc:	64a2                	ld	s1,8(sp)
    800018ce:	6105                	addi	sp,sp,32
    800018d0:	8082                	ret

00000000800018d2 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018d2:	7179                	addi	sp,sp,-48
    800018d4:	f406                	sd	ra,40(sp)
    800018d6:	f022                	sd	s0,32(sp)
    800018d8:	ec26                	sd	s1,24(sp)
    800018da:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800018dc:	fc7ff0ef          	jal	800018a2 <myproc>
    800018e0:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    800018e2:	b3aff0ef          	jal	80000c1c <release>

  if (first) {
    800018e6:	00009797          	auipc	a5,0x9
    800018ea:	9ba7a783          	lw	a5,-1606(a5) # 8000a2a0 <first.1>
    800018ee:	cb9d                	beqz	a5,80001924 <forkret+0x52>
    first = 0;
    800018f0:	00009797          	auipc	a5,0x9
    800018f4:	9a07a823          	sw	zero,-1616(a5) # 8000a2a0 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800018f8:	4505                	li	a0,1
    800018fa:	57f010ef          	jal	80003678 <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    800018fe:	00006517          	auipc	a0,0x6
    80001902:	88250513          	addi	a0,a0,-1918 # 80007180 <etext+0x180>
    80001906:	fca43823          	sd	a0,-48(s0)
    8000190a:	fc043c23          	sd	zero,-40(s0)
    8000190e:	fd040593          	addi	a1,s0,-48
    80001912:	76f020ef          	jal	80004880 <kexec>
    80001916:	6cbc                	ld	a5,88(s1)
    80001918:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000191a:	6cbc                	ld	a5,88(s1)
    8000191c:	7bb8                	ld	a4,112(a5)
    8000191e:	57fd                	li	a5,-1
    80001920:	02f70d63          	beq	a4,a5,8000195a <forkret+0x88>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001924:	3ff000ef          	jal	80002522 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001928:	68a8                	ld	a0,80(s1)
    8000192a:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000192c:	04000737          	lui	a4,0x4000
    80001930:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001932:	0732                	slli	a4,a4,0xc
    80001934:	00004797          	auipc	a5,0x4
    80001938:	76878793          	addi	a5,a5,1896 # 8000609c <userret>
    8000193c:	00004697          	auipc	a3,0x4
    80001940:	6c468693          	addi	a3,a3,1732 # 80006000 <_trampoline>
    80001944:	8f95                	sub	a5,a5,a3
    80001946:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001948:	577d                	li	a4,-1
    8000194a:	177e                	slli	a4,a4,0x3f
    8000194c:	8d59                	or	a0,a0,a4
    8000194e:	9782                	jalr	a5
}
    80001950:	70a2                	ld	ra,40(sp)
    80001952:	7402                	ld	s0,32(sp)
    80001954:	64e2                	ld	s1,24(sp)
    80001956:	6145                	addi	sp,sp,48
    80001958:	8082                	ret
      panic("exec");
    8000195a:	00006517          	auipc	a0,0x6
    8000195e:	82e50513          	addi	a0,a0,-2002 # 80007188 <etext+0x188>
    80001962:	e8ffe0ef          	jal	800007f0 <panic>

0000000080001966 <allocpid>:
{
    80001966:	1101                	addi	sp,sp,-32
    80001968:	ec06                	sd	ra,24(sp)
    8000196a:	e822                	sd	s0,16(sp)
    8000196c:	e426                	sd	s1,8(sp)
    8000196e:	e04a                	sd	s2,0(sp)
    80001970:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001972:	00011917          	auipc	s2,0x11
    80001976:	a9e90913          	addi	s2,s2,-1378 # 80012410 <pid_lock>
    8000197a:	854a                	mv	a0,s2
    8000197c:	a14ff0ef          	jal	80000b90 <acquire>
  pid = nextpid;
    80001980:	00009797          	auipc	a5,0x9
    80001984:	92478793          	addi	a5,a5,-1756 # 8000a2a4 <nextpid>
    80001988:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    8000198a:	0014871b          	addiw	a4,s1,1
    8000198e:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001990:	854a                	mv	a0,s2
    80001992:	a8aff0ef          	jal	80000c1c <release>
}
    80001996:	8526                	mv	a0,s1
    80001998:	60e2                	ld	ra,24(sp)
    8000199a:	6442                	ld	s0,16(sp)
    8000199c:	64a2                	ld	s1,8(sp)
    8000199e:	6902                	ld	s2,0(sp)
    800019a0:	6105                	addi	sp,sp,32
    800019a2:	8082                	ret

00000000800019a4 <proc_pagetable>:
{
    800019a4:	1101                	addi	sp,sp,-32
    800019a6:	ec06                	sd	ra,24(sp)
    800019a8:	e822                	sd	s0,16(sp)
    800019aa:	e426                	sd	s1,8(sp)
    800019ac:	e04a                	sd	s2,0(sp)
    800019ae:	1000                	addi	s0,sp,32
    800019b0:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019b2:	f96ff0ef          	jal	80001148 <uvmcreate>
    800019b6:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800019b8:	cd05                	beqz	a0,800019f0 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    800019ba:	4729                	li	a4,10
    800019bc:	00004697          	auipc	a3,0x4
    800019c0:	64468693          	addi	a3,a3,1604 # 80006000 <_trampoline>
    800019c4:	6605                	lui	a2,0x1
    800019c6:	040005b7          	lui	a1,0x4000
    800019ca:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019cc:	05b2                	slli	a1,a1,0xc
    800019ce:	dd4ff0ef          	jal	80000fa2 <mappages>
    800019d2:	02054663          	bltz	a0,800019fe <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    800019d6:	4719                	li	a4,6
    800019d8:	05893683          	ld	a3,88(s2)
    800019dc:	6605                	lui	a2,0x1
    800019de:	020005b7          	lui	a1,0x2000
    800019e2:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800019e4:	05b6                	slli	a1,a1,0xd
    800019e6:	8526                	mv	a0,s1
    800019e8:	dbaff0ef          	jal	80000fa2 <mappages>
    800019ec:	00054f63          	bltz	a0,80001a0a <proc_pagetable+0x66>
}
    800019f0:	8526                	mv	a0,s1
    800019f2:	60e2                	ld	ra,24(sp)
    800019f4:	6442                	ld	s0,16(sp)
    800019f6:	64a2                	ld	s1,8(sp)
    800019f8:	6902                	ld	s2,0(sp)
    800019fa:	6105                	addi	sp,sp,32
    800019fc:	8082                	ret
    uvmfree(pagetable, 0);
    800019fe:	4581                	li	a1,0
    80001a00:	8526                	mv	a0,s1
    80001a02:	941ff0ef          	jal	80001342 <uvmfree>
    return 0;
    80001a06:	4481                	li	s1,0
    80001a08:	b7e5                	j	800019f0 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a0a:	4681                	li	a3,0
    80001a0c:	4605                	li	a2,1
    80001a0e:	040005b7          	lui	a1,0x4000
    80001a12:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a14:	05b2                	slli	a1,a1,0xc
    80001a16:	8526                	mv	a0,s1
    80001a18:	f56ff0ef          	jal	8000116e <uvmunmap>
    uvmfree(pagetable, 0);
    80001a1c:	4581                	li	a1,0
    80001a1e:	8526                	mv	a0,s1
    80001a20:	923ff0ef          	jal	80001342 <uvmfree>
    return 0;
    80001a24:	4481                	li	s1,0
    80001a26:	b7e9                	j	800019f0 <proc_pagetable+0x4c>

0000000080001a28 <proc_freepagetable>:
{
    80001a28:	1101                	addi	sp,sp,-32
    80001a2a:	ec06                	sd	ra,24(sp)
    80001a2c:	e822                	sd	s0,16(sp)
    80001a2e:	e426                	sd	s1,8(sp)
    80001a30:	e04a                	sd	s2,0(sp)
    80001a32:	1000                	addi	s0,sp,32
    80001a34:	84aa                	mv	s1,a0
    80001a36:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a38:	4681                	li	a3,0
    80001a3a:	4605                	li	a2,1
    80001a3c:	040005b7          	lui	a1,0x4000
    80001a40:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a42:	05b2                	slli	a1,a1,0xc
    80001a44:	f2aff0ef          	jal	8000116e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a48:	4681                	li	a3,0
    80001a4a:	4605                	li	a2,1
    80001a4c:	020005b7          	lui	a1,0x2000
    80001a50:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a52:	05b6                	slli	a1,a1,0xd
    80001a54:	8526                	mv	a0,s1
    80001a56:	f18ff0ef          	jal	8000116e <uvmunmap>
  uvmfree(pagetable, sz);
    80001a5a:	85ca                	mv	a1,s2
    80001a5c:	8526                	mv	a0,s1
    80001a5e:	8e5ff0ef          	jal	80001342 <uvmfree>
}
    80001a62:	60e2                	ld	ra,24(sp)
    80001a64:	6442                	ld	s0,16(sp)
    80001a66:	64a2                	ld	s1,8(sp)
    80001a68:	6902                	ld	s2,0(sp)
    80001a6a:	6105                	addi	sp,sp,32
    80001a6c:	8082                	ret

0000000080001a6e <freeproc>:
{
    80001a6e:	1101                	addi	sp,sp,-32
    80001a70:	ec06                	sd	ra,24(sp)
    80001a72:	e822                	sd	s0,16(sp)
    80001a74:	e426                	sd	s1,8(sp)
    80001a76:	1000                	addi	s0,sp,32
    80001a78:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001a7a:	6d28                	ld	a0,88(a0)
    80001a7c:	c119                	beqz	a0,80001a82 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001a7e:	f6bfe0ef          	jal	800009e8 <kfree>
  p->trapframe = 0;
    80001a82:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001a86:	68a8                	ld	a0,80(s1)
    80001a88:	c501                	beqz	a0,80001a90 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a8a:	64ac                	ld	a1,72(s1)
    80001a8c:	f9dff0ef          	jal	80001a28 <proc_freepagetable>
  p->pagetable = 0;
    80001a90:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a94:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a98:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001a9c:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001aa0:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001aa4:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001aa8:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001aac:	0004ac23          	sw	zero,24(s1)
}
    80001ab0:	60e2                	ld	ra,24(sp)
    80001ab2:	6442                	ld	s0,16(sp)
    80001ab4:	64a2                	ld	s1,8(sp)
    80001ab6:	6105                	addi	sp,sp,32
    80001ab8:	8082                	ret

0000000080001aba <allocproc>:
{
    80001aba:	1101                	addi	sp,sp,-32
    80001abc:	ec06                	sd	ra,24(sp)
    80001abe:	e822                	sd	s0,16(sp)
    80001ac0:	e426                	sd	s1,8(sp)
    80001ac2:	e04a                	sd	s2,0(sp)
    80001ac4:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ac6:	00011497          	auipc	s1,0x11
    80001aca:	d7a48493          	addi	s1,s1,-646 # 80012840 <proc>
    80001ace:	00017917          	auipc	s2,0x17
    80001ad2:	b7290913          	addi	s2,s2,-1166 # 80018640 <tickslock>
    acquire(&p->lock);
    80001ad6:	8526                	mv	a0,s1
    80001ad8:	8b8ff0ef          	jal	80000b90 <acquire>
    if (p->state == UNUSED) {
    80001adc:	4c9c                	lw	a5,24(s1)
    80001ade:	cb91                	beqz	a5,80001af2 <allocproc+0x38>
      release(&p->lock);
    80001ae0:	8526                	mv	a0,s1
    80001ae2:	93aff0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ae6:	17848493          	addi	s1,s1,376
    80001aea:	ff2496e3          	bne	s1,s2,80001ad6 <allocproc+0x1c>
  return 0;
    80001aee:	4481                	li	s1,0
    80001af0:	a881                	j	80001b40 <allocproc+0x86>
      p->runtime = 0; //would this just be for unused or also locks...hmm
    80001af2:	1604a423          	sw	zero,360(s1)
      p->stride = 1;
    80001af6:	4905                	li	s2,1
    80001af8:	1724a823          	sw	s2,368(s1)
      p->pass = 0;
    80001afc:	1604a623          	sw	zero,364(s1)
  p->pid = allocpid();
    80001b00:	e67ff0ef          	jal	80001966 <allocpid>
    80001b04:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b06:	0124ac23          	sw	s2,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b0a:	fc1fe0ef          	jal	80000aca <kalloc>
    80001b0e:	892a                	mv	s2,a0
    80001b10:	eca8                	sd	a0,88(s1)
    80001b12:	cd15                	beqz	a0,80001b4e <allocproc+0x94>
  p->pagetable = proc_pagetable(p);
    80001b14:	8526                	mv	a0,s1
    80001b16:	e8fff0ef          	jal	800019a4 <proc_pagetable>
    80001b1a:	892a                	mv	s2,a0
    80001b1c:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b1e:	c121                	beqz	a0,80001b5e <allocproc+0xa4>
  memset(&p->context, 0, sizeof(p->context));
    80001b20:	07000613          	li	a2,112
    80001b24:	4581                	li	a1,0
    80001b26:	06048513          	addi	a0,s1,96
    80001b2a:	92aff0ef          	jal	80000c54 <memset>
  p->context.ra = (uint64)forkret;
    80001b2e:	00000797          	auipc	a5,0x0
    80001b32:	da478793          	addi	a5,a5,-604 # 800018d2 <forkret>
    80001b36:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b38:	60bc                	ld	a5,64(s1)
    80001b3a:	6705                	lui	a4,0x1
    80001b3c:	97ba                	add	a5,a5,a4
    80001b3e:	f4bc                	sd	a5,104(s1)
}
    80001b40:	8526                	mv	a0,s1
    80001b42:	60e2                	ld	ra,24(sp)
    80001b44:	6442                	ld	s0,16(sp)
    80001b46:	64a2                	ld	s1,8(sp)
    80001b48:	6902                	ld	s2,0(sp)
    80001b4a:	6105                	addi	sp,sp,32
    80001b4c:	8082                	ret
    freeproc(p);
    80001b4e:	8526                	mv	a0,s1
    80001b50:	f1fff0ef          	jal	80001a6e <freeproc>
    release(&p->lock);
    80001b54:	8526                	mv	a0,s1
    80001b56:	8c6ff0ef          	jal	80000c1c <release>
    return 0;
    80001b5a:	84ca                	mv	s1,s2
    80001b5c:	b7d5                	j	80001b40 <allocproc+0x86>
    freeproc(p);
    80001b5e:	8526                	mv	a0,s1
    80001b60:	f0fff0ef          	jal	80001a6e <freeproc>
    release(&p->lock);
    80001b64:	8526                	mv	a0,s1
    80001b66:	8b6ff0ef          	jal	80000c1c <release>
    return 0;
    80001b6a:	84ca                	mv	s1,s2
    80001b6c:	bfd1                	j	80001b40 <allocproc+0x86>

0000000080001b6e <userinit>:
{
    80001b6e:	1101                	addi	sp,sp,-32
    80001b70:	ec06                	sd	ra,24(sp)
    80001b72:	e822                	sd	s0,16(sp)
    80001b74:	e426                	sd	s1,8(sp)
    80001b76:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b78:	f43ff0ef          	jal	80001aba <allocproc>
    80001b7c:	84aa                	mv	s1,a0
  initproc = p;
    80001b7e:	00008797          	auipc	a5,0x8
    80001b82:	76a7b523          	sd	a0,1898(a5) # 8000a2e8 <initproc>
  p->cwd = namei("/");
    80001b86:	00005517          	auipc	a0,0x5
    80001b8a:	60a50513          	addi	a0,a0,1546 # 80007190 <etext+0x190>
    80001b8e:	022020ef          	jal	80003bb0 <namei>
    80001b92:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001b96:	478d                	li	a5,3
    80001b98:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001b9a:	8526                	mv	a0,s1
    80001b9c:	880ff0ef          	jal	80000c1c <release>
}
    80001ba0:	60e2                	ld	ra,24(sp)
    80001ba2:	6442                	ld	s0,16(sp)
    80001ba4:	64a2                	ld	s1,8(sp)
    80001ba6:	6105                	addi	sp,sp,32
    80001ba8:	8082                	ret

0000000080001baa <growproc>:
{
    80001baa:	1101                	addi	sp,sp,-32
    80001bac:	ec06                	sd	ra,24(sp)
    80001bae:	e822                	sd	s0,16(sp)
    80001bb0:	e426                	sd	s1,8(sp)
    80001bb2:	e04a                	sd	s2,0(sp)
    80001bb4:	1000                	addi	s0,sp,32
    80001bb6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bb8:	cebff0ef          	jal	800018a2 <myproc>
    80001bbc:	892a                	mv	s2,a0
  sz = p->sz;
    80001bbe:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001bc0:	02905963          	blez	s1,80001bf2 <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001bc4:	00b48633          	add	a2,s1,a1
    80001bc8:	020007b7          	lui	a5,0x2000
    80001bcc:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001bce:	07b6                	slli	a5,a5,0xd
    80001bd0:	02c7ea63          	bltu	a5,a2,80001c04 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001bd4:	4691                	li	a3,4
    80001bd6:	6928                	ld	a0,80(a0)
    80001bd8:	e64ff0ef          	jal	8000123c <uvmalloc>
    80001bdc:	85aa                	mv	a1,a0
    80001bde:	c50d                	beqz	a0,80001c08 <growproc+0x5e>
  p->sz = sz;
    80001be0:	04b93423          	sd	a1,72(s2)
  return 0;
    80001be4:	4501                	li	a0,0
}
    80001be6:	60e2                	ld	ra,24(sp)
    80001be8:	6442                	ld	s0,16(sp)
    80001bea:	64a2                	ld	s1,8(sp)
    80001bec:	6902                	ld	s2,0(sp)
    80001bee:	6105                	addi	sp,sp,32
    80001bf0:	8082                	ret
  } else if (n < 0) {
    80001bf2:	fe04d7e3          	bgez	s1,80001be0 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001bf6:	00b48633          	add	a2,s1,a1
    80001bfa:	6928                	ld	a0,80(a0)
    80001bfc:	dfcff0ef          	jal	800011f8 <uvmdealloc>
    80001c00:	85aa                	mv	a1,a0
    80001c02:	bff9                	j	80001be0 <growproc+0x36>
      return -1;
    80001c04:	557d                	li	a0,-1
    80001c06:	b7c5                	j	80001be6 <growproc+0x3c>
      return -1;
    80001c08:	557d                	li	a0,-1
    80001c0a:	bff1                	j	80001be6 <growproc+0x3c>

0000000080001c0c <kfork>:
{
    80001c0c:	7139                	addi	sp,sp,-64
    80001c0e:	fc06                	sd	ra,56(sp)
    80001c10:	f822                	sd	s0,48(sp)
    80001c12:	f04a                	sd	s2,32(sp)
    80001c14:	e456                	sd	s5,8(sp)
    80001c16:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c18:	c8bff0ef          	jal	800018a2 <myproc>
    80001c1c:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c1e:	e9dff0ef          	jal	80001aba <allocproc>
    80001c22:	0e050a63          	beqz	a0,80001d16 <kfork+0x10a>
    80001c26:	e852                	sd	s4,16(sp)
    80001c28:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c2a:	048ab603          	ld	a2,72(s5)
    80001c2e:	692c                	ld	a1,80(a0)
    80001c30:	050ab503          	ld	a0,80(s5)
    80001c34:	f40ff0ef          	jal	80001374 <uvmcopy>
    80001c38:	04054a63          	bltz	a0,80001c8c <kfork+0x80>
    80001c3c:	f426                	sd	s1,40(sp)
    80001c3e:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c40:	048ab783          	ld	a5,72(s5)
    80001c44:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c48:	058ab683          	ld	a3,88(s5)
    80001c4c:	87b6                	mv	a5,a3
    80001c4e:	058a3703          	ld	a4,88(s4)
    80001c52:	12068693          	addi	a3,a3,288
    80001c56:	0007b803          	ld	a6,0(a5)
    80001c5a:	6788                	ld	a0,8(a5)
    80001c5c:	6b8c                	ld	a1,16(a5)
    80001c5e:	6f90                	ld	a2,24(a5)
    80001c60:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c64:	e708                	sd	a0,8(a4)
    80001c66:	eb0c                	sd	a1,16(a4)
    80001c68:	ef10                	sd	a2,24(a4)
    80001c6a:	02078793          	addi	a5,a5,32
    80001c6e:	02070713          	addi	a4,a4,32
    80001c72:	fed792e3          	bne	a5,a3,80001c56 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001c76:	058a3783          	ld	a5,88(s4)
    80001c7a:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001c7e:	0d0a8493          	addi	s1,s5,208
    80001c82:	0d0a0913          	addi	s2,s4,208
    80001c86:	150a8993          	addi	s3,s5,336
    80001c8a:	a831                	j	80001ca6 <kfork+0x9a>
    freeproc(np);
    80001c8c:	8552                	mv	a0,s4
    80001c8e:	de1ff0ef          	jal	80001a6e <freeproc>
    release(&np->lock);
    80001c92:	8552                	mv	a0,s4
    80001c94:	f89fe0ef          	jal	80000c1c <release>
    return -1;
    80001c98:	597d                	li	s2,-1
    80001c9a:	6a42                	ld	s4,16(sp)
    80001c9c:	a0b5                	j	80001d08 <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001c9e:	04a1                	addi	s1,s1,8
    80001ca0:	0921                	addi	s2,s2,8
    80001ca2:	01348963          	beq	s1,s3,80001cb4 <kfork+0xa8>
    if (p->ofile[i])
    80001ca6:	6088                	ld	a0,0(s1)
    80001ca8:	d97d                	beqz	a0,80001c9e <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001caa:	540020ef          	jal	800041ea <filedup>
    80001cae:	00a93023          	sd	a0,0(s2)
    80001cb2:	b7f5                	j	80001c9e <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001cb4:	150ab503          	ld	a0,336(s5)
    80001cb8:	64e010ef          	jal	80003306 <idup>
    80001cbc:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cc0:	4641                	li	a2,16
    80001cc2:	158a8593          	addi	a1,s5,344
    80001cc6:	158a0513          	addi	a0,s4,344
    80001cca:	8c8ff0ef          	jal	80000d92 <safestrcpy>
  pid = np->pid;
    80001cce:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001cd2:	8552                	mv	a0,s4
    80001cd4:	f49fe0ef          	jal	80000c1c <release>
  acquire(&wait_lock);
    80001cd8:	00010497          	auipc	s1,0x10
    80001cdc:	75048493          	addi	s1,s1,1872 # 80012428 <wait_lock>
    80001ce0:	8526                	mv	a0,s1
    80001ce2:	eaffe0ef          	jal	80000b90 <acquire>
  np->parent = p;
    80001ce6:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001cea:	8526                	mv	a0,s1
    80001cec:	f31fe0ef          	jal	80000c1c <release>
  acquire(&np->lock);
    80001cf0:	8552                	mv	a0,s4
    80001cf2:	e9ffe0ef          	jal	80000b90 <acquire>
  np->state = RUNNABLE;
    80001cf6:	478d                	li	a5,3
    80001cf8:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001cfc:	8552                	mv	a0,s4
    80001cfe:	f1ffe0ef          	jal	80000c1c <release>
  return pid;
    80001d02:	74a2                	ld	s1,40(sp)
    80001d04:	69e2                	ld	s3,24(sp)
    80001d06:	6a42                	ld	s4,16(sp)
}
    80001d08:	854a                	mv	a0,s2
    80001d0a:	70e2                	ld	ra,56(sp)
    80001d0c:	7442                	ld	s0,48(sp)
    80001d0e:	7902                	ld	s2,32(sp)
    80001d10:	6aa2                	ld	s5,8(sp)
    80001d12:	6121                	addi	sp,sp,64
    80001d14:	8082                	ret
    return -1;
    80001d16:	597d                	li	s2,-1
    80001d18:	bfc5                	j	80001d08 <kfork+0xfc>

0000000080001d1a <scheduler>:
{
    80001d1a:	715d                	addi	sp,sp,-80
    80001d1c:	e486                	sd	ra,72(sp)
    80001d1e:	e0a2                	sd	s0,64(sp)
    80001d20:	fc26                	sd	s1,56(sp)
    80001d22:	f84a                	sd	s2,48(sp)
    80001d24:	f44e                	sd	s3,40(sp)
    80001d26:	f052                	sd	s4,32(sp)
    80001d28:	ec56                	sd	s5,24(sp)
    80001d2a:	e85a                	sd	s6,16(sp)
    80001d2c:	e45e                	sd	s7,8(sp)
    80001d2e:	e062                	sd	s8,0(sp)
    80001d30:	0880                	addi	s0,sp,80
    80001d32:	8792                	mv	a5,tp
  int id = r_tp();
    80001d34:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d36:	00779c13          	slli	s8,a5,0x7
    80001d3a:	00010717          	auipc	a4,0x10
    80001d3e:	6d670713          	addi	a4,a4,1750 # 80012410 <pid_lock>
    80001d42:	9762                	add	a4,a4,s8
    80001d44:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d48:	00010717          	auipc	a4,0x10
    80001d4c:	70070713          	addi	a4,a4,1792 # 80012448 <cpus+0x8>
    80001d50:	9c3a                	add	s8,s8,a4
    struct proc *smallest = 0;
    80001d52:	4b81                	li	s7,0
      if (p->state == RUNNABLE){
    80001d54:	498d                	li	s3,3
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d56:	00017a17          	auipc	s4,0x17
    80001d5a:	8eaa0a13          	addi	s4,s4,-1814 # 80018640 <tickslock>
        c->proc = p;
    80001d5e:	079e                	slli	a5,a5,0x7
    80001d60:	00010a97          	auipc	s5,0x10
    80001d64:	6b0a8a93          	addi	s5,s5,1712 # 80012410 <pid_lock>
    80001d68:	9abe                	add	s5,s5,a5
        passTotal = passTotal + p->stride;
    80001d6a:	00008b17          	auipc	s6,0x8
    80001d6e:	586b0b13          	addi	s6,s6,1414 # 8000a2f0 <passTotal>
    80001d72:	a051                	j	80001df6 <scheduler+0xdc>
          release(&p->lock);
    80001d74:	8526                	mv	a0,s1
    80001d76:	ea7fe0ef          	jal	80000c1c <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d7a:	17848493          	addi	s1,s1,376
    80001d7e:	03448a63          	beq	s1,s4,80001db2 <scheduler+0x98>
      acquire (&p->lock);
    80001d82:	8526                	mv	a0,s1
    80001d84:	e0dfe0ef          	jal	80000b90 <acquire>
      if (p->state == RUNNABLE){
    80001d88:	4c9c                	lw	a5,24(s1)
    80001d8a:	ff3795e3          	bne	a5,s3,80001d74 <scheduler+0x5a>
        if (smallest == 0 || p->pass < smallest->pass){
    80001d8e:	00090b63          	beqz	s2,80001da4 <scheduler+0x8a>
    80001d92:	16c4a703          	lw	a4,364(s1)
    80001d96:	16c92783          	lw	a5,364(s2)
    80001d9a:	fcf75de3          	bge	a4,a5,80001d74 <scheduler+0x5a>
          if (smallest != 0) release(&smallest-> lock);
    80001d9e:	854a                	mv	a0,s2
    80001da0:	e7dfe0ef          	jal	80000c1c <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001da4:	17848793          	addi	a5,s1,376
    80001da8:	07478163          	beq	a5,s4,80001e0a <scheduler+0xf0>
    80001dac:	8926                	mv	s2,s1
    80001dae:	84be                	mv	s1,a5
    80001db0:	bfc9                	j	80001d82 <scheduler+0x68>
    if (smallest != 0){
    80001db2:	04090263          	beqz	s2,80001df6 <scheduler+0xdc>
        p->state = RUNNING;
    80001db6:	4791                	li	a5,4
    80001db8:	00f92c23          	sw	a5,24(s2)
        c->proc = p;
    80001dbc:	032ab823          	sd	s2,48(s5)
        swtch(&c->context, &p->context);
    80001dc0:	06090593          	addi	a1,s2,96
    80001dc4:	8562                	mv	a0,s8
    80001dc6:	6b6000ef          	jal	8000247c <swtch>
        p->runtime++; //increments runtime
    80001dca:	16892783          	lw	a5,360(s2)
    80001dce:	2785                	addiw	a5,a5,1
    80001dd0:	16f92423          	sw	a5,360(s2)
        p->pass = p->pass + p->stride;
    80001dd4:	17092703          	lw	a4,368(s2)
    80001dd8:	16c92783          	lw	a5,364(s2)
    80001ddc:	9fb9                	addw	a5,a5,a4
    80001dde:	16f92623          	sw	a5,364(s2)
        passTotal = passTotal + p->stride;
    80001de2:	000b2783          	lw	a5,0(s6)
    80001de6:	9fb9                	addw	a5,a5,a4
    80001de8:	00fb2023          	sw	a5,0(s6)
        c->proc = 0;
    80001dec:	020ab823          	sd	zero,48(s5)
        release(&p->lock);
    80001df0:	854a                	mv	a0,s2
    80001df2:	e2bfe0ef          	jal	80000c1c <release>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001df6:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001dfa:	10017073          	csrci	sstatus,2
    struct proc *smallest = 0;
    80001dfe:	895e                	mv	s2,s7
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e00:	00011497          	auipc	s1,0x11
    80001e04:	a4048493          	addi	s1,s1,-1472 # 80012840 <proc>
    80001e08:	bfad                	j	80001d82 <scheduler+0x68>
    80001e0a:	8926                	mv	s2,s1
    80001e0c:	b76d                	j	80001db6 <scheduler+0x9c>

0000000080001e0e <sched>:
{
    80001e0e:	7179                	addi	sp,sp,-48
    80001e10:	f406                	sd	ra,40(sp)
    80001e12:	f022                	sd	s0,32(sp)
    80001e14:	ec26                	sd	s1,24(sp)
    80001e16:	e84a                	sd	s2,16(sp)
    80001e18:	e44e                	sd	s3,8(sp)
    80001e1a:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e1c:	a87ff0ef          	jal	800018a2 <myproc>
    80001e20:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001e22:	d0ffe0ef          	jal	80000b30 <holding>
    80001e26:	c92d                	beqz	a0,80001e98 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e28:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001e2a:	2781                	sext.w	a5,a5
    80001e2c:	079e                	slli	a5,a5,0x7
    80001e2e:	00010717          	auipc	a4,0x10
    80001e32:	5e270713          	addi	a4,a4,1506 # 80012410 <pid_lock>
    80001e36:	97ba                	add	a5,a5,a4
    80001e38:	0a87a703          	lw	a4,168(a5)
    80001e3c:	4785                	li	a5,1
    80001e3e:	06f71363          	bne	a4,a5,80001ea4 <sched+0x96>
  if (p->state == RUNNING)
    80001e42:	4c98                	lw	a4,24(s1)
    80001e44:	4791                	li	a5,4
    80001e46:	06f70563          	beq	a4,a5,80001eb0 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001e4a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e4e:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e50:	e7b5                	bnez	a5,80001ebc <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e52:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e54:	00010917          	auipc	s2,0x10
    80001e58:	5bc90913          	addi	s2,s2,1468 # 80012410 <pid_lock>
    80001e5c:	2781                	sext.w	a5,a5
    80001e5e:	079e                	slli	a5,a5,0x7
    80001e60:	97ca                	add	a5,a5,s2
    80001e62:	0ac7a983          	lw	s3,172(a5)
    80001e66:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e68:	2781                	sext.w	a5,a5
    80001e6a:	079e                	slli	a5,a5,0x7
    80001e6c:	00010597          	auipc	a1,0x10
    80001e70:	5dc58593          	addi	a1,a1,1500 # 80012448 <cpus+0x8>
    80001e74:	95be                	add	a1,a1,a5
    80001e76:	06048513          	addi	a0,s1,96
    80001e7a:	602000ef          	jal	8000247c <swtch>
    80001e7e:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e80:	2781                	sext.w	a5,a5
    80001e82:	079e                	slli	a5,a5,0x7
    80001e84:	993e                	add	s2,s2,a5
    80001e86:	0b392623          	sw	s3,172(s2)
}
    80001e8a:	70a2                	ld	ra,40(sp)
    80001e8c:	7402                	ld	s0,32(sp)
    80001e8e:	64e2                	ld	s1,24(sp)
    80001e90:	6942                	ld	s2,16(sp)
    80001e92:	69a2                	ld	s3,8(sp)
    80001e94:	6145                	addi	sp,sp,48
    80001e96:	8082                	ret
    panic("sched p->lock");
    80001e98:	00005517          	auipc	a0,0x5
    80001e9c:	30050513          	addi	a0,a0,768 # 80007198 <etext+0x198>
    80001ea0:	951fe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001ea4:	00005517          	auipc	a0,0x5
    80001ea8:	30450513          	addi	a0,a0,772 # 800071a8 <etext+0x1a8>
    80001eac:	945fe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001eb0:	00005517          	auipc	a0,0x5
    80001eb4:	30850513          	addi	a0,a0,776 # 800071b8 <etext+0x1b8>
    80001eb8:	939fe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001ebc:	00005517          	auipc	a0,0x5
    80001ec0:	30c50513          	addi	a0,a0,780 # 800071c8 <etext+0x1c8>
    80001ec4:	92dfe0ef          	jal	800007f0 <panic>

0000000080001ec8 <yield>:
{
    80001ec8:	1101                	addi	sp,sp,-32
    80001eca:	ec06                	sd	ra,24(sp)
    80001ecc:	e822                	sd	s0,16(sp)
    80001ece:	e426                	sd	s1,8(sp)
    80001ed0:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ed2:	9d1ff0ef          	jal	800018a2 <myproc>
    80001ed6:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ed8:	cb9fe0ef          	jal	80000b90 <acquire>
  p->state = RUNNABLE;
    80001edc:	478d                	li	a5,3
    80001ede:	cc9c                	sw	a5,24(s1)
  sched();
    80001ee0:	f2fff0ef          	jal	80001e0e <sched>
  release(&p->lock);
    80001ee4:	8526                	mv	a0,s1
    80001ee6:	d37fe0ef          	jal	80000c1c <release>
}
    80001eea:	60e2                	ld	ra,24(sp)
    80001eec:	6442                	ld	s0,16(sp)
    80001eee:	64a2                	ld	s1,8(sp)
    80001ef0:	6105                	addi	sp,sp,32
    80001ef2:	8082                	ret

0000000080001ef4 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001ef4:	1101                	addi	sp,sp,-32
    80001ef6:	ec06                	sd	ra,24(sp)
    80001ef8:	e822                	sd	s0,16(sp)
    80001efa:	e426                	sd	s1,8(sp)
    80001efc:	e04a                	sd	s2,0(sp)
    80001efe:	1000                	addi	s0,sp,32
    80001f00:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001f02:	9a1ff0ef          	jal	800018a2 <myproc>
    80001f06:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001f08:	c89fe0ef          	jal	80000b90 <acquire>
  if (chan == 0)
    80001f0c:	cc81                	beqz	s1,80001f24 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001f0e:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001f12:	854a                	mv	a0,s2
    80001f14:	d09fe0ef          	jal	80000c1c <release>
}
    80001f18:	60e2                	ld	ra,24(sp)
    80001f1a:	6442                	ld	s0,16(sp)
    80001f1c:	64a2                	ld	s1,8(sp)
    80001f1e:	6902                	ld	s2,0(sp)
    80001f20:	6105                	addi	sp,sp,32
    80001f22:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001f24:	00005517          	auipc	a0,0x5
    80001f28:	2bc50513          	addi	a0,a0,700 # 800071e0 <etext+0x1e0>
    80001f2c:	8c5fe0ef          	jal	800007f0 <panic>

0000000080001f30 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001f30:	1101                	addi	sp,sp,-32
    80001f32:	ec06                	sd	ra,24(sp)
    80001f34:	e822                	sd	s0,16(sp)
    80001f36:	e426                	sd	s1,8(sp)
    80001f38:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f3a:	969ff0ef          	jal	800018a2 <myproc>
    80001f3e:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001f40:	c51fe0ef          	jal	80000b90 <acquire>
  if (p->chan != 0) {
    80001f44:	709c                	ld	a5,32(s1)
    80001f46:	c789                	beqz	a5,80001f50 <sleep+0x20>
    p->state = SLEEPING;
    80001f48:	4789                	li	a5,2
    80001f4a:	cc9c                	sw	a5,24(s1)
    sched();
    80001f4c:	ec3ff0ef          	jal	80001e0e <sched>
  }
  release(&p->lock);
    80001f50:	8526                	mv	a0,s1
    80001f52:	ccbfe0ef          	jal	80000c1c <release>
}
    80001f56:	60e2                	ld	ra,24(sp)
    80001f58:	6442                	ld	s0,16(sp)
    80001f5a:	64a2                	ld	s1,8(sp)
    80001f5c:	6105                	addi	sp,sp,32
    80001f5e:	8082                	ret

0000000080001f60 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001f60:	7139                	addi	sp,sp,-64
    80001f62:	fc06                	sd	ra,56(sp)
    80001f64:	f822                	sd	s0,48(sp)
    80001f66:	f426                	sd	s1,40(sp)
    80001f68:	f04a                	sd	s2,32(sp)
    80001f6a:	ec4e                	sd	s3,24(sp)
    80001f6c:	e852                	sd	s4,16(sp)
    80001f6e:	e456                	sd	s5,8(sp)
    80001f70:	0080                	addi	s0,sp,64
    80001f72:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001f74:	00011497          	auipc	s1,0x11
    80001f78:	8cc48493          	addi	s1,s1,-1844 # 80012840 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001f7c:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001f7e:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f80:	00016997          	auipc	s3,0x16
    80001f84:	6c098993          	addi	s3,s3,1728 # 80018640 <tickslock>
    80001f88:	a801                	j	80001f98 <wakeup+0x38>
      }
    }
    release(&p->lock);
    80001f8a:	8526                	mv	a0,s1
    80001f8c:	c91fe0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f90:	17848493          	addi	s1,s1,376
    80001f94:	03348063          	beq	s1,s3,80001fb4 <wakeup+0x54>
    acquire(&p->lock);
    80001f98:	8526                	mv	a0,s1
    80001f9a:	bf7fe0ef          	jal	80000b90 <acquire>
    if (p->chan == chan) {
    80001f9e:	709c                	ld	a5,32(s1)
    80001fa0:	ff2795e3          	bne	a5,s2,80001f8a <wakeup+0x2a>
      p->chan = 0;
    80001fa4:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    80001fa8:	4c9c                	lw	a5,24(s1)
    80001faa:	ff4790e3          	bne	a5,s4,80001f8a <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fae:	0154ac23          	sw	s5,24(s1)
    80001fb2:	bfe1                	j	80001f8a <wakeup+0x2a>
  }
}
    80001fb4:	70e2                	ld	ra,56(sp)
    80001fb6:	7442                	ld	s0,48(sp)
    80001fb8:	74a2                	ld	s1,40(sp)
    80001fba:	7902                	ld	s2,32(sp)
    80001fbc:	69e2                	ld	s3,24(sp)
    80001fbe:	6a42                	ld	s4,16(sp)
    80001fc0:	6aa2                	ld	s5,8(sp)
    80001fc2:	6121                	addi	sp,sp,64
    80001fc4:	8082                	ret

0000000080001fc6 <reparent>:
{
    80001fc6:	7179                	addi	sp,sp,-48
    80001fc8:	f406                	sd	ra,40(sp)
    80001fca:	f022                	sd	s0,32(sp)
    80001fcc:	ec26                	sd	s1,24(sp)
    80001fce:	e84a                	sd	s2,16(sp)
    80001fd0:	e44e                	sd	s3,8(sp)
    80001fd2:	e052                	sd	s4,0(sp)
    80001fd4:	1800                	addi	s0,sp,48
    80001fd6:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001fd8:	00011497          	auipc	s1,0x11
    80001fdc:	86848493          	addi	s1,s1,-1944 # 80012840 <proc>
      pp->parent = initproc;
    80001fe0:	00008a17          	auipc	s4,0x8
    80001fe4:	308a0a13          	addi	s4,s4,776 # 8000a2e8 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001fe8:	00016997          	auipc	s3,0x16
    80001fec:	65898993          	addi	s3,s3,1624 # 80018640 <tickslock>
    80001ff0:	a029                	j	80001ffa <reparent+0x34>
    80001ff2:	17848493          	addi	s1,s1,376
    80001ff6:	01348b63          	beq	s1,s3,8000200c <reparent+0x46>
    if (pp->parent == p) {
    80001ffa:	7c9c                	ld	a5,56(s1)
    80001ffc:	ff279be3          	bne	a5,s2,80001ff2 <reparent+0x2c>
      pp->parent = initproc;
    80002000:	000a3503          	ld	a0,0(s4)
    80002004:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002006:	f5bff0ef          	jal	80001f60 <wakeup>
    8000200a:	b7e5                	j	80001ff2 <reparent+0x2c>
}
    8000200c:	70a2                	ld	ra,40(sp)
    8000200e:	7402                	ld	s0,32(sp)
    80002010:	64e2                	ld	s1,24(sp)
    80002012:	6942                	ld	s2,16(sp)
    80002014:	69a2                	ld	s3,8(sp)
    80002016:	6a02                	ld	s4,0(sp)
    80002018:	6145                	addi	sp,sp,48
    8000201a:	8082                	ret

000000008000201c <kexit>:
{
    8000201c:	7179                	addi	sp,sp,-48
    8000201e:	f406                	sd	ra,40(sp)
    80002020:	f022                	sd	s0,32(sp)
    80002022:	ec26                	sd	s1,24(sp)
    80002024:	e84a                	sd	s2,16(sp)
    80002026:	e44e                	sd	s3,8(sp)
    80002028:	e052                	sd	s4,0(sp)
    8000202a:	1800                	addi	s0,sp,48
    8000202c:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000202e:	875ff0ef          	jal	800018a2 <myproc>
    80002032:	89aa                	mv	s3,a0
  if (p == initproc)
    80002034:	00008797          	auipc	a5,0x8
    80002038:	2b47b783          	ld	a5,692(a5) # 8000a2e8 <initproc>
    8000203c:	0d050493          	addi	s1,a0,208
    80002040:	15050913          	addi	s2,a0,336
    80002044:	00a79f63          	bne	a5,a0,80002062 <kexit+0x46>
    panic("init exiting");
    80002048:	00005517          	auipc	a0,0x5
    8000204c:	1b850513          	addi	a0,a0,440 # 80007200 <etext+0x200>
    80002050:	fa0fe0ef          	jal	800007f0 <panic>
      fileclose(f);
    80002054:	1dc020ef          	jal	80004230 <fileclose>
      p->ofile[fd] = 0;
    80002058:	0004b023          	sd	zero,0(s1)
  for (int fd = 0; fd < NOFILE; fd++) {
    8000205c:	04a1                	addi	s1,s1,8
    8000205e:	01248563          	beq	s1,s2,80002068 <kexit+0x4c>
    if (p->ofile[fd]) {
    80002062:	6088                	ld	a0,0(s1)
    80002064:	f965                	bnez	a0,80002054 <kexit+0x38>
    80002066:	bfdd                	j	8000205c <kexit+0x40>
  begin_op();
    80002068:	51d010ef          	jal	80003d84 <begin_op>
  iput(p->cwd);
    8000206c:	1509b503          	ld	a0,336(s3)
    80002070:	44e010ef          	jal	800034be <iput>
  end_op();
    80002074:	597010ef          	jal	80003e0a <end_op>
  p->cwd = 0;
    80002078:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000207c:	00010497          	auipc	s1,0x10
    80002080:	3ac48493          	addi	s1,s1,940 # 80012428 <wait_lock>
    80002084:	8526                	mv	a0,s1
    80002086:	b0bfe0ef          	jal	80000b90 <acquire>
  reparent(p);
    8000208a:	854e                	mv	a0,s3
    8000208c:	f3bff0ef          	jal	80001fc6 <reparent>
  wakeup(p->parent);
    80002090:	0389b503          	ld	a0,56(s3)
    80002094:	ecdff0ef          	jal	80001f60 <wakeup>
  acquire(&p->lock);
    80002098:	854e                	mv	a0,s3
    8000209a:	af7fe0ef          	jal	80000b90 <acquire>
  p->xstate = status;
    8000209e:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020a2:	4795                	li	a5,5
    800020a4:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020a8:	8526                	mv	a0,s1
    800020aa:	b73fe0ef          	jal	80000c1c <release>
  sched();
    800020ae:	d61ff0ef          	jal	80001e0e <sched>
  panic("zombie exit");
    800020b2:	00005517          	auipc	a0,0x5
    800020b6:	15e50513          	addi	a0,a0,350 # 80007210 <etext+0x210>
    800020ba:	f36fe0ef          	jal	800007f0 <panic>

00000000800020be <kkill>:
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    800020be:	c525                	beqz	a0,80002126 <kkill+0x68>
{
    800020c0:	7179                	addi	sp,sp,-48
    800020c2:	f406                	sd	ra,40(sp)
    800020c4:	f022                	sd	s0,32(sp)
    800020c6:	ec26                	sd	s1,24(sp)
    800020c8:	e84a                	sd	s2,16(sp)
    800020ca:	e44e                	sd	s3,8(sp)
    800020cc:	1800                	addi	s0,sp,48
    800020ce:	892a                	mv	s2,a0
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    800020d0:	00010497          	auipc	s1,0x10
    800020d4:	77048493          	addi	s1,s1,1904 # 80012840 <proc>
    800020d8:	00016997          	auipc	s3,0x16
    800020dc:	56898993          	addi	s3,s3,1384 # 80018640 <tickslock>
    acquire(&p->lock);
    800020e0:	8526                	mv	a0,s1
    800020e2:	aaffe0ef          	jal	80000b90 <acquire>
    if (p->pid == pid) {
    800020e6:	589c                	lw	a5,48(s1)
    800020e8:	01278b63          	beq	a5,s2,800020fe <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020ec:	8526                	mv	a0,s1
    800020ee:	b2ffe0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800020f2:	17848493          	addi	s1,s1,376
    800020f6:	ff3495e3          	bne	s1,s3,800020e0 <kkill+0x22>
  }
  return -1;
    800020fa:	557d                	li	a0,-1
    800020fc:	a819                	j	80002112 <kkill+0x54>
      p->killed = 1;
    800020fe:	4785                	li	a5,1
    80002100:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    80002102:	4c98                	lw	a4,24(s1)
    80002104:	4789                	li	a5,2
    80002106:	00f70d63          	beq	a4,a5,80002120 <kkill+0x62>
      release(&p->lock);
    8000210a:	8526                	mv	a0,s1
    8000210c:	b11fe0ef          	jal	80000c1c <release>
      return 0;
    80002110:	4501                	li	a0,0
}
    80002112:	70a2                	ld	ra,40(sp)
    80002114:	7402                	ld	s0,32(sp)
    80002116:	64e2                	ld	s1,24(sp)
    80002118:	6942                	ld	s2,16(sp)
    8000211a:	69a2                	ld	s3,8(sp)
    8000211c:	6145                	addi	sp,sp,48
    8000211e:	8082                	ret
        p->state = RUNNABLE;
    80002120:	478d                	li	a5,3
    80002122:	cc9c                	sw	a5,24(s1)
    80002124:	b7dd                	j	8000210a <kkill+0x4c>
    return -1;
    80002126:	557d                	li	a0,-1
}
    80002128:	8082                	ret

000000008000212a <setkilled>:

void
setkilled(struct proc *p)
{
    8000212a:	1101                	addi	sp,sp,-32
    8000212c:	ec06                	sd	ra,24(sp)
    8000212e:	e822                	sd	s0,16(sp)
    80002130:	e426                	sd	s1,8(sp)
    80002132:	1000                	addi	s0,sp,32
    80002134:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002136:	a5bfe0ef          	jal	80000b90 <acquire>
  p->killed = 1;
    8000213a:	4785                	li	a5,1
    8000213c:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000213e:	8526                	mv	a0,s1
    80002140:	addfe0ef          	jal	80000c1c <release>
}
    80002144:	60e2                	ld	ra,24(sp)
    80002146:	6442                	ld	s0,16(sp)
    80002148:	64a2                	ld	s1,8(sp)
    8000214a:	6105                	addi	sp,sp,32
    8000214c:	8082                	ret

000000008000214e <killed>:

int
killed(struct proc *p)
{
    8000214e:	1101                	addi	sp,sp,-32
    80002150:	ec06                	sd	ra,24(sp)
    80002152:	e822                	sd	s0,16(sp)
    80002154:	e426                	sd	s1,8(sp)
    80002156:	e04a                	sd	s2,0(sp)
    80002158:	1000                	addi	s0,sp,32
    8000215a:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    8000215c:	a35fe0ef          	jal	80000b90 <acquire>
  k = p->killed;
    80002160:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002164:	8526                	mv	a0,s1
    80002166:	ab7fe0ef          	jal	80000c1c <release>
  return k;
}
    8000216a:	854a                	mv	a0,s2
    8000216c:	60e2                	ld	ra,24(sp)
    8000216e:	6442                	ld	s0,16(sp)
    80002170:	64a2                	ld	s1,8(sp)
    80002172:	6902                	ld	s2,0(sp)
    80002174:	6105                	addi	sp,sp,32
    80002176:	8082                	ret

0000000080002178 <kwait>:
{
    80002178:	715d                	addi	sp,sp,-80
    8000217a:	e486                	sd	ra,72(sp)
    8000217c:	e0a2                	sd	s0,64(sp)
    8000217e:	fc26                	sd	s1,56(sp)
    80002180:	f84a                	sd	s2,48(sp)
    80002182:	f44e                	sd	s3,40(sp)
    80002184:	f052                	sd	s4,32(sp)
    80002186:	ec56                	sd	s5,24(sp)
    80002188:	e85a                	sd	s6,16(sp)
    8000218a:	e45e                	sd	s7,8(sp)
    8000218c:	e062                	sd	s8,0(sp)
    8000218e:	0880                	addi	s0,sp,80
    80002190:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002192:	f10ff0ef          	jal	800018a2 <myproc>
    80002196:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002198:	00010517          	auipc	a0,0x10
    8000219c:	29050513          	addi	a0,a0,656 # 80012428 <wait_lock>
    800021a0:	9f1fe0ef          	jal	80000b90 <acquire>
    havekids = 0;
    800021a4:	4c01                	li	s8,0
        if (pp->state == ZOMBIE) {
    800021a6:	4a15                	li	s4,5
        havekids = 1;
    800021a8:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021aa:	00016997          	auipc	s3,0x16
    800021ae:	49698993          	addi	s3,s3,1174 # 80018640 <tickslock>
    release(&wait_lock);
    800021b2:	00010b97          	auipc	s7,0x10
    800021b6:	276b8b93          	addi	s7,s7,630 # 80012428 <wait_lock>
    800021ba:	a84d                	j	8000226c <kwait+0xf4>
          pid = pp->pid;
    800021bc:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    800021c0:	000b0e63          	beqz	s6,800021dc <kwait+0x64>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    800021c4:	4711                	li	a4,4
    800021c6:	02c48693          	addi	a3,s1,44
    800021ca:	865a                	mv	a2,s6
    800021cc:	04893583          	ld	a1,72(s2)
    800021d0:	05093503          	ld	a0,80(s2)
    800021d4:	b04ff0ef          	jal	800014d8 <copyout>
          if (addr != 0 &&
    800021d8:	02054d63          	bltz	a0,80002212 <kwait+0x9a>
          pp->parent = 0;
    800021dc:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    800021e0:	8526                	mv	a0,s1
    800021e2:	88dff0ef          	jal	80001a6e <freeproc>
          release(&pp->lock);
    800021e6:	8526                	mv	a0,s1
    800021e8:	a35fe0ef          	jal	80000c1c <release>
          release(&wait_lock);
    800021ec:	00010517          	auipc	a0,0x10
    800021f0:	23c50513          	addi	a0,a0,572 # 80012428 <wait_lock>
    800021f4:	a29fe0ef          	jal	80000c1c <release>
}
    800021f8:	854e                	mv	a0,s3
    800021fa:	60a6                	ld	ra,72(sp)
    800021fc:	6406                	ld	s0,64(sp)
    800021fe:	74e2                	ld	s1,56(sp)
    80002200:	7942                	ld	s2,48(sp)
    80002202:	79a2                	ld	s3,40(sp)
    80002204:	7a02                	ld	s4,32(sp)
    80002206:	6ae2                	ld	s5,24(sp)
    80002208:	6b42                	ld	s6,16(sp)
    8000220a:	6ba2                	ld	s7,8(sp)
    8000220c:	6c02                	ld	s8,0(sp)
    8000220e:	6161                	addi	sp,sp,80
    80002210:	8082                	ret
            release(&pp->lock);
    80002212:	8526                	mv	a0,s1
    80002214:	a09fe0ef          	jal	80000c1c <release>
            release(&wait_lock);
    80002218:	00010517          	auipc	a0,0x10
    8000221c:	21050513          	addi	a0,a0,528 # 80012428 <wait_lock>
    80002220:	9fdfe0ef          	jal	80000c1c <release>
            return -1;
    80002224:	59fd                	li	s3,-1
    80002226:	bfc9                	j	800021f8 <kwait+0x80>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002228:	17848493          	addi	s1,s1,376
    8000222c:	03348063          	beq	s1,s3,8000224c <kwait+0xd4>
      if (pp->parent == p) {
    80002230:	7c9c                	ld	a5,56(s1)
    80002232:	ff279be3          	bne	a5,s2,80002228 <kwait+0xb0>
        acquire(&pp->lock);
    80002236:	8526                	mv	a0,s1
    80002238:	959fe0ef          	jal	80000b90 <acquire>
        if (pp->state == ZOMBIE) {
    8000223c:	4c9c                	lw	a5,24(s1)
    8000223e:	f7478fe3          	beq	a5,s4,800021bc <kwait+0x44>
        release(&pp->lock);
    80002242:	8526                	mv	a0,s1
    80002244:	9d9fe0ef          	jal	80000c1c <release>
        havekids = 1;
    80002248:	8756                	mv	a4,s5
    8000224a:	bff9                	j	80002228 <kwait+0xb0>
    if (!havekids || killed(p)) {
    8000224c:	c715                	beqz	a4,80002278 <kwait+0x100>
    8000224e:	854a                	mv	a0,s2
    80002250:	effff0ef          	jal	8000214e <killed>
    80002254:	e115                	bnez	a0,80002278 <kwait+0x100>
    sleep_prepare(p); //DOC: wait-sleep
    80002256:	854a                	mv	a0,s2
    80002258:	c9dff0ef          	jal	80001ef4 <sleep_prepare>
    release(&wait_lock);
    8000225c:	855e                	mv	a0,s7
    8000225e:	9bffe0ef          	jal	80000c1c <release>
    sleep();
    80002262:	ccfff0ef          	jal	80001f30 <sleep>
    acquire(&wait_lock);
    80002266:	855e                	mv	a0,s7
    80002268:	929fe0ef          	jal	80000b90 <acquire>
    havekids = 0;
    8000226c:	8762                	mv	a4,s8
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000226e:	00010497          	auipc	s1,0x10
    80002272:	5d248493          	addi	s1,s1,1490 # 80012840 <proc>
    80002276:	bf6d                	j	80002230 <kwait+0xb8>
      release(&wait_lock);
    80002278:	00010517          	auipc	a0,0x10
    8000227c:	1b050513          	addi	a0,a0,432 # 80012428 <wait_lock>
    80002280:	99dfe0ef          	jal	80000c1c <release>
      return -1;
    80002284:	59fd                	li	s3,-1
    80002286:	bf8d                	j	800021f8 <kwait+0x80>

0000000080002288 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002288:	7179                	addi	sp,sp,-48
    8000228a:	f406                	sd	ra,40(sp)
    8000228c:	f022                	sd	s0,32(sp)
    8000228e:	ec26                	sd	s1,24(sp)
    80002290:	e84a                	sd	s2,16(sp)
    80002292:	e44e                	sd	s3,8(sp)
    80002294:	e052                	sd	s4,0(sp)
    80002296:	1800                	addi	s0,sp,48
    80002298:	84aa                	mv	s1,a0
    8000229a:	892e                	mv	s2,a1
    8000229c:	89b2                	mv	s3,a2
    8000229e:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022a0:	e02ff0ef          	jal	800018a2 <myproc>
  if (user_dst) {
    800022a4:	c085                	beqz	s1,800022c4 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    800022a6:	8752                	mv	a4,s4
    800022a8:	86ce                	mv	a3,s3
    800022aa:	864a                	mv	a2,s2
    800022ac:	652c                	ld	a1,72(a0)
    800022ae:	6928                	ld	a0,80(a0)
    800022b0:	a28ff0ef          	jal	800014d8 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022b4:	70a2                	ld	ra,40(sp)
    800022b6:	7402                	ld	s0,32(sp)
    800022b8:	64e2                	ld	s1,24(sp)
    800022ba:	6942                	ld	s2,16(sp)
    800022bc:	69a2                	ld	s3,8(sp)
    800022be:	6a02                	ld	s4,0(sp)
    800022c0:	6145                	addi	sp,sp,48
    800022c2:	8082                	ret
    memmove((char *)dst, src, len);
    800022c4:	000a061b          	sext.w	a2,s4
    800022c8:	85ce                	mv	a1,s3
    800022ca:	854a                	mv	a0,s2
    800022cc:	9e5fe0ef          	jal	80000cb0 <memmove>
    return 0;
    800022d0:	8526                	mv	a0,s1
    800022d2:	b7cd                	j	800022b4 <either_copyout+0x2c>

00000000800022d4 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800022d4:	7179                	addi	sp,sp,-48
    800022d6:	f406                	sd	ra,40(sp)
    800022d8:	f022                	sd	s0,32(sp)
    800022da:	ec26                	sd	s1,24(sp)
    800022dc:	e84a                	sd	s2,16(sp)
    800022de:	e44e                	sd	s3,8(sp)
    800022e0:	e052                	sd	s4,0(sp)
    800022e2:	1800                	addi	s0,sp,48
    800022e4:	892a                	mv	s2,a0
    800022e6:	84ae                	mv	s1,a1
    800022e8:	89b2                	mv	s3,a2
    800022ea:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022ec:	db6ff0ef          	jal	800018a2 <myproc>
  if (user_src) {
    800022f0:	c085                	beqz	s1,80002310 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    800022f2:	8752                	mv	a4,s4
    800022f4:	86ce                	mv	a3,s3
    800022f6:	864a                	mv	a2,s2
    800022f8:	652c                	ld	a1,72(a0)
    800022fa:	6928                	ld	a0,80(a0)
    800022fc:	ac8ff0ef          	jal	800015c4 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    80002300:	70a2                	ld	ra,40(sp)
    80002302:	7402                	ld	s0,32(sp)
    80002304:	64e2                	ld	s1,24(sp)
    80002306:	6942                	ld	s2,16(sp)
    80002308:	69a2                	ld	s3,8(sp)
    8000230a:	6a02                	ld	s4,0(sp)
    8000230c:	6145                	addi	sp,sp,48
    8000230e:	8082                	ret
    memmove(dst, (char *)src, len);
    80002310:	000a061b          	sext.w	a2,s4
    80002314:	85ce                	mv	a1,s3
    80002316:	854a                	mv	a0,s2
    80002318:	999fe0ef          	jal	80000cb0 <memmove>
    return 0;
    8000231c:	8526                	mv	a0,s1
    8000231e:	b7cd                	j	80002300 <either_copyin+0x2c>

0000000080002320 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002320:	715d                	addi	sp,sp,-80
    80002322:	e486                	sd	ra,72(sp)
    80002324:	e0a2                	sd	s0,64(sp)
    80002326:	fc26                	sd	s1,56(sp)
    80002328:	f84a                	sd	s2,48(sp)
    8000232a:	f44e                	sd	s3,40(sp)
    8000232c:	f052                	sd	s4,32(sp)
    8000232e:	ec56                	sd	s5,24(sp)
    80002330:	e85a                	sd	s6,16(sp)
    80002332:	e45e                	sd	s7,8(sp)
    80002334:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002336:	00005517          	auipc	a0,0x5
    8000233a:	d4250513          	addi	a0,a0,-702 # 80007078 <etext+0x78>
    8000233e:	9ccfe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002342:	00010497          	auipc	s1,0x10
    80002346:	65648493          	addi	s1,s1,1622 # 80012998 <proc+0x158>
    8000234a:	00016917          	auipc	s2,0x16
    8000234e:	44e90913          	addi	s2,s2,1102 # 80018798 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002352:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002354:	00005997          	auipc	s3,0x5
    80002358:	ecc98993          	addi	s3,s3,-308 # 80007220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    8000235c:	00005a97          	auipc	s5,0x5
    80002360:	ecca8a93          	addi	s5,s5,-308 # 80007228 <etext+0x228>
    printk("\n");
    80002364:	00005a17          	auipc	s4,0x5
    80002368:	d14a0a13          	addi	s4,s4,-748 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000236c:	00005b97          	auipc	s7,0x5
    80002370:	3dcb8b93          	addi	s7,s7,988 # 80007748 <states.0>
    80002374:	a829                	j	8000238e <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002376:	ed86a583          	lw	a1,-296(a3)
    8000237a:	8556                	mv	a0,s5
    8000237c:	98efe0ef          	jal	8000050a <printk>
    printk("\n");
    80002380:	8552                	mv	a0,s4
    80002382:	988fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002386:	17848493          	addi	s1,s1,376
    8000238a:	03248263          	beq	s1,s2,800023ae <procdump+0x8e>
    if (p->state == UNUSED)
    8000238e:	86a6                	mv	a3,s1
    80002390:	ec04a783          	lw	a5,-320(s1)
    80002394:	dbed                	beqz	a5,80002386 <procdump+0x66>
      state = "???";
    80002396:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002398:	fcfb6fe3          	bltu	s6,a5,80002376 <procdump+0x56>
    8000239c:	02079713          	slli	a4,a5,0x20
    800023a0:	01d75793          	srli	a5,a4,0x1d
    800023a4:	97de                	add	a5,a5,s7
    800023a6:	6390                	ld	a2,0(a5)
    800023a8:	f679                	bnez	a2,80002376 <procdump+0x56>
      state = "???";
    800023aa:	864e                	mv	a2,s3
    800023ac:	b7e9                	j	80002376 <procdump+0x56>
  }
}
    800023ae:	60a6                	ld	ra,72(sp)
    800023b0:	6406                	ld	s0,64(sp)
    800023b2:	74e2                	ld	s1,56(sp)
    800023b4:	7942                	ld	s2,48(sp)
    800023b6:	79a2                	ld	s3,40(sp)
    800023b8:	7a02                	ld	s4,32(sp)
    800023ba:	6ae2                	ld	s5,24(sp)
    800023bc:	6b42                	ld	s6,16(sp)
    800023be:	6ba2                	ld	s7,8(sp)
    800023c0:	6161                	addi	sp,sp,80
    800023c2:	8082                	ret

00000000800023c4 <getpinfo>:


//My code for getpinfo
int getpinfo(struct pstat *pFromUser){
    800023c4:	ae010113          	addi	sp,sp,-1312
    800023c8:	50113c23          	sd	ra,1304(sp)
    800023cc:	50813823          	sd	s0,1296(sp)
    800023d0:	52010413          	addi	s0,sp,1312
    800023d4:	85aa                	mv	a1,a0
    pinfo.inuse[i] = (proc[i].state != UNUSED);
    pinfo.pid[i] = proc[i].pid;
    pinfo.runtime[i] = proc[i].runtime; 
    pinfo.pass[i] = proc[i].pass;
    pinfo.stride[i] = proc[i].stride;
    pinfo.passTotal = passTotal;
    800023d6:	00008517          	auipc	a0,0x8
    800023da:	f1a52503          	lw	a0,-230(a0) # 8000a2f0 <passTotal>
    800023de:	00010797          	auipc	a5,0x10
    800023e2:	47a78793          	addi	a5,a5,1146 # 80012858 <proc+0x18>
    800023e6:	ae840713          	addi	a4,s0,-1304
    800023ea:	00016617          	auipc	a2,0x16
    800023ee:	26e60613          	addi	a2,a2,622 # 80018658 <bcache>
    pinfo.inuse[i] = (proc[i].state != UNUSED);
    800023f2:	4394                	lw	a3,0(a5)
    800023f4:	00d036b3          	snez	a3,a3
    800023f8:	c314                	sw	a3,0(a4)
    pinfo.pid[i] = proc[i].pid;
    800023fa:	4f94                	lw	a3,24(a5)
    800023fc:	10d72023          	sw	a3,256(a4)
    pinfo.runtime[i] = proc[i].runtime; 
    80002400:	1507a683          	lw	a3,336(a5)
    80002404:	20d72023          	sw	a3,512(a4)
    pinfo.pass[i] = proc[i].pass;
    80002408:	1547a683          	lw	a3,340(a5)
    8000240c:	30d72023          	sw	a3,768(a4)
    pinfo.stride[i] = proc[i].stride;
    80002410:	1587a683          	lw	a3,344(a5)
    80002414:	40d72023          	sw	a3,1024(a4)
  for (int i=0; i < NPROC; ++i)
    80002418:	17878793          	addi	a5,a5,376
    8000241c:	0711                	addi	a4,a4,4
    8000241e:	fcc79ae3          	bne	a5,a2,800023f2 <getpinfo+0x2e>
    80002422:	fea42423          	sw	a0,-24(s0)

   }
 // now copy to user space from the pinfo structure
  either_copyout(1, (uint64) pFromUser, &pinfo, sizeof(struct pstat));
    80002426:	50400693          	li	a3,1284
    8000242a:	ae840613          	addi	a2,s0,-1304
    8000242e:	4505                	li	a0,1
    80002430:	e59ff0ef          	jal	80002288 <either_copyout>
  return 0;
}
    80002434:	4501                	li	a0,0
    80002436:	51813083          	ld	ra,1304(sp)
    8000243a:	51013403          	ld	s0,1296(sp)
    8000243e:	52010113          	addi	sp,sp,1312
    80002442:	8082                	ret

0000000080002444 <setstride>:

//My code for setStride
int setstride(int strideLength){
    80002444:	1101                	addi	sp,sp,-32
    80002446:	ec06                	sd	ra,24(sp)
    80002448:	e822                	sd	s0,16(sp)
    8000244a:	e04a                	sd	s2,0(sp)
    8000244c:	1000                	addi	s0,sp,32
    8000244e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80002450:	c52ff0ef          	jal	800018a2 <myproc>

  if (strideLength < 0){
    80002454:	02094263          	bltz	s2,80002478 <setstride+0x34>
    80002458:	e426                	sd	s1,8(sp)
    8000245a:	84aa                	mv	s1,a0
    return -1;
  }
  acquire(&p->lock);
    8000245c:	f34fe0ef          	jal	80000b90 <acquire>
  p->stride = strideLength;
    80002460:	1724a823          	sw	s2,368(s1)
  release(&p->lock);
    80002464:	8526                	mv	a0,s1
    80002466:	fb6fe0ef          	jal	80000c1c <release>

  return 0;
    8000246a:	4501                	li	a0,0
    8000246c:	64a2                	ld	s1,8(sp)
}
    8000246e:	60e2                	ld	ra,24(sp)
    80002470:	6442                	ld	s0,16(sp)
    80002472:	6902                	ld	s2,0(sp)
    80002474:	6105                	addi	sp,sp,32
    80002476:	8082                	ret
    return -1;
    80002478:	557d                	li	a0,-1
    8000247a:	bfd5                	j	8000246e <setstride+0x2a>

000000008000247c <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000247c:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002480:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002484:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002486:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002488:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000248c:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002490:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002494:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002498:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    8000249c:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800024a0:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800024a4:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800024a8:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800024ac:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800024b0:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800024b4:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800024b8:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800024ba:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800024bc:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800024c0:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800024c4:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800024c8:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800024cc:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800024d0:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800024d4:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800024d8:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800024dc:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800024e0:	0685bd83          	ld	s11,104(a1)
        
        ret
    800024e4:	8082                	ret

00000000800024e6 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800024e6:	1141                	addi	sp,sp,-16
    800024e8:	e406                	sd	ra,8(sp)
    800024ea:	e022                	sd	s0,0(sp)
    800024ec:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800024ee:	00005597          	auipc	a1,0x5
    800024f2:	d7a58593          	addi	a1,a1,-646 # 80007268 <etext+0x268>
    800024f6:	00016517          	auipc	a0,0x16
    800024fa:	14a50513          	addi	a0,a0,330 # 80018640 <tickslock>
    800024fe:	e1cfe0ef          	jal	80000b1a <initlock>
}
    80002502:	60a2                	ld	ra,8(sp)
    80002504:	6402                	ld	s0,0(sp)
    80002506:	0141                	addi	sp,sp,16
    80002508:	8082                	ret

000000008000250a <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000250a:	1141                	addi	sp,sp,-16
    8000250c:	e422                	sd	s0,8(sp)
    8000250e:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002510:	00003797          	auipc	a5,0x3
    80002514:	16078793          	addi	a5,a5,352 # 80005670 <kernelvec>
    80002518:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000251c:	6422                	ld	s0,8(sp)
    8000251e:	0141                	addi	sp,sp,16
    80002520:	8082                	ret

0000000080002522 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002522:	1141                	addi	sp,sp,-16
    80002524:	e406                	sd	ra,8(sp)
    80002526:	e022                	sd	s0,0(sp)
    80002528:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000252a:	b78ff0ef          	jal	800018a2 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    8000252e:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002532:	04000737          	lui	a4,0x4000
    80002536:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002538:	0732                	slli	a4,a4,0xc
    8000253a:	00004797          	auipc	a5,0x4
    8000253e:	ac678793          	addi	a5,a5,-1338 # 80006000 <_trampoline>
    80002542:	00004697          	auipc	a3,0x4
    80002546:	abe68693          	addi	a3,a3,-1346 # 80006000 <_trampoline>
    8000254a:	8f95                	sub	a5,a5,a3
    8000254c:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000254e:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002552:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002554:	18002773          	csrr	a4,satp
    80002558:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000255a:	6d38                	ld	a4,88(a0)
    8000255c:	613c                	ld	a5,64(a0)
    8000255e:	6685                	lui	a3,0x1
    80002560:	97b6                	add	a5,a5,a3
    80002562:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002564:	6d3c                	ld	a5,88(a0)
    80002566:	00000717          	auipc	a4,0x0
    8000256a:	0f870713          	addi	a4,a4,248 # 8000265e <usertrap>
    8000256e:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002570:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002572:	8712                	mv	a4,tp
    80002574:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002576:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000257a:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000257e:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002582:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002586:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002588:	6f9c                	ld	a5,24(a5)
    8000258a:	14179073          	csrw	sepc,a5
}
    8000258e:	60a2                	ld	ra,8(sp)
    80002590:	6402                	ld	s0,0(sp)
    80002592:	0141                	addi	sp,sp,16
    80002594:	8082                	ret

0000000080002596 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002596:	1101                	addi	sp,sp,-32
    80002598:	ec06                	sd	ra,24(sp)
    8000259a:	e822                	sd	s0,16(sp)
    8000259c:	1000                	addi	s0,sp,32
  if (cpuid() == 0) {
    8000259e:	ad8ff0ef          	jal	80001876 <cpuid>
    800025a2:	cd11                	beqz	a0,800025be <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    800025a4:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800025a8:	000f4737          	lui	a4,0xf4
    800025ac:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800025b0:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    800025b2:	14d79073          	csrw	stimecmp,a5
}
    800025b6:	60e2                	ld	ra,24(sp)
    800025b8:	6442                	ld	s0,16(sp)
    800025ba:	6105                	addi	sp,sp,32
    800025bc:	8082                	ret
    800025be:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    800025c0:	00016497          	auipc	s1,0x16
    800025c4:	08048493          	addi	s1,s1,128 # 80018640 <tickslock>
    800025c8:	8526                	mv	a0,s1
    800025ca:	dc6fe0ef          	jal	80000b90 <acquire>
    ticks++;
    800025ce:	00008517          	auipc	a0,0x8
    800025d2:	d2650513          	addi	a0,a0,-730 # 8000a2f4 <ticks>
    800025d6:	411c                	lw	a5,0(a0)
    800025d8:	2785                	addiw	a5,a5,1
    800025da:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800025dc:	985ff0ef          	jal	80001f60 <wakeup>
    release(&tickslock);
    800025e0:	8526                	mv	a0,s1
    800025e2:	e3afe0ef          	jal	80000c1c <release>
    800025e6:	64a2                	ld	s1,8(sp)
    800025e8:	bf75                	j	800025a4 <clockintr+0xe>

00000000800025ea <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800025ea:	1101                	addi	sp,sp,-32
    800025ec:	ec06                	sd	ra,24(sp)
    800025ee:	e822                	sd	s0,16(sp)
    800025f0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    800025f2:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    800025f6:	57fd                	li	a5,-1
    800025f8:	17fe                	slli	a5,a5,0x3f
    800025fa:	07a5                	addi	a5,a5,9
    800025fc:	00f70c63          	beq	a4,a5,80002614 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    80002600:	57fd                	li	a5,-1
    80002602:	17fe                	slli	a5,a5,0x3f
    80002604:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002606:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002608:	04f70763          	beq	a4,a5,80002656 <devintr+0x6c>
  }
}
    8000260c:	60e2                	ld	ra,24(sp)
    8000260e:	6442                	ld	s0,16(sp)
    80002610:	6105                	addi	sp,sp,32
    80002612:	8082                	ret
    80002614:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002616:	108030ef          	jal	8000571e <plic_claim>
    8000261a:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    8000261c:	47a9                	li	a5,10
    8000261e:	00f50963          	beq	a0,a5,80002630 <devintr+0x46>
    } else if (irq == VIRTIO0_IRQ) {
    80002622:	4785                	li	a5,1
    80002624:	00f50963          	beq	a0,a5,80002636 <devintr+0x4c>
    return 1;
    80002628:	4505                	li	a0,1
    } else if (irq) {
    8000262a:	e889                	bnez	s1,8000263c <devintr+0x52>
    8000262c:	64a2                	ld	s1,8(sp)
    8000262e:	bff9                	j	8000260c <devintr+0x22>
      uartintr();
    80002630:	b5cfe0ef          	jal	8000098c <uartintr>
    if (irq)
    80002634:	a819                	j	8000264a <devintr+0x60>
      virtio_disk_intr();
    80002636:	5d2030ef          	jal	80005c08 <virtio_disk_intr>
    if (irq)
    8000263a:	a801                	j	8000264a <devintr+0x60>
      printk("unexpected interrupt irq=%d\n", irq);
    8000263c:	85a6                	mv	a1,s1
    8000263e:	00005517          	auipc	a0,0x5
    80002642:	c3250513          	addi	a0,a0,-974 # 80007270 <etext+0x270>
    80002646:	ec5fd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    8000264a:	8526                	mv	a0,s1
    8000264c:	0f4030ef          	jal	80005740 <plic_complete>
    return 1;
    80002650:	4505                	li	a0,1
    80002652:	64a2                	ld	s1,8(sp)
    80002654:	bf65                	j	8000260c <devintr+0x22>
    clockintr();
    80002656:	f41ff0ef          	jal	80002596 <clockintr>
    return 2;
    8000265a:	4509                	li	a0,2
    8000265c:	bf45                	j	8000260c <devintr+0x22>

000000008000265e <usertrap>:
{
    8000265e:	1101                	addi	sp,sp,-32
    80002660:	ec06                	sd	ra,24(sp)
    80002662:	e822                	sd	s0,16(sp)
    80002664:	e426                	sd	s1,8(sp)
    80002666:	e04a                	sd	s2,0(sp)
    80002668:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000266a:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    8000266e:	1007f793          	andi	a5,a5,256
    80002672:	eba5                	bnez	a5,800026e2 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002674:	00003797          	auipc	a5,0x3
    80002678:	ffc78793          	addi	a5,a5,-4 # 80005670 <kernelvec>
    8000267c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002680:	a22ff0ef          	jal	800018a2 <myproc>
    80002684:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002686:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002688:	14102773          	csrr	a4,sepc
    8000268c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    8000268e:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002692:	47a1                	li	a5,8
    80002694:	04f70d63          	beq	a4,a5,800026ee <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002698:	f53ff0ef          	jal	800025ea <devintr>
    8000269c:	892a                	mv	s2,a0
    8000269e:	e54d                	bnez	a0,80002748 <usertrap+0xea>
    800026a0:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026a4:	47bd                	li	a5,15
    800026a6:	08f70463          	beq	a4,a5,8000272e <usertrap+0xd0>
    800026aa:	14202773          	csrr	a4,scause
    800026ae:	47b5                	li	a5,13
    800026b0:	06f70f63          	beq	a4,a5,8000272e <usertrap+0xd0>
    800026b4:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800026b8:	5890                	lw	a2,48(s1)
    800026ba:	00005517          	auipc	a0,0x5
    800026be:	bf650513          	addi	a0,a0,-1034 # 800072b0 <etext+0x2b0>
    800026c2:	e49fd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026c6:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800026ca:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800026ce:	00005517          	auipc	a0,0x5
    800026d2:	c1250513          	addi	a0,a0,-1006 # 800072e0 <etext+0x2e0>
    800026d6:	e35fd0ef          	jal	8000050a <printk>
    setkilled(p);
    800026da:	8526                	mv	a0,s1
    800026dc:	a4fff0ef          	jal	8000212a <setkilled>
    800026e0:	a015                	j	80002704 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    800026e2:	00005517          	auipc	a0,0x5
    800026e6:	bae50513          	addi	a0,a0,-1106 # 80007290 <etext+0x290>
    800026ea:	906fe0ef          	jal	800007f0 <panic>
    if (killed(p))
    800026ee:	a61ff0ef          	jal	8000214e <killed>
    800026f2:	e915                	bnez	a0,80002726 <usertrap+0xc8>
    p->trapframe->epc += 4;
    800026f4:	6cb8                	ld	a4,88(s1)
    800026f6:	6f1c                	ld	a5,24(a4)
    800026f8:	0791                	addi	a5,a5,4
    800026fa:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    800026fc:	10016073          	csrsi	sstatus,2
    syscall();
    80002700:	24a000ef          	jal	8000294a <syscall>
  if (killed(p))
    80002704:	8526                	mv	a0,s1
    80002706:	a49ff0ef          	jal	8000214e <killed>
    8000270a:	e521                	bnez	a0,80002752 <usertrap+0xf4>
  prepare_return();
    8000270c:	e17ff0ef          	jal	80002522 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002710:	68a8                	ld	a0,80(s1)
    80002712:	8131                	srli	a0,a0,0xc
    80002714:	57fd                	li	a5,-1
    80002716:	17fe                	slli	a5,a5,0x3f
    80002718:	8d5d                	or	a0,a0,a5
}
    8000271a:	60e2                	ld	ra,24(sp)
    8000271c:	6442                	ld	s0,16(sp)
    8000271e:	64a2                	ld	s1,8(sp)
    80002720:	6902                	ld	s2,0(sp)
    80002722:	6105                	addi	sp,sp,32
    80002724:	8082                	ret
      kexit(-1);
    80002726:	557d                	li	a0,-1
    80002728:	8f5ff0ef          	jal	8000201c <kexit>
    8000272c:	b7e1                	j	800026f4 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    8000272e:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002732:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    80002736:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    80002738:	0016b693          	seqz	a3,a3
    8000273c:	64ac                	ld	a1,72(s1)
    8000273e:	68a8                	ld	a0,80(s1)
    80002740:	d1dfe0ef          	jal	8000145c <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002744:	f161                	bnez	a0,80002704 <usertrap+0xa6>
    80002746:	b7bd                	j	800026b4 <usertrap+0x56>
  if (killed(p))
    80002748:	8526                	mv	a0,s1
    8000274a:	a05ff0ef          	jal	8000214e <killed>
    8000274e:	c511                	beqz	a0,8000275a <usertrap+0xfc>
    80002750:	a011                	j	80002754 <usertrap+0xf6>
    80002752:	4901                	li	s2,0
    kexit(-1);
    80002754:	557d                	li	a0,-1
    80002756:	8c7ff0ef          	jal	8000201c <kexit>
  if (which_dev == 2)
    8000275a:	4789                	li	a5,2
    8000275c:	faf918e3          	bne	s2,a5,8000270c <usertrap+0xae>
    yield();
    80002760:	f68ff0ef          	jal	80001ec8 <yield>
    80002764:	b765                	j	8000270c <usertrap+0xae>

0000000080002766 <kerneltrap>:
{
    80002766:	7179                	addi	sp,sp,-48
    80002768:	f406                	sd	ra,40(sp)
    8000276a:	f022                	sd	s0,32(sp)
    8000276c:	ec26                	sd	s1,24(sp)
    8000276e:	e84a                	sd	s2,16(sp)
    80002770:	e44e                	sd	s3,8(sp)
    80002772:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002774:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002778:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    8000277c:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    80002780:	1004f793          	andi	a5,s1,256
    80002784:	c795                	beqz	a5,800027b0 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002786:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000278a:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    8000278c:	eb85                	bnez	a5,800027bc <kerneltrap+0x56>
  if ((which_dev = devintr()) == 0) {
    8000278e:	e5dff0ef          	jal	800025ea <devintr>
    80002792:	c91d                	beqz	a0,800027c8 <kerneltrap+0x62>
  if (which_dev == 2 && myproc() != 0)
    80002794:	4789                	li	a5,2
    80002796:	04f50a63          	beq	a0,a5,800027ea <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000279a:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000279e:	10049073          	csrw	sstatus,s1
}
    800027a2:	70a2                	ld	ra,40(sp)
    800027a4:	7402                	ld	s0,32(sp)
    800027a6:	64e2                	ld	s1,24(sp)
    800027a8:	6942                	ld	s2,16(sp)
    800027aa:	69a2                	ld	s3,8(sp)
    800027ac:	6145                	addi	sp,sp,48
    800027ae:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800027b0:	00005517          	auipc	a0,0x5
    800027b4:	b5850513          	addi	a0,a0,-1192 # 80007308 <etext+0x308>
    800027b8:	838fe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    800027bc:	00005517          	auipc	a0,0x5
    800027c0:	b7450513          	addi	a0,a0,-1164 # 80007330 <etext+0x330>
    800027c4:	82cfe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800027c8:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800027cc:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    800027d0:	85ce                	mv	a1,s3
    800027d2:	00005517          	auipc	a0,0x5
    800027d6:	b7e50513          	addi	a0,a0,-1154 # 80007350 <etext+0x350>
    800027da:	d31fd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    800027de:	00005517          	auipc	a0,0x5
    800027e2:	b9a50513          	addi	a0,a0,-1126 # 80007378 <etext+0x378>
    800027e6:	80afe0ef          	jal	800007f0 <panic>
  if (which_dev == 2 && myproc() != 0)
    800027ea:	8b8ff0ef          	jal	800018a2 <myproc>
    800027ee:	d555                	beqz	a0,8000279a <kerneltrap+0x34>
    yield();
    800027f0:	ed8ff0ef          	jal	80001ec8 <yield>
    800027f4:	b75d                	j	8000279a <kerneltrap+0x34>

00000000800027f6 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800027f6:	1101                	addi	sp,sp,-32
    800027f8:	ec06                	sd	ra,24(sp)
    800027fa:	e822                	sd	s0,16(sp)
    800027fc:	e426                	sd	s1,8(sp)
    800027fe:	1000                	addi	s0,sp,32
    80002800:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002802:	8a0ff0ef          	jal	800018a2 <myproc>
  switch (n) {
    80002806:	4795                	li	a5,5
    80002808:	0497e163          	bltu	a5,s1,8000284a <argraw+0x54>
    8000280c:	048a                	slli	s1,s1,0x2
    8000280e:	00005717          	auipc	a4,0x5
    80002812:	f6a70713          	addi	a4,a4,-150 # 80007778 <states.0+0x30>
    80002816:	94ba                	add	s1,s1,a4
    80002818:	409c                	lw	a5,0(s1)
    8000281a:	97ba                	add	a5,a5,a4
    8000281c:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000281e:	6d3c                	ld	a5,88(a0)
    80002820:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002822:	60e2                	ld	ra,24(sp)
    80002824:	6442                	ld	s0,16(sp)
    80002826:	64a2                	ld	s1,8(sp)
    80002828:	6105                	addi	sp,sp,32
    8000282a:	8082                	ret
    return p->trapframe->a1;
    8000282c:	6d3c                	ld	a5,88(a0)
    8000282e:	7fa8                	ld	a0,120(a5)
    80002830:	bfcd                	j	80002822 <argraw+0x2c>
    return p->trapframe->a2;
    80002832:	6d3c                	ld	a5,88(a0)
    80002834:	63c8                	ld	a0,128(a5)
    80002836:	b7f5                	j	80002822 <argraw+0x2c>
    return p->trapframe->a3;
    80002838:	6d3c                	ld	a5,88(a0)
    8000283a:	67c8                	ld	a0,136(a5)
    8000283c:	b7dd                	j	80002822 <argraw+0x2c>
    return p->trapframe->a4;
    8000283e:	6d3c                	ld	a5,88(a0)
    80002840:	6bc8                	ld	a0,144(a5)
    80002842:	b7c5                	j	80002822 <argraw+0x2c>
    return p->trapframe->a5;
    80002844:	6d3c                	ld	a5,88(a0)
    80002846:	6fc8                	ld	a0,152(a5)
    80002848:	bfe9                	j	80002822 <argraw+0x2c>
  panic("argraw");
    8000284a:	00005517          	auipc	a0,0x5
    8000284e:	b3e50513          	addi	a0,a0,-1218 # 80007388 <etext+0x388>
    80002852:	f9ffd0ef          	jal	800007f0 <panic>

0000000080002856 <fetchaddr>:
{
    80002856:	1101                	addi	sp,sp,-32
    80002858:	ec06                	sd	ra,24(sp)
    8000285a:	e822                	sd	s0,16(sp)
    8000285c:	e426                	sd	s1,8(sp)
    8000285e:	e04a                	sd	s2,0(sp)
    80002860:	1000                	addi	s0,sp,32
    80002862:	84aa                	mv	s1,a0
    80002864:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002866:	83cff0ef          	jal	800018a2 <myproc>
  if (addr >= p->sz ||
    8000286a:	652c                	ld	a1,72(a0)
    8000286c:	02b4f663          	bgeu	s1,a1,80002898 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002870:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002874:	02f5e463          	bltu	a1,a5,8000289c <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    80002878:	4721                	li	a4,8
    8000287a:	86a6                	mv	a3,s1
    8000287c:	864a                	mv	a2,s2
    8000287e:	6928                	ld	a0,80(a0)
    80002880:	d45fe0ef          	jal	800015c4 <copyin>
    80002884:	00a03533          	snez	a0,a0
    80002888:	40a00533          	neg	a0,a0
}
    8000288c:	60e2                	ld	ra,24(sp)
    8000288e:	6442                	ld	s0,16(sp)
    80002890:	64a2                	ld	s1,8(sp)
    80002892:	6902                	ld	s2,0(sp)
    80002894:	6105                	addi	sp,sp,32
    80002896:	8082                	ret
    return -1;
    80002898:	557d                	li	a0,-1
    8000289a:	bfcd                	j	8000288c <fetchaddr+0x36>
    8000289c:	557d                	li	a0,-1
    8000289e:	b7fd                	j	8000288c <fetchaddr+0x36>

00000000800028a0 <fetchstr>:
{
    800028a0:	7179                	addi	sp,sp,-48
    800028a2:	f406                	sd	ra,40(sp)
    800028a4:	f022                	sd	s0,32(sp)
    800028a6:	ec26                	sd	s1,24(sp)
    800028a8:	e84a                	sd	s2,16(sp)
    800028aa:	e44e                	sd	s3,8(sp)
    800028ac:	1800                	addi	s0,sp,48
    800028ae:	892a                	mv	s2,a0
    800028b0:	84ae                	mv	s1,a1
    800028b2:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800028b4:	feffe0ef          	jal	800018a2 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    800028b8:	874e                	mv	a4,s3
    800028ba:	86ca                	mv	a3,s2
    800028bc:	8626                	mv	a2,s1
    800028be:	652c                	ld	a1,72(a0)
    800028c0:	6928                	ld	a0,80(a0)
    800028c2:	d99fe0ef          	jal	8000165a <copyinstr>
    800028c6:	00054c63          	bltz	a0,800028de <fetchstr+0x3e>
  return strlen(buf);
    800028ca:	8526                	mv	a0,s1
    800028cc:	cf8fe0ef          	jal	80000dc4 <strlen>
}
    800028d0:	70a2                	ld	ra,40(sp)
    800028d2:	7402                	ld	s0,32(sp)
    800028d4:	64e2                	ld	s1,24(sp)
    800028d6:	6942                	ld	s2,16(sp)
    800028d8:	69a2                	ld	s3,8(sp)
    800028da:	6145                	addi	sp,sp,48
    800028dc:	8082                	ret
    return -1;
    800028de:	557d                	li	a0,-1
    800028e0:	bfc5                	j	800028d0 <fetchstr+0x30>

00000000800028e2 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800028e2:	1101                	addi	sp,sp,-32
    800028e4:	ec06                	sd	ra,24(sp)
    800028e6:	e822                	sd	s0,16(sp)
    800028e8:	e426                	sd	s1,8(sp)
    800028ea:	1000                	addi	s0,sp,32
    800028ec:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028ee:	f09ff0ef          	jal	800027f6 <argraw>
    800028f2:	c088                	sw	a0,0(s1)
}
    800028f4:	60e2                	ld	ra,24(sp)
    800028f6:	6442                	ld	s0,16(sp)
    800028f8:	64a2                	ld	s1,8(sp)
    800028fa:	6105                	addi	sp,sp,32
    800028fc:	8082                	ret

00000000800028fe <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800028fe:	1101                	addi	sp,sp,-32
    80002900:	ec06                	sd	ra,24(sp)
    80002902:	e822                	sd	s0,16(sp)
    80002904:	e426                	sd	s1,8(sp)
    80002906:	1000                	addi	s0,sp,32
    80002908:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000290a:	eedff0ef          	jal	800027f6 <argraw>
    8000290e:	e088                	sd	a0,0(s1)
}
    80002910:	60e2                	ld	ra,24(sp)
    80002912:	6442                	ld	s0,16(sp)
    80002914:	64a2                	ld	s1,8(sp)
    80002916:	6105                	addi	sp,sp,32
    80002918:	8082                	ret

000000008000291a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    8000291a:	7179                	addi	sp,sp,-48
    8000291c:	f406                	sd	ra,40(sp)
    8000291e:	f022                	sd	s0,32(sp)
    80002920:	ec26                	sd	s1,24(sp)
    80002922:	e84a                	sd	s2,16(sp)
    80002924:	1800                	addi	s0,sp,48
    80002926:	84ae                	mv	s1,a1
    80002928:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    8000292a:	fd840593          	addi	a1,s0,-40
    8000292e:	fd1ff0ef          	jal	800028fe <argaddr>
  return fetchstr(addr, buf, max);
    80002932:	864a                	mv	a2,s2
    80002934:	85a6                	mv	a1,s1
    80002936:	fd843503          	ld	a0,-40(s0)
    8000293a:	f67ff0ef          	jal	800028a0 <fetchstr>
}
    8000293e:	70a2                	ld	ra,40(sp)
    80002940:	7402                	ld	s0,32(sp)
    80002942:	64e2                	ld	s1,24(sp)
    80002944:	6942                	ld	s2,16(sp)
    80002946:	6145                	addi	sp,sp,48
    80002948:	8082                	ret

000000008000294a <syscall>:
  // clang-format on
};

void
syscall(void)
{
    8000294a:	1101                	addi	sp,sp,-32
    8000294c:	ec06                	sd	ra,24(sp)
    8000294e:	e822                	sd	s0,16(sp)
    80002950:	e426                	sd	s1,8(sp)
    80002952:	e04a                	sd	s2,0(sp)
    80002954:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002956:	f4dfe0ef          	jal	800018a2 <myproc>
    8000295a:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    8000295c:	05853903          	ld	s2,88(a0)
    80002960:	0a893783          	ld	a5,168(s2)
    80002964:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002968:	37fd                	addiw	a5,a5,-1
    8000296a:	475d                	li	a4,23
    8000296c:	00f76f63          	bltu	a4,a5,8000298a <syscall+0x40>
    80002970:	00369713          	slli	a4,a3,0x3
    80002974:	00005797          	auipc	a5,0x5
    80002978:	e1c78793          	addi	a5,a5,-484 # 80007790 <syscalls>
    8000297c:	97ba                	add	a5,a5,a4
    8000297e:	639c                	ld	a5,0(a5)
    80002980:	c789                	beqz	a5,8000298a <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002982:	9782                	jalr	a5
    80002984:	06a93823          	sd	a0,112(s2)
    80002988:	a829                	j	800029a2 <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    8000298a:	15848613          	addi	a2,s1,344
    8000298e:	588c                	lw	a1,48(s1)
    80002990:	00005517          	auipc	a0,0x5
    80002994:	a0050513          	addi	a0,a0,-1536 # 80007390 <etext+0x390>
    80002998:	b73fd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    8000299c:	6cbc                	ld	a5,88(s1)
    8000299e:	577d                	li	a4,-1
    800029a0:	fbb8                	sd	a4,112(a5)
  }
}
    800029a2:	60e2                	ld	ra,24(sp)
    800029a4:	6442                	ld	s0,16(sp)
    800029a6:	64a2                	ld	s1,8(sp)
    800029a8:	6902                	ld	s2,0(sp)
    800029aa:	6105                	addi	sp,sp,32
    800029ac:	8082                	ret

00000000800029ae <sys_exit>:
#include "vm.h"
#include "pstat.h"

uint64
sys_exit(void)
{
    800029ae:	1101                	addi	sp,sp,-32
    800029b0:	ec06                	sd	ra,24(sp)
    800029b2:	e822                	sd	s0,16(sp)
    800029b4:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800029b6:	fec40593          	addi	a1,s0,-20
    800029ba:	4501                	li	a0,0
    800029bc:	f27ff0ef          	jal	800028e2 <argint>
  kexit(n);
    800029c0:	fec42503          	lw	a0,-20(s0)
    800029c4:	e58ff0ef          	jal	8000201c <kexit>
  return 0; // not reached
}
    800029c8:	4501                	li	a0,0
    800029ca:	60e2                	ld	ra,24(sp)
    800029cc:	6442                	ld	s0,16(sp)
    800029ce:	6105                	addi	sp,sp,32
    800029d0:	8082                	ret

00000000800029d2 <sys_getpid>:

uint64
sys_getpid(void)
{
    800029d2:	1141                	addi	sp,sp,-16
    800029d4:	e406                	sd	ra,8(sp)
    800029d6:	e022                	sd	s0,0(sp)
    800029d8:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800029da:	ec9fe0ef          	jal	800018a2 <myproc>
}
    800029de:	5908                	lw	a0,48(a0)
    800029e0:	60a2                	ld	ra,8(sp)
    800029e2:	6402                	ld	s0,0(sp)
    800029e4:	0141                	addi	sp,sp,16
    800029e6:	8082                	ret

00000000800029e8 <sys_fork>:

uint64
sys_fork(void)
{
    800029e8:	1141                	addi	sp,sp,-16
    800029ea:	e406                	sd	ra,8(sp)
    800029ec:	e022                	sd	s0,0(sp)
    800029ee:	0800                	addi	s0,sp,16
  return kfork();
    800029f0:	a1cff0ef          	jal	80001c0c <kfork>
}
    800029f4:	60a2                	ld	ra,8(sp)
    800029f6:	6402                	ld	s0,0(sp)
    800029f8:	0141                	addi	sp,sp,16
    800029fa:	8082                	ret

00000000800029fc <sys_wait>:

uint64
sys_wait(void)
{
    800029fc:	1101                	addi	sp,sp,-32
    800029fe:	ec06                	sd	ra,24(sp)
    80002a00:	e822                	sd	s0,16(sp)
    80002a02:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a04:	fe840593          	addi	a1,s0,-24
    80002a08:	4501                	li	a0,0
    80002a0a:	ef5ff0ef          	jal	800028fe <argaddr>
  return kwait(p);
    80002a0e:	fe843503          	ld	a0,-24(s0)
    80002a12:	f66ff0ef          	jal	80002178 <kwait>
}
    80002a16:	60e2                	ld	ra,24(sp)
    80002a18:	6442                	ld	s0,16(sp)
    80002a1a:	6105                	addi	sp,sp,32
    80002a1c:	8082                	ret

0000000080002a1e <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002a1e:	7179                	addi	sp,sp,-48
    80002a20:	f406                	sd	ra,40(sp)
    80002a22:	f022                	sd	s0,32(sp)
    80002a24:	ec26                	sd	s1,24(sp)
    80002a26:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002a28:	fd840593          	addi	a1,s0,-40
    80002a2c:	4501                	li	a0,0
    80002a2e:	eb5ff0ef          	jal	800028e2 <argint>
  argint(1, &t);
    80002a32:	fdc40593          	addi	a1,s0,-36
    80002a36:	4505                	li	a0,1
    80002a38:	eabff0ef          	jal	800028e2 <argint>
  addr = myproc()->sz;
    80002a3c:	e67fe0ef          	jal	800018a2 <myproc>
    80002a40:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002a42:	fdc42703          	lw	a4,-36(s0)
    80002a46:	4785                	li	a5,1
    80002a48:	02f70763          	beq	a4,a5,80002a76 <sys_sbrk+0x58>
    80002a4c:	fd842783          	lw	a5,-40(s0)
    80002a50:	0207c363          	bltz	a5,80002a76 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002a54:	97a6                	add	a5,a5,s1
    80002a56:	0297ee63          	bltu	a5,s1,80002a92 <sys_sbrk+0x74>
      return -1;
    if (addr + n > TRAPFRAME)
    80002a5a:	02000737          	lui	a4,0x2000
    80002a5e:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002a60:	0736                	slli	a4,a4,0xd
    80002a62:	02f76a63          	bltu	a4,a5,80002a96 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002a66:	e3dfe0ef          	jal	800018a2 <myproc>
    80002a6a:	fd842703          	lw	a4,-40(s0)
    80002a6e:	653c                	ld	a5,72(a0)
    80002a70:	97ba                	add	a5,a5,a4
    80002a72:	e53c                	sd	a5,72(a0)
    80002a74:	a039                	j	80002a82 <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80002a76:	fd842503          	lw	a0,-40(s0)
    80002a7a:	930ff0ef          	jal	80001baa <growproc>
    80002a7e:	00054863          	bltz	a0,80002a8e <sys_sbrk+0x70>
  }
  return addr;
}
    80002a82:	8526                	mv	a0,s1
    80002a84:	70a2                	ld	ra,40(sp)
    80002a86:	7402                	ld	s0,32(sp)
    80002a88:	64e2                	ld	s1,24(sp)
    80002a8a:	6145                	addi	sp,sp,48
    80002a8c:	8082                	ret
      return -1;
    80002a8e:	54fd                	li	s1,-1
    80002a90:	bfcd                	j	80002a82 <sys_sbrk+0x64>
      return -1;
    80002a92:	54fd                	li	s1,-1
    80002a94:	b7fd                	j	80002a82 <sys_sbrk+0x64>
      return -1;
    80002a96:	54fd                	li	s1,-1
    80002a98:	b7ed                	j	80002a82 <sys_sbrk+0x64>

0000000080002a9a <sys_pause>:

uint64
sys_pause(void)
{
    80002a9a:	7139                	addi	sp,sp,-64
    80002a9c:	fc06                	sd	ra,56(sp)
    80002a9e:	f822                	sd	s0,48(sp)
    80002aa0:	ec4e                	sd	s3,24(sp)
    80002aa2:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002aa4:	fcc40593          	addi	a1,s0,-52
    80002aa8:	4501                	li	a0,0
    80002aaa:	e39ff0ef          	jal	800028e2 <argint>
  if (n < 0)
    80002aae:	fcc42783          	lw	a5,-52(s0)
    80002ab2:	0607cf63          	bltz	a5,80002b30 <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002ab6:	00016517          	auipc	a0,0x16
    80002aba:	b8a50513          	addi	a0,a0,-1142 # 80018640 <tickslock>
    80002abe:	8d2fe0ef          	jal	80000b90 <acquire>
  ticks0 = ticks;
    80002ac2:	00008997          	auipc	s3,0x8
    80002ac6:	8329a983          	lw	s3,-1998(s3) # 8000a2f4 <ticks>
  while (ticks - ticks0 < n) {
    80002aca:	fcc42783          	lw	a5,-52(s0)
    80002ace:	c7a9                	beqz	a5,80002b18 <sys_pause+0x7e>
    80002ad0:	f426                	sd	s1,40(sp)
    80002ad2:	f04a                	sd	s2,32(sp)
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002ad4:	00008917          	auipc	s2,0x8
    80002ad8:	82090913          	addi	s2,s2,-2016 # 8000a2f4 <ticks>
    release(&tickslock);
    80002adc:	00016497          	auipc	s1,0x16
    80002ae0:	b6448493          	addi	s1,s1,-1180 # 80018640 <tickslock>
    if (killed(myproc())) {
    80002ae4:	dbffe0ef          	jal	800018a2 <myproc>
    80002ae8:	e66ff0ef          	jal	8000214e <killed>
    80002aec:	e529                	bnez	a0,80002b36 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002aee:	854a                	mv	a0,s2
    80002af0:	c04ff0ef          	jal	80001ef4 <sleep_prepare>
    release(&tickslock);
    80002af4:	8526                	mv	a0,s1
    80002af6:	926fe0ef          	jal	80000c1c <release>
    sleep();
    80002afa:	c36ff0ef          	jal	80001f30 <sleep>
    acquire(&tickslock);
    80002afe:	8526                	mv	a0,s1
    80002b00:	890fe0ef          	jal	80000b90 <acquire>
  while (ticks - ticks0 < n) {
    80002b04:	00092783          	lw	a5,0(s2)
    80002b08:	413787bb          	subw	a5,a5,s3
    80002b0c:	fcc42703          	lw	a4,-52(s0)
    80002b10:	fce7eae3          	bltu	a5,a4,80002ae4 <sys_pause+0x4a>
    80002b14:	74a2                	ld	s1,40(sp)
    80002b16:	7902                	ld	s2,32(sp)
  }
  release(&tickslock);
    80002b18:	00016517          	auipc	a0,0x16
    80002b1c:	b2850513          	addi	a0,a0,-1240 # 80018640 <tickslock>
    80002b20:	8fcfe0ef          	jal	80000c1c <release>
  return 0;
    80002b24:	4501                	li	a0,0
}
    80002b26:	70e2                	ld	ra,56(sp)
    80002b28:	7442                	ld	s0,48(sp)
    80002b2a:	69e2                	ld	s3,24(sp)
    80002b2c:	6121                	addi	sp,sp,64
    80002b2e:	8082                	ret
    n = 0;
    80002b30:	fc042623          	sw	zero,-52(s0)
    80002b34:	b749                	j	80002ab6 <sys_pause+0x1c>
      release(&tickslock);
    80002b36:	00016517          	auipc	a0,0x16
    80002b3a:	b0a50513          	addi	a0,a0,-1270 # 80018640 <tickslock>
    80002b3e:	8defe0ef          	jal	80000c1c <release>
      return -1;
    80002b42:	557d                	li	a0,-1
    80002b44:	74a2                	ld	s1,40(sp)
    80002b46:	7902                	ld	s2,32(sp)
    80002b48:	bff9                	j	80002b26 <sys_pause+0x8c>

0000000080002b4a <sys_kill>:

uint64
sys_kill(void)
{
    80002b4a:	1101                	addi	sp,sp,-32
    80002b4c:	ec06                	sd	ra,24(sp)
    80002b4e:	e822                	sd	s0,16(sp)
    80002b50:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002b52:	fec40593          	addi	a1,s0,-20
    80002b56:	4501                	li	a0,0
    80002b58:	d8bff0ef          	jal	800028e2 <argint>
  return kkill(pid);
    80002b5c:	fec42503          	lw	a0,-20(s0)
    80002b60:	d5eff0ef          	jal	800020be <kkill>
}
    80002b64:	60e2                	ld	ra,24(sp)
    80002b66:	6442                	ld	s0,16(sp)
    80002b68:	6105                	addi	sp,sp,32
    80002b6a:	8082                	ret

0000000080002b6c <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b6c:	1101                	addi	sp,sp,-32
    80002b6e:	ec06                	sd	ra,24(sp)
    80002b70:	e822                	sd	s0,16(sp)
    80002b72:	e426                	sd	s1,8(sp)
    80002b74:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b76:	00016517          	auipc	a0,0x16
    80002b7a:	aca50513          	addi	a0,a0,-1334 # 80018640 <tickslock>
    80002b7e:	812fe0ef          	jal	80000b90 <acquire>
  xticks = ticks;
    80002b82:	00007497          	auipc	s1,0x7
    80002b86:	7724a483          	lw	s1,1906(s1) # 8000a2f4 <ticks>
  release(&tickslock);
    80002b8a:	00016517          	auipc	a0,0x16
    80002b8e:	ab650513          	addi	a0,a0,-1354 # 80018640 <tickslock>
    80002b92:	88afe0ef          	jal	80000c1c <release>
  return xticks;
}
    80002b96:	02049513          	slli	a0,s1,0x20
    80002b9a:	9101                	srli	a0,a0,0x20
    80002b9c:	60e2                	ld	ra,24(sp)
    80002b9e:	6442                	ld	s0,16(sp)
    80002ba0:	64a2                	ld	s1,8(sp)
    80002ba2:	6105                	addi	sp,sp,32
    80002ba4:	8082                	ret

0000000080002ba6 <sys_getpinfo>:

//My code for get pinfo
uint64
sys_getpinfo(void){
    80002ba6:	1101                	addi	sp,sp,-32
    80002ba8:	ec06                	sd	ra,24(sp)
    80002baa:	e822                	sd	s0,16(sp)
    80002bac:	1000                	addi	s0,sp,32
  uint64 p; 
  argaddr(0, &p); 
    80002bae:	fe840593          	addi	a1,s0,-24
    80002bb2:	4501                	li	a0,0
    80002bb4:	d4bff0ef          	jal	800028fe <argaddr>
  return getpinfo((struct pstat *)p);
    80002bb8:	fe843503          	ld	a0,-24(s0)
    80002bbc:	809ff0ef          	jal	800023c4 <getpinfo>
}
    80002bc0:	60e2                	ld	ra,24(sp)
    80002bc2:	6442                	ld	s0,16(sp)
    80002bc4:	6105                	addi	sp,sp,32
    80002bc6:	8082                	ret

0000000080002bc8 <sys_setstride>:

uint64
sys_setstride(void){
    80002bc8:	1101                	addi	sp,sp,-32
    80002bca:	ec06                	sd	ra,24(sp)
    80002bcc:	e822                	sd	s0,16(sp)
    80002bce:	1000                	addi	s0,sp,32
  int strideLength;
  argint(0, &strideLength);
    80002bd0:	fec40593          	addi	a1,s0,-20
    80002bd4:	4501                	li	a0,0
    80002bd6:	d0dff0ef          	jal	800028e2 <argint>

  return setstride(strideLength);
    80002bda:	fec42503          	lw	a0,-20(s0)
    80002bde:	867ff0ef          	jal	80002444 <setstride>

}
    80002be2:	60e2                	ld	ra,24(sp)
    80002be4:	6442                	ld	s0,16(sp)
    80002be6:	6105                	addi	sp,sp,32
    80002be8:	8082                	ret

0000000080002bea <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002bea:	7179                	addi	sp,sp,-48
    80002bec:	f406                	sd	ra,40(sp)
    80002bee:	f022                	sd	s0,32(sp)
    80002bf0:	ec26                	sd	s1,24(sp)
    80002bf2:	e84a                	sd	s2,16(sp)
    80002bf4:	e44e                	sd	s3,8(sp)
    80002bf6:	e052                	sd	s4,0(sp)
    80002bf8:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002bfa:	00004597          	auipc	a1,0x4
    80002bfe:	7b658593          	addi	a1,a1,1974 # 800073b0 <etext+0x3b0>
    80002c02:	00016517          	auipc	a0,0x16
    80002c06:	a5650513          	addi	a0,a0,-1450 # 80018658 <bcache>
    80002c0a:	f11fd0ef          	jal	80000b1a <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002c0e:	0001e797          	auipc	a5,0x1e
    80002c12:	a4a78793          	addi	a5,a5,-1462 # 80020658 <bcache+0x8000>
    80002c16:	0001e717          	auipc	a4,0x1e
    80002c1a:	caa70713          	addi	a4,a4,-854 # 800208c0 <bcache+0x8268>
    80002c1e:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002c22:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002c26:	00016497          	auipc	s1,0x16
    80002c2a:	a4a48493          	addi	s1,s1,-1462 # 80018670 <bcache+0x18>
    b->next = bcache.head.next;
    80002c2e:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002c30:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002c32:	00004a17          	auipc	s4,0x4
    80002c36:	786a0a13          	addi	s4,s4,1926 # 800073b8 <etext+0x3b8>
    b->next = bcache.head.next;
    80002c3a:	2b893783          	ld	a5,696(s2)
    80002c3e:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002c40:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002c44:	85d2                	mv	a1,s4
    80002c46:	01048513          	addi	a0,s1,16
    80002c4a:	412010ef          	jal	8000405c <initsleeplock>
    bcache.head.next->prev = b;
    80002c4e:	2b893783          	ld	a5,696(s2)
    80002c52:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002c54:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002c58:	45848493          	addi	s1,s1,1112
    80002c5c:	fd349fe3          	bne	s1,s3,80002c3a <binit+0x50>
  }
}
    80002c60:	70a2                	ld	ra,40(sp)
    80002c62:	7402                	ld	s0,32(sp)
    80002c64:	64e2                	ld	s1,24(sp)
    80002c66:	6942                	ld	s2,16(sp)
    80002c68:	69a2                	ld	s3,8(sp)
    80002c6a:	6a02                	ld	s4,0(sp)
    80002c6c:	6145                	addi	sp,sp,48
    80002c6e:	8082                	ret

0000000080002c70 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002c70:	7179                	addi	sp,sp,-48
    80002c72:	f406                	sd	ra,40(sp)
    80002c74:	f022                	sd	s0,32(sp)
    80002c76:	ec26                	sd	s1,24(sp)
    80002c78:	e84a                	sd	s2,16(sp)
    80002c7a:	e44e                	sd	s3,8(sp)
    80002c7c:	1800                	addi	s0,sp,48
    80002c7e:	892a                	mv	s2,a0
    80002c80:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c82:	00016517          	auipc	a0,0x16
    80002c86:	9d650513          	addi	a0,a0,-1578 # 80018658 <bcache>
    80002c8a:	f07fd0ef          	jal	80000b90 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002c8e:	0001e497          	auipc	s1,0x1e
    80002c92:	c824b483          	ld	s1,-894(s1) # 80020910 <bcache+0x82b8>
    80002c96:	0001e797          	auipc	a5,0x1e
    80002c9a:	c2a78793          	addi	a5,a5,-982 # 800208c0 <bcache+0x8268>
    80002c9e:	02f48b63          	beq	s1,a5,80002cd4 <bread+0x64>
    80002ca2:	873e                	mv	a4,a5
    80002ca4:	a021                	j	80002cac <bread+0x3c>
    80002ca6:	68a4                	ld	s1,80(s1)
    80002ca8:	02e48663          	beq	s1,a4,80002cd4 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002cac:	449c                	lw	a5,8(s1)
    80002cae:	ff279ce3          	bne	a5,s2,80002ca6 <bread+0x36>
    80002cb2:	44dc                	lw	a5,12(s1)
    80002cb4:	ff3799e3          	bne	a5,s3,80002ca6 <bread+0x36>
      b->refcnt++;
    80002cb8:	40bc                	lw	a5,64(s1)
    80002cba:	2785                	addiw	a5,a5,1
    80002cbc:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002cbe:	00016517          	auipc	a0,0x16
    80002cc2:	99a50513          	addi	a0,a0,-1638 # 80018658 <bcache>
    80002cc6:	f57fd0ef          	jal	80000c1c <release>
      acquiresleep(&b->lock);
    80002cca:	01048513          	addi	a0,s1,16
    80002cce:	3c4010ef          	jal	80004092 <acquiresleep>
      return b;
    80002cd2:	a889                	j	80002d24 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002cd4:	0001e497          	auipc	s1,0x1e
    80002cd8:	c344b483          	ld	s1,-972(s1) # 80020908 <bcache+0x82b0>
    80002cdc:	0001e797          	auipc	a5,0x1e
    80002ce0:	be478793          	addi	a5,a5,-1052 # 800208c0 <bcache+0x8268>
    80002ce4:	00f48863          	beq	s1,a5,80002cf4 <bread+0x84>
    80002ce8:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002cea:	40bc                	lw	a5,64(s1)
    80002cec:	cb91                	beqz	a5,80002d00 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002cee:	64a4                	ld	s1,72(s1)
    80002cf0:	fee49de3          	bne	s1,a4,80002cea <bread+0x7a>
  panic("bget: no buffers");
    80002cf4:	00004517          	auipc	a0,0x4
    80002cf8:	6cc50513          	addi	a0,a0,1740 # 800073c0 <etext+0x3c0>
    80002cfc:	af5fd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80002d00:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002d04:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002d08:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002d0c:	4785                	li	a5,1
    80002d0e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002d10:	00016517          	auipc	a0,0x16
    80002d14:	94850513          	addi	a0,a0,-1720 # 80018658 <bcache>
    80002d18:	f05fd0ef          	jal	80000c1c <release>
      acquiresleep(&b->lock);
    80002d1c:	01048513          	addi	a0,s1,16
    80002d20:	372010ef          	jal	80004092 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002d24:	409c                	lw	a5,0(s1)
    80002d26:	cb89                	beqz	a5,80002d38 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002d28:	8526                	mv	a0,s1
    80002d2a:	70a2                	ld	ra,40(sp)
    80002d2c:	7402                	ld	s0,32(sp)
    80002d2e:	64e2                	ld	s1,24(sp)
    80002d30:	6942                	ld	s2,16(sp)
    80002d32:	69a2                	ld	s3,8(sp)
    80002d34:	6145                	addi	sp,sp,48
    80002d36:	8082                	ret
    virtio_disk_rw(b, 0);
    80002d38:	4581                	li	a1,0
    80002d3a:	8526                	mv	a0,s1
    80002d3c:	49d020ef          	jal	800059d8 <virtio_disk_rw>
    b->valid = 1;
    80002d40:	4785                	li	a5,1
    80002d42:	c09c                	sw	a5,0(s1)
  return b;
    80002d44:	b7d5                	j	80002d28 <bread+0xb8>

0000000080002d46 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002d46:	1101                	addi	sp,sp,-32
    80002d48:	ec06                	sd	ra,24(sp)
    80002d4a:	e822                	sd	s0,16(sp)
    80002d4c:	e426                	sd	s1,8(sp)
    80002d4e:	1000                	addi	s0,sp,32
    80002d50:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d52:	0541                	addi	a0,a0,16
    80002d54:	3ca010ef          	jal	8000411e <holdingsleep>
    80002d58:	c911                	beqz	a0,80002d6c <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002d5a:	4585                	li	a1,1
    80002d5c:	8526                	mv	a0,s1
    80002d5e:	47b020ef          	jal	800059d8 <virtio_disk_rw>
}
    80002d62:	60e2                	ld	ra,24(sp)
    80002d64:	6442                	ld	s0,16(sp)
    80002d66:	64a2                	ld	s1,8(sp)
    80002d68:	6105                	addi	sp,sp,32
    80002d6a:	8082                	ret
    panic("bwrite");
    80002d6c:	00004517          	auipc	a0,0x4
    80002d70:	66c50513          	addi	a0,a0,1644 # 800073d8 <etext+0x3d8>
    80002d74:	a7dfd0ef          	jal	800007f0 <panic>

0000000080002d78 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d78:	1101                	addi	sp,sp,-32
    80002d7a:	ec06                	sd	ra,24(sp)
    80002d7c:	e822                	sd	s0,16(sp)
    80002d7e:	e426                	sd	s1,8(sp)
    80002d80:	e04a                	sd	s2,0(sp)
    80002d82:	1000                	addi	s0,sp,32
    80002d84:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d86:	01050913          	addi	s2,a0,16
    80002d8a:	854a                	mv	a0,s2
    80002d8c:	392010ef          	jal	8000411e <holdingsleep>
    80002d90:	c135                	beqz	a0,80002df4 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002d92:	854a                	mv	a0,s2
    80002d94:	352010ef          	jal	800040e6 <releasesleep>

  acquire(&bcache.lock);
    80002d98:	00016517          	auipc	a0,0x16
    80002d9c:	8c050513          	addi	a0,a0,-1856 # 80018658 <bcache>
    80002da0:	df1fd0ef          	jal	80000b90 <acquire>
  b->refcnt--;
    80002da4:	40bc                	lw	a5,64(s1)
    80002da6:	37fd                	addiw	a5,a5,-1
    80002da8:	0007871b          	sext.w	a4,a5
    80002dac:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002dae:	e71d                	bnez	a4,80002ddc <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002db0:	68b8                	ld	a4,80(s1)
    80002db2:	64bc                	ld	a5,72(s1)
    80002db4:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002db6:	68b8                	ld	a4,80(s1)
    80002db8:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002dba:	0001e797          	auipc	a5,0x1e
    80002dbe:	89e78793          	addi	a5,a5,-1890 # 80020658 <bcache+0x8000>
    80002dc2:	2b87b703          	ld	a4,696(a5)
    80002dc6:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002dc8:	0001e717          	auipc	a4,0x1e
    80002dcc:	af870713          	addi	a4,a4,-1288 # 800208c0 <bcache+0x8268>
    80002dd0:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002dd2:	2b87b703          	ld	a4,696(a5)
    80002dd6:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002dd8:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002ddc:	00016517          	auipc	a0,0x16
    80002de0:	87c50513          	addi	a0,a0,-1924 # 80018658 <bcache>
    80002de4:	e39fd0ef          	jal	80000c1c <release>
}
    80002de8:	60e2                	ld	ra,24(sp)
    80002dea:	6442                	ld	s0,16(sp)
    80002dec:	64a2                	ld	s1,8(sp)
    80002dee:	6902                	ld	s2,0(sp)
    80002df0:	6105                	addi	sp,sp,32
    80002df2:	8082                	ret
    panic("brelse");
    80002df4:	00004517          	auipc	a0,0x4
    80002df8:	5ec50513          	addi	a0,a0,1516 # 800073e0 <etext+0x3e0>
    80002dfc:	9f5fd0ef          	jal	800007f0 <panic>

0000000080002e00 <bpin>:

void
bpin(struct buf *b)
{
    80002e00:	1101                	addi	sp,sp,-32
    80002e02:	ec06                	sd	ra,24(sp)
    80002e04:	e822                	sd	s0,16(sp)
    80002e06:	e426                	sd	s1,8(sp)
    80002e08:	1000                	addi	s0,sp,32
    80002e0a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e0c:	00016517          	auipc	a0,0x16
    80002e10:	84c50513          	addi	a0,a0,-1972 # 80018658 <bcache>
    80002e14:	d7dfd0ef          	jal	80000b90 <acquire>
  b->refcnt++;
    80002e18:	40bc                	lw	a5,64(s1)
    80002e1a:	2785                	addiw	a5,a5,1
    80002e1c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e1e:	00016517          	auipc	a0,0x16
    80002e22:	83a50513          	addi	a0,a0,-1990 # 80018658 <bcache>
    80002e26:	df7fd0ef          	jal	80000c1c <release>
}
    80002e2a:	60e2                	ld	ra,24(sp)
    80002e2c:	6442                	ld	s0,16(sp)
    80002e2e:	64a2                	ld	s1,8(sp)
    80002e30:	6105                	addi	sp,sp,32
    80002e32:	8082                	ret

0000000080002e34 <bunpin>:

void
bunpin(struct buf *b)
{
    80002e34:	1101                	addi	sp,sp,-32
    80002e36:	ec06                	sd	ra,24(sp)
    80002e38:	e822                	sd	s0,16(sp)
    80002e3a:	e426                	sd	s1,8(sp)
    80002e3c:	1000                	addi	s0,sp,32
    80002e3e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e40:	00016517          	auipc	a0,0x16
    80002e44:	81850513          	addi	a0,a0,-2024 # 80018658 <bcache>
    80002e48:	d49fd0ef          	jal	80000b90 <acquire>
  b->refcnt--;
    80002e4c:	40bc                	lw	a5,64(s1)
    80002e4e:	37fd                	addiw	a5,a5,-1
    80002e50:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e52:	00016517          	auipc	a0,0x16
    80002e56:	80650513          	addi	a0,a0,-2042 # 80018658 <bcache>
    80002e5a:	dc3fd0ef          	jal	80000c1c <release>
}
    80002e5e:	60e2                	ld	ra,24(sp)
    80002e60:	6442                	ld	s0,16(sp)
    80002e62:	64a2                	ld	s1,8(sp)
    80002e64:	6105                	addi	sp,sp,32
    80002e66:	8082                	ret

0000000080002e68 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002e68:	1101                	addi	sp,sp,-32
    80002e6a:	ec06                	sd	ra,24(sp)
    80002e6c:	e822                	sd	s0,16(sp)
    80002e6e:	e426                	sd	s1,8(sp)
    80002e70:	e04a                	sd	s2,0(sp)
    80002e72:	1000                	addi	s0,sp,32
    80002e74:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e76:	00d5d59b          	srliw	a1,a1,0xd
    80002e7a:	0001e797          	auipc	a5,0x1e
    80002e7e:	eba7a783          	lw	a5,-326(a5) # 80020d34 <sb+0x1c>
    80002e82:	9dbd                	addw	a1,a1,a5
    80002e84:	dedff0ef          	jal	80002c70 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e88:	0074f713          	andi	a4,s1,7
    80002e8c:	4785                	li	a5,1
    80002e8e:	00e797bb          	sllw	a5,a5,a4
  if ((bp->data[bi / 8] & m) == 0)
    80002e92:	14ce                	slli	s1,s1,0x33
    80002e94:	90d9                	srli	s1,s1,0x36
    80002e96:	00950733          	add	a4,a0,s1
    80002e9a:	05874703          	lbu	a4,88(a4)
    80002e9e:	00e7f6b3          	and	a3,a5,a4
    80002ea2:	c29d                	beqz	a3,80002ec8 <bfree+0x60>
    80002ea4:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002ea6:	94aa                	add	s1,s1,a0
    80002ea8:	fff7c793          	not	a5,a5
    80002eac:	8f7d                	and	a4,a4,a5
    80002eae:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002eb2:	078010ef          	jal	80003f2a <log_write>
  brelse(bp);
    80002eb6:	854a                	mv	a0,s2
    80002eb8:	ec1ff0ef          	jal	80002d78 <brelse>
}
    80002ebc:	60e2                	ld	ra,24(sp)
    80002ebe:	6442                	ld	s0,16(sp)
    80002ec0:	64a2                	ld	s1,8(sp)
    80002ec2:	6902                	ld	s2,0(sp)
    80002ec4:	6105                	addi	sp,sp,32
    80002ec6:	8082                	ret
    panic("freeing free block");
    80002ec8:	00004517          	auipc	a0,0x4
    80002ecc:	52050513          	addi	a0,a0,1312 # 800073e8 <etext+0x3e8>
    80002ed0:	921fd0ef          	jal	800007f0 <panic>

0000000080002ed4 <balloc>:
{
    80002ed4:	711d                	addi	sp,sp,-96
    80002ed6:	ec86                	sd	ra,88(sp)
    80002ed8:	e8a2                	sd	s0,80(sp)
    80002eda:	e4a6                	sd	s1,72(sp)
    80002edc:	1080                	addi	s0,sp,96
  for (b = 0; b < sb.size; b += BPB) {
    80002ede:	0001e797          	auipc	a5,0x1e
    80002ee2:	e3e7a783          	lw	a5,-450(a5) # 80020d1c <sb+0x4>
    80002ee6:	0e078f63          	beqz	a5,80002fe4 <balloc+0x110>
    80002eea:	e0ca                	sd	s2,64(sp)
    80002eec:	fc4e                	sd	s3,56(sp)
    80002eee:	f852                	sd	s4,48(sp)
    80002ef0:	f456                	sd	s5,40(sp)
    80002ef2:	f05a                	sd	s6,32(sp)
    80002ef4:	ec5e                	sd	s7,24(sp)
    80002ef6:	e862                	sd	s8,16(sp)
    80002ef8:	e466                	sd	s9,8(sp)
    80002efa:	8baa                	mv	s7,a0
    80002efc:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002efe:	0001eb17          	auipc	s6,0x1e
    80002f02:	e1ab0b13          	addi	s6,s6,-486 # 80020d18 <sb>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f06:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002f08:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f0a:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002f0c:	6c89                	lui	s9,0x2
    80002f0e:	a0b5                	j	80002f7a <balloc+0xa6>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002f10:	97ca                	add	a5,a5,s2
    80002f12:	8e55                	or	a2,a2,a3
    80002f14:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002f18:	854a                	mv	a0,s2
    80002f1a:	010010ef          	jal	80003f2a <log_write>
        brelse(bp);
    80002f1e:	854a                	mv	a0,s2
    80002f20:	e59ff0ef          	jal	80002d78 <brelse>
  bp = bread(dev, bno);
    80002f24:	85a6                	mv	a1,s1
    80002f26:	855e                	mv	a0,s7
    80002f28:	d49ff0ef          	jal	80002c70 <bread>
    80002f2c:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002f2e:	40000613          	li	a2,1024
    80002f32:	4581                	li	a1,0
    80002f34:	05850513          	addi	a0,a0,88
    80002f38:	d1dfd0ef          	jal	80000c54 <memset>
  log_write(bp);
    80002f3c:	854a                	mv	a0,s2
    80002f3e:	7ed000ef          	jal	80003f2a <log_write>
  brelse(bp);
    80002f42:	854a                	mv	a0,s2
    80002f44:	e35ff0ef          	jal	80002d78 <brelse>
}
    80002f48:	6906                	ld	s2,64(sp)
    80002f4a:	79e2                	ld	s3,56(sp)
    80002f4c:	7a42                	ld	s4,48(sp)
    80002f4e:	7aa2                	ld	s5,40(sp)
    80002f50:	7b02                	ld	s6,32(sp)
    80002f52:	6be2                	ld	s7,24(sp)
    80002f54:	6c42                	ld	s8,16(sp)
    80002f56:	6ca2                	ld	s9,8(sp)
}
    80002f58:	8526                	mv	a0,s1
    80002f5a:	60e6                	ld	ra,88(sp)
    80002f5c:	6446                	ld	s0,80(sp)
    80002f5e:	64a6                	ld	s1,72(sp)
    80002f60:	6125                	addi	sp,sp,96
    80002f62:	8082                	ret
    brelse(bp);
    80002f64:	854a                	mv	a0,s2
    80002f66:	e13ff0ef          	jal	80002d78 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80002f6a:	015c87bb          	addw	a5,s9,s5
    80002f6e:	00078a9b          	sext.w	s5,a5
    80002f72:	004b2703          	lw	a4,4(s6)
    80002f76:	04eaff63          	bgeu	s5,a4,80002fd4 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80002f7a:	41fad79b          	sraiw	a5,s5,0x1f
    80002f7e:	0137d79b          	srliw	a5,a5,0x13
    80002f82:	015787bb          	addw	a5,a5,s5
    80002f86:	40d7d79b          	sraiw	a5,a5,0xd
    80002f8a:	01cb2583          	lw	a1,28(s6)
    80002f8e:	9dbd                	addw	a1,a1,a5
    80002f90:	855e                	mv	a0,s7
    80002f92:	cdfff0ef          	jal	80002c70 <bread>
    80002f96:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f98:	004b2503          	lw	a0,4(s6)
    80002f9c:	000a849b          	sext.w	s1,s5
    80002fa0:	8762                	mv	a4,s8
    80002fa2:	fca4f1e3          	bgeu	s1,a0,80002f64 <balloc+0x90>
      m = 1 << (bi % 8);
    80002fa6:	00777693          	andi	a3,a4,7
    80002faa:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002fae:	41f7579b          	sraiw	a5,a4,0x1f
    80002fb2:	01d7d79b          	srliw	a5,a5,0x1d
    80002fb6:	9fb9                	addw	a5,a5,a4
    80002fb8:	4037d79b          	sraiw	a5,a5,0x3
    80002fbc:	00f90633          	add	a2,s2,a5
    80002fc0:	05864603          	lbu	a2,88(a2)
    80002fc4:	00c6f5b3          	and	a1,a3,a2
    80002fc8:	d5a1                	beqz	a1,80002f10 <balloc+0x3c>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002fca:	2705                	addiw	a4,a4,1
    80002fcc:	2485                	addiw	s1,s1,1
    80002fce:	fd471ae3          	bne	a4,s4,80002fa2 <balloc+0xce>
    80002fd2:	bf49                	j	80002f64 <balloc+0x90>
    80002fd4:	6906                	ld	s2,64(sp)
    80002fd6:	79e2                	ld	s3,56(sp)
    80002fd8:	7a42                	ld	s4,48(sp)
    80002fda:	7aa2                	ld	s5,40(sp)
    80002fdc:	7b02                	ld	s6,32(sp)
    80002fde:	6be2                	ld	s7,24(sp)
    80002fe0:	6c42                	ld	s8,16(sp)
    80002fe2:	6ca2                	ld	s9,8(sp)
  printk("balloc: out of blocks\n");
    80002fe4:	00004517          	auipc	a0,0x4
    80002fe8:	41c50513          	addi	a0,a0,1052 # 80007400 <etext+0x400>
    80002fec:	d1efd0ef          	jal	8000050a <printk>
  return 0;
    80002ff0:	4481                	li	s1,0
    80002ff2:	b79d                	j	80002f58 <balloc+0x84>

0000000080002ff4 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002ff4:	7179                	addi	sp,sp,-48
    80002ff6:	f406                	sd	ra,40(sp)
    80002ff8:	f022                	sd	s0,32(sp)
    80002ffa:	ec26                	sd	s1,24(sp)
    80002ffc:	e84a                	sd	s2,16(sp)
    80002ffe:	e44e                	sd	s3,8(sp)
    80003000:	1800                	addi	s0,sp,48
    80003002:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80003004:	47ad                	li	a5,11
    80003006:	02b7e663          	bltu	a5,a1,80003032 <bmap+0x3e>
    if ((addr = ip->addrs[bn]) == 0) {
    8000300a:	02059793          	slli	a5,a1,0x20
    8000300e:	01e7d593          	srli	a1,a5,0x1e
    80003012:	00b504b3          	add	s1,a0,a1
    80003016:	0504a903          	lw	s2,80(s1)
    8000301a:	06091a63          	bnez	s2,8000308e <bmap+0x9a>
      addr = balloc(ip->dev);
    8000301e:	4108                	lw	a0,0(a0)
    80003020:	eb5ff0ef          	jal	80002ed4 <balloc>
    80003024:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80003028:	06090363          	beqz	s2,8000308e <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    8000302c:	0524a823          	sw	s2,80(s1)
    80003030:	a8b9                	j	8000308e <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003032:	ff45849b          	addiw	s1,a1,-12
    80003036:	0004871b          	sext.w	a4,s1

  if (bn < NINDIRECT) {
    8000303a:	0ff00793          	li	a5,255
    8000303e:	06e7ee63          	bltu	a5,a4,800030ba <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80003042:	08052903          	lw	s2,128(a0)
    80003046:	00091d63          	bnez	s2,80003060 <bmap+0x6c>
      addr = balloc(ip->dev);
    8000304a:	4108                	lw	a0,0(a0)
    8000304c:	e89ff0ef          	jal	80002ed4 <balloc>
    80003050:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80003054:	02090d63          	beqz	s2,8000308e <bmap+0x9a>
    80003058:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000305a:	0929a023          	sw	s2,128(s3)
    8000305e:	a011                	j	80003062 <bmap+0x6e>
    80003060:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80003062:	85ca                	mv	a1,s2
    80003064:	0009a503          	lw	a0,0(s3)
    80003068:	c09ff0ef          	jal	80002c70 <bread>
    8000306c:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    8000306e:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80003072:	02049713          	slli	a4,s1,0x20
    80003076:	01e75593          	srli	a1,a4,0x1e
    8000307a:	00b784b3          	add	s1,a5,a1
    8000307e:	0004a903          	lw	s2,0(s1)
    80003082:	00090e63          	beqz	s2,8000309e <bmap+0xaa>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003086:	8552                	mv	a0,s4
    80003088:	cf1ff0ef          	jal	80002d78 <brelse>
    return addr;
    8000308c:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000308e:	854a                	mv	a0,s2
    80003090:	70a2                	ld	ra,40(sp)
    80003092:	7402                	ld	s0,32(sp)
    80003094:	64e2                	ld	s1,24(sp)
    80003096:	6942                	ld	s2,16(sp)
    80003098:	69a2                	ld	s3,8(sp)
    8000309a:	6145                	addi	sp,sp,48
    8000309c:	8082                	ret
      addr = balloc(ip->dev);
    8000309e:	0009a503          	lw	a0,0(s3)
    800030a2:	e33ff0ef          	jal	80002ed4 <balloc>
    800030a6:	0005091b          	sext.w	s2,a0
      if (addr) {
    800030aa:	fc090ee3          	beqz	s2,80003086 <bmap+0x92>
        a[bn] = addr;
    800030ae:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800030b2:	8552                	mv	a0,s4
    800030b4:	677000ef          	jal	80003f2a <log_write>
    800030b8:	b7f9                	j	80003086 <bmap+0x92>
    800030ba:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800030bc:	00004517          	auipc	a0,0x4
    800030c0:	35c50513          	addi	a0,a0,860 # 80007418 <etext+0x418>
    800030c4:	f2cfd0ef          	jal	800007f0 <panic>

00000000800030c8 <iget>:
{
    800030c8:	7179                	addi	sp,sp,-48
    800030ca:	f406                	sd	ra,40(sp)
    800030cc:	f022                	sd	s0,32(sp)
    800030ce:	ec26                	sd	s1,24(sp)
    800030d0:	e84a                	sd	s2,16(sp)
    800030d2:	e44e                	sd	s3,8(sp)
    800030d4:	e052                	sd	s4,0(sp)
    800030d6:	1800                	addi	s0,sp,48
    800030d8:	89aa                	mv	s3,a0
    800030da:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800030dc:	0001e517          	auipc	a0,0x1e
    800030e0:	c5c50513          	addi	a0,a0,-932 # 80020d38 <itable>
    800030e4:	aadfd0ef          	jal	80000b90 <acquire>
  empty = 0;
    800030e8:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    800030ea:	0001e497          	auipc	s1,0x1e
    800030ee:	c6648493          	addi	s1,s1,-922 # 80020d50 <itable+0x18>
    800030f2:	0001f697          	auipc	a3,0x1f
    800030f6:	6ee68693          	addi	a3,a3,1774 # 800227e0 <log>
    800030fa:	a039                	j	80003108 <iget+0x40>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    800030fc:	02090963          	beqz	s2,8000312e <iget+0x66>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003100:	08848493          	addi	s1,s1,136
    80003104:	02d48863          	beq	s1,a3,80003134 <iget+0x6c>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003108:	449c                	lw	a5,8(s1)
    8000310a:	fef059e3          	blez	a5,800030fc <iget+0x34>
    8000310e:	4098                	lw	a4,0(s1)
    80003110:	ff3716e3          	bne	a4,s3,800030fc <iget+0x34>
    80003114:	40d8                	lw	a4,4(s1)
    80003116:	ff4713e3          	bne	a4,s4,800030fc <iget+0x34>
      ip->ref++;
    8000311a:	2785                	addiw	a5,a5,1
    8000311c:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000311e:	0001e517          	auipc	a0,0x1e
    80003122:	c1a50513          	addi	a0,a0,-998 # 80020d38 <itable>
    80003126:	af7fd0ef          	jal	80000c1c <release>
      return ip;
    8000312a:	8926                	mv	s2,s1
    8000312c:	a02d                	j	80003156 <iget+0x8e>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    8000312e:	fbe9                	bnez	a5,80003100 <iget+0x38>
      empty = ip;
    80003130:	8926                	mv	s2,s1
    80003132:	b7f9                	j	80003100 <iget+0x38>
  if (empty == 0)
    80003134:	02090a63          	beqz	s2,80003168 <iget+0xa0>
  ip->dev = dev;
    80003138:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    8000313c:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003140:	4785                	li	a5,1
    80003142:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003146:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000314a:	0001e517          	auipc	a0,0x1e
    8000314e:	bee50513          	addi	a0,a0,-1042 # 80020d38 <itable>
    80003152:	acbfd0ef          	jal	80000c1c <release>
}
    80003156:	854a                	mv	a0,s2
    80003158:	70a2                	ld	ra,40(sp)
    8000315a:	7402                	ld	s0,32(sp)
    8000315c:	64e2                	ld	s1,24(sp)
    8000315e:	6942                	ld	s2,16(sp)
    80003160:	69a2                	ld	s3,8(sp)
    80003162:	6a02                	ld	s4,0(sp)
    80003164:	6145                	addi	sp,sp,48
    80003166:	8082                	ret
    panic("iget: no inodes");
    80003168:	00004517          	auipc	a0,0x4
    8000316c:	2c850513          	addi	a0,a0,712 # 80007430 <etext+0x430>
    80003170:	e80fd0ef          	jal	800007f0 <panic>

0000000080003174 <iinit>:
{
    80003174:	7179                	addi	sp,sp,-48
    80003176:	f406                	sd	ra,40(sp)
    80003178:	f022                	sd	s0,32(sp)
    8000317a:	ec26                	sd	s1,24(sp)
    8000317c:	e84a                	sd	s2,16(sp)
    8000317e:	e44e                	sd	s3,8(sp)
    80003180:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003182:	00004597          	auipc	a1,0x4
    80003186:	2be58593          	addi	a1,a1,702 # 80007440 <etext+0x440>
    8000318a:	0001e517          	auipc	a0,0x1e
    8000318e:	bae50513          	addi	a0,a0,-1106 # 80020d38 <itable>
    80003192:	989fd0ef          	jal	80000b1a <initlock>
  for (i = 0; i < NINODE; i++) {
    80003196:	0001e497          	auipc	s1,0x1e
    8000319a:	bca48493          	addi	s1,s1,-1078 # 80020d60 <itable+0x28>
    8000319e:	0001f997          	auipc	s3,0x1f
    800031a2:	65298993          	addi	s3,s3,1618 # 800227f0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800031a6:	00004917          	auipc	s2,0x4
    800031aa:	2a290913          	addi	s2,s2,674 # 80007448 <etext+0x448>
    800031ae:	85ca                	mv	a1,s2
    800031b0:	8526                	mv	a0,s1
    800031b2:	6ab000ef          	jal	8000405c <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    800031b6:	08848493          	addi	s1,s1,136
    800031ba:	ff349ae3          	bne	s1,s3,800031ae <iinit+0x3a>
}
    800031be:	70a2                	ld	ra,40(sp)
    800031c0:	7402                	ld	s0,32(sp)
    800031c2:	64e2                	ld	s1,24(sp)
    800031c4:	6942                	ld	s2,16(sp)
    800031c6:	69a2                	ld	s3,8(sp)
    800031c8:	6145                	addi	sp,sp,48
    800031ca:	8082                	ret

00000000800031cc <ialloc>:
{
    800031cc:	7139                	addi	sp,sp,-64
    800031ce:	fc06                	sd	ra,56(sp)
    800031d0:	f822                	sd	s0,48(sp)
    800031d2:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    800031d4:	0001e717          	auipc	a4,0x1e
    800031d8:	b5072703          	lw	a4,-1200(a4) # 80020d24 <sb+0xc>
    800031dc:	4785                	li	a5,1
    800031de:	06e7f063          	bgeu	a5,a4,8000323e <ialloc+0x72>
    800031e2:	f426                	sd	s1,40(sp)
    800031e4:	f04a                	sd	s2,32(sp)
    800031e6:	ec4e                	sd	s3,24(sp)
    800031e8:	e852                	sd	s4,16(sp)
    800031ea:	e456                	sd	s5,8(sp)
    800031ec:	e05a                	sd	s6,0(sp)
    800031ee:	8aaa                	mv	s5,a0
    800031f0:	8b2e                	mv	s6,a1
    800031f2:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    800031f4:	0001ea17          	auipc	s4,0x1e
    800031f8:	b24a0a13          	addi	s4,s4,-1244 # 80020d18 <sb>
    800031fc:	00495593          	srli	a1,s2,0x4
    80003200:	018a2783          	lw	a5,24(s4)
    80003204:	9dbd                	addw	a1,a1,a5
    80003206:	8556                	mv	a0,s5
    80003208:	a69ff0ef          	jal	80002c70 <bread>
    8000320c:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    8000320e:	05850993          	addi	s3,a0,88
    80003212:	00f97793          	andi	a5,s2,15
    80003216:	079a                	slli	a5,a5,0x6
    80003218:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    8000321a:	00099783          	lh	a5,0(s3)
    8000321e:	cb9d                	beqz	a5,80003254 <ialloc+0x88>
    brelse(bp);
    80003220:	b59ff0ef          	jal	80002d78 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003224:	0905                	addi	s2,s2,1
    80003226:	00ca2703          	lw	a4,12(s4)
    8000322a:	0009079b          	sext.w	a5,s2
    8000322e:	fce7e7e3          	bltu	a5,a4,800031fc <ialloc+0x30>
    80003232:	74a2                	ld	s1,40(sp)
    80003234:	7902                	ld	s2,32(sp)
    80003236:	69e2                	ld	s3,24(sp)
    80003238:	6a42                	ld	s4,16(sp)
    8000323a:	6aa2                	ld	s5,8(sp)
    8000323c:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    8000323e:	00004517          	auipc	a0,0x4
    80003242:	21250513          	addi	a0,a0,530 # 80007450 <etext+0x450>
    80003246:	ac4fd0ef          	jal	8000050a <printk>
  return 0;
    8000324a:	4501                	li	a0,0
}
    8000324c:	70e2                	ld	ra,56(sp)
    8000324e:	7442                	ld	s0,48(sp)
    80003250:	6121                	addi	sp,sp,64
    80003252:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003254:	04000613          	li	a2,64
    80003258:	4581                	li	a1,0
    8000325a:	854e                	mv	a0,s3
    8000325c:	9f9fd0ef          	jal	80000c54 <memset>
      dip->type = type;
    80003260:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    80003264:	8526                	mv	a0,s1
    80003266:	4c5000ef          	jal	80003f2a <log_write>
      brelse(bp);
    8000326a:	8526                	mv	a0,s1
    8000326c:	b0dff0ef          	jal	80002d78 <brelse>
      return iget(dev, inum);
    80003270:	0009059b          	sext.w	a1,s2
    80003274:	8556                	mv	a0,s5
    80003276:	e53ff0ef          	jal	800030c8 <iget>
    8000327a:	74a2                	ld	s1,40(sp)
    8000327c:	7902                	ld	s2,32(sp)
    8000327e:	69e2                	ld	s3,24(sp)
    80003280:	6a42                	ld	s4,16(sp)
    80003282:	6aa2                	ld	s5,8(sp)
    80003284:	6b02                	ld	s6,0(sp)
    80003286:	b7d9                	j	8000324c <ialloc+0x80>

0000000080003288 <iupdate>:
{
    80003288:	1101                	addi	sp,sp,-32
    8000328a:	ec06                	sd	ra,24(sp)
    8000328c:	e822                	sd	s0,16(sp)
    8000328e:	e426                	sd	s1,8(sp)
    80003290:	e04a                	sd	s2,0(sp)
    80003292:	1000                	addi	s0,sp,32
    80003294:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003296:	415c                	lw	a5,4(a0)
    80003298:	0047d79b          	srliw	a5,a5,0x4
    8000329c:	0001e597          	auipc	a1,0x1e
    800032a0:	a945a583          	lw	a1,-1388(a1) # 80020d30 <sb+0x18>
    800032a4:	9dbd                	addw	a1,a1,a5
    800032a6:	4108                	lw	a0,0(a0)
    800032a8:	9c9ff0ef          	jal	80002c70 <bread>
    800032ac:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    800032ae:	05850793          	addi	a5,a0,88
    800032b2:	40d8                	lw	a4,4(s1)
    800032b4:	8b3d                	andi	a4,a4,15
    800032b6:	071a                	slli	a4,a4,0x6
    800032b8:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800032ba:	04449703          	lh	a4,68(s1)
    800032be:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800032c2:	04649703          	lh	a4,70(s1)
    800032c6:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800032ca:	04849703          	lh	a4,72(s1)
    800032ce:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800032d2:	04a49703          	lh	a4,74(s1)
    800032d6:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800032da:	44f8                	lw	a4,76(s1)
    800032dc:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800032de:	03400613          	li	a2,52
    800032e2:	05048593          	addi	a1,s1,80
    800032e6:	00c78513          	addi	a0,a5,12
    800032ea:	9c7fd0ef          	jal	80000cb0 <memmove>
  log_write(bp);
    800032ee:	854a                	mv	a0,s2
    800032f0:	43b000ef          	jal	80003f2a <log_write>
  brelse(bp);
    800032f4:	854a                	mv	a0,s2
    800032f6:	a83ff0ef          	jal	80002d78 <brelse>
}
    800032fa:	60e2                	ld	ra,24(sp)
    800032fc:	6442                	ld	s0,16(sp)
    800032fe:	64a2                	ld	s1,8(sp)
    80003300:	6902                	ld	s2,0(sp)
    80003302:	6105                	addi	sp,sp,32
    80003304:	8082                	ret

0000000080003306 <idup>:
{
    80003306:	1101                	addi	sp,sp,-32
    80003308:	ec06                	sd	ra,24(sp)
    8000330a:	e822                	sd	s0,16(sp)
    8000330c:	e426                	sd	s1,8(sp)
    8000330e:	1000                	addi	s0,sp,32
    80003310:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003312:	0001e517          	auipc	a0,0x1e
    80003316:	a2650513          	addi	a0,a0,-1498 # 80020d38 <itable>
    8000331a:	877fd0ef          	jal	80000b90 <acquire>
  ip->ref++;
    8000331e:	449c                	lw	a5,8(s1)
    80003320:	2785                	addiw	a5,a5,1
    80003322:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003324:	0001e517          	auipc	a0,0x1e
    80003328:	a1450513          	addi	a0,a0,-1516 # 80020d38 <itable>
    8000332c:	8f1fd0ef          	jal	80000c1c <release>
}
    80003330:	8526                	mv	a0,s1
    80003332:	60e2                	ld	ra,24(sp)
    80003334:	6442                	ld	s0,16(sp)
    80003336:	64a2                	ld	s1,8(sp)
    80003338:	6105                	addi	sp,sp,32
    8000333a:	8082                	ret

000000008000333c <ilock>:
{
    8000333c:	1101                	addi	sp,sp,-32
    8000333e:	ec06                	sd	ra,24(sp)
    80003340:	e822                	sd	s0,16(sp)
    80003342:	e426                	sd	s1,8(sp)
    80003344:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003346:	cd19                	beqz	a0,80003364 <ilock+0x28>
    80003348:	84aa                	mv	s1,a0
    8000334a:	451c                	lw	a5,8(a0)
    8000334c:	00f05c63          	blez	a5,80003364 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003350:	0541                	addi	a0,a0,16
    80003352:	541000ef          	jal	80004092 <acquiresleep>
  if (ip->valid == 0) {
    80003356:	40bc                	lw	a5,64(s1)
    80003358:	cf89                	beqz	a5,80003372 <ilock+0x36>
}
    8000335a:	60e2                	ld	ra,24(sp)
    8000335c:	6442                	ld	s0,16(sp)
    8000335e:	64a2                	ld	s1,8(sp)
    80003360:	6105                	addi	sp,sp,32
    80003362:	8082                	ret
    80003364:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003366:	00004517          	auipc	a0,0x4
    8000336a:	10250513          	addi	a0,a0,258 # 80007468 <etext+0x468>
    8000336e:	c82fd0ef          	jal	800007f0 <panic>
    80003372:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003374:	40dc                	lw	a5,4(s1)
    80003376:	0047d79b          	srliw	a5,a5,0x4
    8000337a:	0001e597          	auipc	a1,0x1e
    8000337e:	9b65a583          	lw	a1,-1610(a1) # 80020d30 <sb+0x18>
    80003382:	9dbd                	addw	a1,a1,a5
    80003384:	4088                	lw	a0,0(s1)
    80003386:	8ebff0ef          	jal	80002c70 <bread>
    8000338a:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    8000338c:	05850593          	addi	a1,a0,88
    80003390:	40dc                	lw	a5,4(s1)
    80003392:	8bbd                	andi	a5,a5,15
    80003394:	079a                	slli	a5,a5,0x6
    80003396:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003398:	00059783          	lh	a5,0(a1)
    8000339c:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800033a0:	00259783          	lh	a5,2(a1)
    800033a4:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800033a8:	00459783          	lh	a5,4(a1)
    800033ac:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800033b0:	00659783          	lh	a5,6(a1)
    800033b4:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800033b8:	459c                	lw	a5,8(a1)
    800033ba:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800033bc:	03400613          	li	a2,52
    800033c0:	05b1                	addi	a1,a1,12
    800033c2:	05048513          	addi	a0,s1,80
    800033c6:	8ebfd0ef          	jal	80000cb0 <memmove>
    brelse(bp);
    800033ca:	854a                	mv	a0,s2
    800033cc:	9adff0ef          	jal	80002d78 <brelse>
    ip->valid = 1;
    800033d0:	4785                	li	a5,1
    800033d2:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    800033d4:	04449783          	lh	a5,68(s1)
    800033d8:	c399                	beqz	a5,800033de <ilock+0xa2>
    800033da:	6902                	ld	s2,0(sp)
    800033dc:	bfbd                	j	8000335a <ilock+0x1e>
      panic("ilock: no type");
    800033de:	00004517          	auipc	a0,0x4
    800033e2:	09250513          	addi	a0,a0,146 # 80007470 <etext+0x470>
    800033e6:	c0afd0ef          	jal	800007f0 <panic>

00000000800033ea <iunlock>:
{
    800033ea:	1101                	addi	sp,sp,-32
    800033ec:	ec06                	sd	ra,24(sp)
    800033ee:	e822                	sd	s0,16(sp)
    800033f0:	e426                	sd	s1,8(sp)
    800033f2:	e04a                	sd	s2,0(sp)
    800033f4:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800033f6:	c505                	beqz	a0,8000341e <iunlock+0x34>
    800033f8:	84aa                	mv	s1,a0
    800033fa:	01050913          	addi	s2,a0,16
    800033fe:	854a                	mv	a0,s2
    80003400:	51f000ef          	jal	8000411e <holdingsleep>
    80003404:	cd09                	beqz	a0,8000341e <iunlock+0x34>
    80003406:	449c                	lw	a5,8(s1)
    80003408:	00f05b63          	blez	a5,8000341e <iunlock+0x34>
  releasesleep(&ip->lock);
    8000340c:	854a                	mv	a0,s2
    8000340e:	4d9000ef          	jal	800040e6 <releasesleep>
}
    80003412:	60e2                	ld	ra,24(sp)
    80003414:	6442                	ld	s0,16(sp)
    80003416:	64a2                	ld	s1,8(sp)
    80003418:	6902                	ld	s2,0(sp)
    8000341a:	6105                	addi	sp,sp,32
    8000341c:	8082                	ret
    panic("iunlock");
    8000341e:	00004517          	auipc	a0,0x4
    80003422:	06250513          	addi	a0,a0,98 # 80007480 <etext+0x480>
    80003426:	bcafd0ef          	jal	800007f0 <panic>

000000008000342a <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000342a:	7179                	addi	sp,sp,-48
    8000342c:	f406                	sd	ra,40(sp)
    8000342e:	f022                	sd	s0,32(sp)
    80003430:	ec26                	sd	s1,24(sp)
    80003432:	e84a                	sd	s2,16(sp)
    80003434:	e44e                	sd	s3,8(sp)
    80003436:	1800                	addi	s0,sp,48
    80003438:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    8000343a:	05050493          	addi	s1,a0,80
    8000343e:	08050913          	addi	s2,a0,128
    80003442:	a021                	j	8000344a <itrunc+0x20>
    80003444:	0491                	addi	s1,s1,4
    80003446:	01248b63          	beq	s1,s2,8000345c <itrunc+0x32>
    if (ip->addrs[i]) {
    8000344a:	408c                	lw	a1,0(s1)
    8000344c:	dde5                	beqz	a1,80003444 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000344e:	0009a503          	lw	a0,0(s3)
    80003452:	a17ff0ef          	jal	80002e68 <bfree>
      ip->addrs[i] = 0;
    80003456:	0004a023          	sw	zero,0(s1)
    8000345a:	b7ed                	j	80003444 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    8000345c:	0809a583          	lw	a1,128(s3)
    80003460:	ed89                	bnez	a1,8000347a <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003462:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003466:	854e                	mv	a0,s3
    80003468:	e21ff0ef          	jal	80003288 <iupdate>
}
    8000346c:	70a2                	ld	ra,40(sp)
    8000346e:	7402                	ld	s0,32(sp)
    80003470:	64e2                	ld	s1,24(sp)
    80003472:	6942                	ld	s2,16(sp)
    80003474:	69a2                	ld	s3,8(sp)
    80003476:	6145                	addi	sp,sp,48
    80003478:	8082                	ret
    8000347a:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000347c:	0009a503          	lw	a0,0(s3)
    80003480:	ff0ff0ef          	jal	80002c70 <bread>
    80003484:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    80003486:	05850493          	addi	s1,a0,88
    8000348a:	45850913          	addi	s2,a0,1112
    8000348e:	a021                	j	80003496 <itrunc+0x6c>
    80003490:	0491                	addi	s1,s1,4
    80003492:	01248963          	beq	s1,s2,800034a4 <itrunc+0x7a>
      if (a[j])
    80003496:	408c                	lw	a1,0(s1)
    80003498:	dde5                	beqz	a1,80003490 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    8000349a:	0009a503          	lw	a0,0(s3)
    8000349e:	9cbff0ef          	jal	80002e68 <bfree>
    800034a2:	b7fd                	j	80003490 <itrunc+0x66>
    brelse(bp);
    800034a4:	8552                	mv	a0,s4
    800034a6:	8d3ff0ef          	jal	80002d78 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800034aa:	0809a583          	lw	a1,128(s3)
    800034ae:	0009a503          	lw	a0,0(s3)
    800034b2:	9b7ff0ef          	jal	80002e68 <bfree>
    ip->addrs[NDIRECT] = 0;
    800034b6:	0809a023          	sw	zero,128(s3)
    800034ba:	6a02                	ld	s4,0(sp)
    800034bc:	b75d                	j	80003462 <itrunc+0x38>

00000000800034be <iput>:
{
    800034be:	7179                	addi	sp,sp,-48
    800034c0:	f406                	sd	ra,40(sp)
    800034c2:	f022                	sd	s0,32(sp)
    800034c4:	ec26                	sd	s1,24(sp)
    800034c6:	1800                	addi	s0,sp,48
    800034c8:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034ca:	0001e517          	auipc	a0,0x1e
    800034ce:	86e50513          	addi	a0,a0,-1938 # 80020d38 <itable>
    800034d2:	ebefd0ef          	jal	80000b90 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800034d6:	449c                	lw	a5,8(s1)
    800034d8:	4705                	li	a4,1
    800034da:	00e78f63          	beq	a5,a4,800034f8 <iput+0x3a>
  ip->ref--;
    800034de:	37fd                	addiw	a5,a5,-1
    800034e0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034e2:	0001e517          	auipc	a0,0x1e
    800034e6:	85650513          	addi	a0,a0,-1962 # 80020d38 <itable>
    800034ea:	f32fd0ef          	jal	80000c1c <release>
}
    800034ee:	70a2                	ld	ra,40(sp)
    800034f0:	7402                	ld	s0,32(sp)
    800034f2:	64e2                	ld	s1,24(sp)
    800034f4:	6145                	addi	sp,sp,48
    800034f6:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800034f8:	40b8                	lw	a4,64(s1)
    800034fa:	d375                	beqz	a4,800034de <iput+0x20>
    800034fc:	e84a                	sd	s2,16(sp)
    800034fe:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    80003500:	0004aa03          	lw	s4,0(s1)
    80003504:	0044a903          	lw	s2,4(s1)
  if (last) {
    80003508:	04a49703          	lh	a4,74(s1)
    8000350c:	ef35                	bnez	a4,80003588 <iput+0xca>
    8000350e:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    80003510:	01048993          	addi	s3,s1,16
    80003514:	854e                	mv	a0,s3
    80003516:	37d000ef          	jal	80004092 <acquiresleep>
    release(&itable.lock);
    8000351a:	0001e517          	auipc	a0,0x1e
    8000351e:	81e50513          	addi	a0,a0,-2018 # 80020d38 <itable>
    80003522:	efafd0ef          	jal	80000c1c <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003526:	8526                	mv	a0,s1
    80003528:	f03ff0ef          	jal	8000342a <itrunc>
    ip->valid = 0;
    8000352c:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003530:	854e                	mv	a0,s3
    80003532:	3b5000ef          	jal	800040e6 <releasesleep>
    acquire(&itable.lock);
    80003536:	0001e517          	auipc	a0,0x1e
    8000353a:	80250513          	addi	a0,a0,-2046 # 80020d38 <itable>
    8000353e:	e52fd0ef          	jal	80000b90 <acquire>
  ip->ref--;
    80003542:	449c                	lw	a5,8(s1)
    80003544:	37fd                	addiw	a5,a5,-1
    80003546:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003548:	0001d517          	auipc	a0,0x1d
    8000354c:	7f050513          	addi	a0,a0,2032 # 80020d38 <itable>
    80003550:	eccfd0ef          	jal	80000c1c <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003554:	0049559b          	srliw	a1,s2,0x4
    80003558:	0001d797          	auipc	a5,0x1d
    8000355c:	7d87a783          	lw	a5,2008(a5) # 80020d30 <sb+0x18>
    80003560:	9dbd                	addw	a1,a1,a5
    80003562:	8552                	mv	a0,s4
    80003564:	f0cff0ef          	jal	80002c70 <bread>
    80003568:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000356a:	00f97913          	andi	s2,s2,15
  dip->type = 0;
    8000356e:	091a                	slli	s2,s2,0x6
    80003570:	992a                	add	s2,s2,a0
    80003572:	04091c23          	sh	zero,88(s2)
  log_write(bp);
    80003576:	1b5000ef          	jal	80003f2a <log_write>
  brelse(bp);
    8000357a:	8526                	mv	a0,s1
    8000357c:	ffcff0ef          	jal	80002d78 <brelse>
}
    80003580:	6942                	ld	s2,16(sp)
    80003582:	69a2                	ld	s3,8(sp)
    80003584:	6a02                	ld	s4,0(sp)
    80003586:	b7a5                	j	800034ee <iput+0x30>
    80003588:	6942                	ld	s2,16(sp)
    8000358a:	6a02                	ld	s4,0(sp)
    8000358c:	bf89                	j	800034de <iput+0x20>

000000008000358e <iunlockput>:
{
    8000358e:	1101                	addi	sp,sp,-32
    80003590:	ec06                	sd	ra,24(sp)
    80003592:	e822                	sd	s0,16(sp)
    80003594:	e426                	sd	s1,8(sp)
    80003596:	1000                	addi	s0,sp,32
    80003598:	84aa                	mv	s1,a0
  iunlock(ip);
    8000359a:	e51ff0ef          	jal	800033ea <iunlock>
  iput(ip);
    8000359e:	8526                	mv	a0,s1
    800035a0:	f1fff0ef          	jal	800034be <iput>
}
    800035a4:	60e2                	ld	ra,24(sp)
    800035a6:	6442                	ld	s0,16(sp)
    800035a8:	64a2                	ld	s1,8(sp)
    800035aa:	6105                	addi	sp,sp,32
    800035ac:	8082                	ret

00000000800035ae <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035ae:	0001d717          	auipc	a4,0x1d
    800035b2:	77672703          	lw	a4,1910(a4) # 80020d24 <sb+0xc>
    800035b6:	4785                	li	a5,1
    800035b8:	0ae7ff63          	bgeu	a5,a4,80003676 <ireclaim+0xc8>
{
    800035bc:	7139                	addi	sp,sp,-64
    800035be:	fc06                	sd	ra,56(sp)
    800035c0:	f822                	sd	s0,48(sp)
    800035c2:	f426                	sd	s1,40(sp)
    800035c4:	f04a                	sd	s2,32(sp)
    800035c6:	ec4e                	sd	s3,24(sp)
    800035c8:	e852                	sd	s4,16(sp)
    800035ca:	e456                	sd	s5,8(sp)
    800035cc:	e05a                	sd	s6,0(sp)
    800035ce:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035d0:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800035d2:	00050a1b          	sext.w	s4,a0
    800035d6:	0001da97          	auipc	s5,0x1d
    800035da:	742a8a93          	addi	s5,s5,1858 # 80020d18 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    800035de:	00004b17          	auipc	s6,0x4
    800035e2:	eaab0b13          	addi	s6,s6,-342 # 80007488 <etext+0x488>
    800035e6:	a099                	j	8000362c <ireclaim+0x7e>
    800035e8:	85ce                	mv	a1,s3
    800035ea:	855a                	mv	a0,s6
    800035ec:	f1ffc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    800035f0:	85ce                	mv	a1,s3
    800035f2:	8552                	mv	a0,s4
    800035f4:	ad5ff0ef          	jal	800030c8 <iget>
    800035f8:	89aa                	mv	s3,a0
    brelse(bp);
    800035fa:	854a                	mv	a0,s2
    800035fc:	f7cff0ef          	jal	80002d78 <brelse>
    if (ip) {
    80003600:	00098f63          	beqz	s3,8000361e <ireclaim+0x70>
      begin_op();
    80003604:	780000ef          	jal	80003d84 <begin_op>
      ilock(ip);
    80003608:	854e                	mv	a0,s3
    8000360a:	d33ff0ef          	jal	8000333c <ilock>
      iunlock(ip);
    8000360e:	854e                	mv	a0,s3
    80003610:	ddbff0ef          	jal	800033ea <iunlock>
      iput(ip);
    80003614:	854e                	mv	a0,s3
    80003616:	ea9ff0ef          	jal	800034be <iput>
      end_op();
    8000361a:	7f0000ef          	jal	80003e0a <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000361e:	0485                	addi	s1,s1,1
    80003620:	00caa703          	lw	a4,12(s5)
    80003624:	0004879b          	sext.w	a5,s1
    80003628:	02e7fd63          	bgeu	a5,a4,80003662 <ireclaim+0xb4>
    8000362c:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003630:	0044d593          	srli	a1,s1,0x4
    80003634:	018aa783          	lw	a5,24(s5)
    80003638:	9dbd                	addw	a1,a1,a5
    8000363a:	8552                	mv	a0,s4
    8000363c:	e34ff0ef          	jal	80002c70 <bread>
    80003640:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003642:	05850793          	addi	a5,a0,88
    80003646:	00f9f713          	andi	a4,s3,15
    8000364a:	071a                	slli	a4,a4,0x6
    8000364c:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    8000364e:	00079703          	lh	a4,0(a5)
    80003652:	c701                	beqz	a4,8000365a <ireclaim+0xac>
    80003654:	00679783          	lh	a5,6(a5)
    80003658:	dbc1                	beqz	a5,800035e8 <ireclaim+0x3a>
    brelse(bp);
    8000365a:	854a                	mv	a0,s2
    8000365c:	f1cff0ef          	jal	80002d78 <brelse>
    if (ip) {
    80003660:	bf7d                	j	8000361e <ireclaim+0x70>
}
    80003662:	70e2                	ld	ra,56(sp)
    80003664:	7442                	ld	s0,48(sp)
    80003666:	74a2                	ld	s1,40(sp)
    80003668:	7902                	ld	s2,32(sp)
    8000366a:	69e2                	ld	s3,24(sp)
    8000366c:	6a42                	ld	s4,16(sp)
    8000366e:	6aa2                	ld	s5,8(sp)
    80003670:	6b02                	ld	s6,0(sp)
    80003672:	6121                	addi	sp,sp,64
    80003674:	8082                	ret
    80003676:	8082                	ret

0000000080003678 <fsinit>:
{
    80003678:	7179                	addi	sp,sp,-48
    8000367a:	f406                	sd	ra,40(sp)
    8000367c:	f022                	sd	s0,32(sp)
    8000367e:	ec26                	sd	s1,24(sp)
    80003680:	e84a                	sd	s2,16(sp)
    80003682:	e44e                	sd	s3,8(sp)
    80003684:	1800                	addi	s0,sp,48
    80003686:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    80003688:	4585                	li	a1,1
    8000368a:	de6ff0ef          	jal	80002c70 <bread>
    8000368e:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003690:	0001d997          	auipc	s3,0x1d
    80003694:	68898993          	addi	s3,s3,1672 # 80020d18 <sb>
    80003698:	02000613          	li	a2,32
    8000369c:	05850593          	addi	a1,a0,88
    800036a0:	854e                	mv	a0,s3
    800036a2:	e0efd0ef          	jal	80000cb0 <memmove>
  brelse(bp);
    800036a6:	854a                	mv	a0,s2
    800036a8:	ed0ff0ef          	jal	80002d78 <brelse>
  if (sb.magic != FSMAGIC)
    800036ac:	0009a703          	lw	a4,0(s3)
    800036b0:	102037b7          	lui	a5,0x10203
    800036b4:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800036b8:	02f71363          	bne	a4,a5,800036de <fsinit+0x66>
  initlog(dev, &sb);
    800036bc:	0001d597          	auipc	a1,0x1d
    800036c0:	65c58593          	addi	a1,a1,1628 # 80020d18 <sb>
    800036c4:	8526                	mv	a0,s1
    800036c6:	640000ef          	jal	80003d06 <initlog>
  ireclaim(dev);
    800036ca:	8526                	mv	a0,s1
    800036cc:	ee3ff0ef          	jal	800035ae <ireclaim>
}
    800036d0:	70a2                	ld	ra,40(sp)
    800036d2:	7402                	ld	s0,32(sp)
    800036d4:	64e2                	ld	s1,24(sp)
    800036d6:	6942                	ld	s2,16(sp)
    800036d8:	69a2                	ld	s3,8(sp)
    800036da:	6145                	addi	sp,sp,48
    800036dc:	8082                	ret
    panic("invalid file system");
    800036de:	00004517          	auipc	a0,0x4
    800036e2:	dca50513          	addi	a0,a0,-566 # 800074a8 <etext+0x4a8>
    800036e6:	90afd0ef          	jal	800007f0 <panic>

00000000800036ea <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800036ea:	1141                	addi	sp,sp,-16
    800036ec:	e422                	sd	s0,8(sp)
    800036ee:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800036f0:	411c                	lw	a5,0(a0)
    800036f2:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800036f4:	415c                	lw	a5,4(a0)
    800036f6:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800036f8:	04451783          	lh	a5,68(a0)
    800036fc:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003700:	04a51783          	lh	a5,74(a0)
    80003704:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003708:	04c56783          	lwu	a5,76(a0)
    8000370c:	e99c                	sd	a5,16(a1)
}
    8000370e:	6422                	ld	s0,8(sp)
    80003710:	0141                	addi	sp,sp,16
    80003712:	8082                	ret

0000000080003714 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003714:	457c                	lw	a5,76(a0)
    80003716:	0ed7eb63          	bltu	a5,a3,8000380c <readi+0xf8>
{
    8000371a:	7159                	addi	sp,sp,-112
    8000371c:	f486                	sd	ra,104(sp)
    8000371e:	f0a2                	sd	s0,96(sp)
    80003720:	eca6                	sd	s1,88(sp)
    80003722:	e0d2                	sd	s4,64(sp)
    80003724:	fc56                	sd	s5,56(sp)
    80003726:	f85a                	sd	s6,48(sp)
    80003728:	f45e                	sd	s7,40(sp)
    8000372a:	1880                	addi	s0,sp,112
    8000372c:	8b2a                	mv	s6,a0
    8000372e:	8bae                	mv	s7,a1
    80003730:	8a32                	mv	s4,a2
    80003732:	84b6                	mv	s1,a3
    80003734:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003736:	9f35                	addw	a4,a4,a3
    return 0;
    80003738:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    8000373a:	0cd76063          	bltu	a4,a3,800037fa <readi+0xe6>
    8000373e:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003740:	00e7f463          	bgeu	a5,a4,80003748 <readi+0x34>
    n = ip->size - off;
    80003744:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003748:	080a8f63          	beqz	s5,800037e6 <readi+0xd2>
    8000374c:	e8ca                	sd	s2,80(sp)
    8000374e:	f062                	sd	s8,32(sp)
    80003750:	ec66                	sd	s9,24(sp)
    80003752:	e86a                	sd	s10,16(sp)
    80003754:	e46e                	sd	s11,8(sp)
    80003756:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003758:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000375c:	5c7d                	li	s8,-1
    8000375e:	a80d                	j	80003790 <readi+0x7c>
    80003760:	020d1d93          	slli	s11,s10,0x20
    80003764:	020ddd93          	srli	s11,s11,0x20
    80003768:	05890613          	addi	a2,s2,88
    8000376c:	86ee                	mv	a3,s11
    8000376e:	963a                	add	a2,a2,a4
    80003770:	85d2                	mv	a1,s4
    80003772:	855e                	mv	a0,s7
    80003774:	b15fe0ef          	jal	80002288 <either_copyout>
    80003778:	05850763          	beq	a0,s8,800037c6 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000377c:	854a                	mv	a0,s2
    8000377e:	dfaff0ef          	jal	80002d78 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003782:	013d09bb          	addw	s3,s10,s3
    80003786:	009d04bb          	addw	s1,s10,s1
    8000378a:	9a6e                	add	s4,s4,s11
    8000378c:	0559f763          	bgeu	s3,s5,800037da <readi+0xc6>
    uint addr = bmap(ip, off / BSIZE);
    80003790:	00a4d59b          	srliw	a1,s1,0xa
    80003794:	855a                	mv	a0,s6
    80003796:	85fff0ef          	jal	80002ff4 <bmap>
    8000379a:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    8000379e:	c5b1                	beqz	a1,800037ea <readi+0xd6>
    bp = bread(ip->dev, addr);
    800037a0:	000b2503          	lw	a0,0(s6)
    800037a4:	cccff0ef          	jal	80002c70 <bread>
    800037a8:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800037aa:	3ff4f713          	andi	a4,s1,1023
    800037ae:	40ec87bb          	subw	a5,s9,a4
    800037b2:	413a86bb          	subw	a3,s5,s3
    800037b6:	8d3e                	mv	s10,a5
    800037b8:	2781                	sext.w	a5,a5
    800037ba:	0006861b          	sext.w	a2,a3
    800037be:	faf671e3          	bgeu	a2,a5,80003760 <readi+0x4c>
    800037c2:	8d36                	mv	s10,a3
    800037c4:	bf71                	j	80003760 <readi+0x4c>
      brelse(bp);
    800037c6:	854a                	mv	a0,s2
    800037c8:	db0ff0ef          	jal	80002d78 <brelse>
      tot = -1;
    800037cc:	59fd                	li	s3,-1
      break;
    800037ce:	6946                	ld	s2,80(sp)
    800037d0:	7c02                	ld	s8,32(sp)
    800037d2:	6ce2                	ld	s9,24(sp)
    800037d4:	6d42                	ld	s10,16(sp)
    800037d6:	6da2                	ld	s11,8(sp)
    800037d8:	a831                	j	800037f4 <readi+0xe0>
    800037da:	6946                	ld	s2,80(sp)
    800037dc:	7c02                	ld	s8,32(sp)
    800037de:	6ce2                	ld	s9,24(sp)
    800037e0:	6d42                	ld	s10,16(sp)
    800037e2:	6da2                	ld	s11,8(sp)
    800037e4:	a801                	j	800037f4 <readi+0xe0>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800037e6:	89d6                	mv	s3,s5
    800037e8:	a031                	j	800037f4 <readi+0xe0>
    800037ea:	6946                	ld	s2,80(sp)
    800037ec:	7c02                	ld	s8,32(sp)
    800037ee:	6ce2                	ld	s9,24(sp)
    800037f0:	6d42                	ld	s10,16(sp)
    800037f2:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800037f4:	0009851b          	sext.w	a0,s3
    800037f8:	69a6                	ld	s3,72(sp)
}
    800037fa:	70a6                	ld	ra,104(sp)
    800037fc:	7406                	ld	s0,96(sp)
    800037fe:	64e6                	ld	s1,88(sp)
    80003800:	6a06                	ld	s4,64(sp)
    80003802:	7ae2                	ld	s5,56(sp)
    80003804:	7b42                	ld	s6,48(sp)
    80003806:	7ba2                	ld	s7,40(sp)
    80003808:	6165                	addi	sp,sp,112
    8000380a:	8082                	ret
    return 0;
    8000380c:	4501                	li	a0,0
}
    8000380e:	8082                	ret

0000000080003810 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003810:	457c                	lw	a5,76(a0)
    80003812:	10d7e363          	bltu	a5,a3,80003918 <writei+0x108>
{
    80003816:	7159                	addi	sp,sp,-112
    80003818:	f486                	sd	ra,104(sp)
    8000381a:	f0a2                	sd	s0,96(sp)
    8000381c:	e8ca                	sd	s2,80(sp)
    8000381e:	e0d2                	sd	s4,64(sp)
    80003820:	fc56                	sd	s5,56(sp)
    80003822:	f85a                	sd	s6,48(sp)
    80003824:	f45e                	sd	s7,40(sp)
    80003826:	1880                	addi	s0,sp,112
    80003828:	8aaa                	mv	s5,a0
    8000382a:	8bae                	mv	s7,a1
    8000382c:	8a32                	mv	s4,a2
    8000382e:	8936                	mv	s2,a3
    80003830:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003832:	00e687bb          	addw	a5,a3,a4
    80003836:	0ed7e363          	bltu	a5,a3,8000391c <writei+0x10c>
    return -1;
  if (off + n > MAXFILE * BSIZE)
    8000383a:	00043737          	lui	a4,0x43
    8000383e:	0ef76163          	bltu	a4,a5,80003920 <writei+0x110>
    80003842:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003844:	0c0b0263          	beqz	s6,80003908 <writei+0xf8>
    80003848:	eca6                	sd	s1,88(sp)
    8000384a:	f062                	sd	s8,32(sp)
    8000384c:	ec66                	sd	s9,24(sp)
    8000384e:	e86a                	sd	s10,16(sp)
    80003850:	e46e                	sd	s11,8(sp)
    80003852:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003854:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003858:	5c7d                	li	s8,-1
    8000385a:	a825                	j	80003892 <writei+0x82>
    8000385c:	020d1d93          	slli	s11,s10,0x20
    80003860:	020ddd93          	srli	s11,s11,0x20
    80003864:	05848513          	addi	a0,s1,88
    80003868:	86ee                	mv	a3,s11
    8000386a:	8652                	mv	a2,s4
    8000386c:	85de                	mv	a1,s7
    8000386e:	953a                	add	a0,a0,a4
    80003870:	a65fe0ef          	jal	800022d4 <either_copyin>
    80003874:	05850a63          	beq	a0,s8,800038c8 <writei+0xb8>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003878:	8526                	mv	a0,s1
    8000387a:	6b0000ef          	jal	80003f2a <log_write>
    brelse(bp);
    8000387e:	8526                	mv	a0,s1
    80003880:	cf8ff0ef          	jal	80002d78 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003884:	013d09bb          	addw	s3,s10,s3
    80003888:	012d093b          	addw	s2,s10,s2
    8000388c:	9a6e                	add	s4,s4,s11
    8000388e:	0569f363          	bgeu	s3,s6,800038d4 <writei+0xc4>
    uint addr = bmap(ip, off / BSIZE);
    80003892:	00a9559b          	srliw	a1,s2,0xa
    80003896:	8556                	mv	a0,s5
    80003898:	f5cff0ef          	jal	80002ff4 <bmap>
    8000389c:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    800038a0:	c995                	beqz	a1,800038d4 <writei+0xc4>
    bp = bread(ip->dev, addr);
    800038a2:	000aa503          	lw	a0,0(s5)
    800038a6:	bcaff0ef          	jal	80002c70 <bread>
    800038aa:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800038ac:	3ff97713          	andi	a4,s2,1023
    800038b0:	40ec87bb          	subw	a5,s9,a4
    800038b4:	413b06bb          	subw	a3,s6,s3
    800038b8:	8d3e                	mv	s10,a5
    800038ba:	2781                	sext.w	a5,a5
    800038bc:	0006861b          	sext.w	a2,a3
    800038c0:	f8f67ee3          	bgeu	a2,a5,8000385c <writei+0x4c>
    800038c4:	8d36                	mv	s10,a3
    800038c6:	bf59                	j	8000385c <writei+0x4c>
      log_write(bp);
    800038c8:	8526                	mv	a0,s1
    800038ca:	660000ef          	jal	80003f2a <log_write>
      brelse(bp);
    800038ce:	8526                	mv	a0,s1
    800038d0:	ca8ff0ef          	jal	80002d78 <brelse>
  }

  if (off > ip->size)
    800038d4:	04caa783          	lw	a5,76(s5)
    800038d8:	0327fa63          	bgeu	a5,s2,8000390c <writei+0xfc>
    ip->size = off;
    800038dc:	052aa623          	sw	s2,76(s5)
    800038e0:	64e6                	ld	s1,88(sp)
    800038e2:	7c02                	ld	s8,32(sp)
    800038e4:	6ce2                	ld	s9,24(sp)
    800038e6:	6d42                	ld	s10,16(sp)
    800038e8:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800038ea:	8556                	mv	a0,s5
    800038ec:	99dff0ef          	jal	80003288 <iupdate>

  return tot;
    800038f0:	0009851b          	sext.w	a0,s3
    800038f4:	69a6                	ld	s3,72(sp)
}
    800038f6:	70a6                	ld	ra,104(sp)
    800038f8:	7406                	ld	s0,96(sp)
    800038fa:	6946                	ld	s2,80(sp)
    800038fc:	6a06                	ld	s4,64(sp)
    800038fe:	7ae2                	ld	s5,56(sp)
    80003900:	7b42                	ld	s6,48(sp)
    80003902:	7ba2                	ld	s7,40(sp)
    80003904:	6165                	addi	sp,sp,112
    80003906:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003908:	89da                	mv	s3,s6
    8000390a:	b7c5                	j	800038ea <writei+0xda>
    8000390c:	64e6                	ld	s1,88(sp)
    8000390e:	7c02                	ld	s8,32(sp)
    80003910:	6ce2                	ld	s9,24(sp)
    80003912:	6d42                	ld	s10,16(sp)
    80003914:	6da2                	ld	s11,8(sp)
    80003916:	bfd1                	j	800038ea <writei+0xda>
    return -1;
    80003918:	557d                	li	a0,-1
}
    8000391a:	8082                	ret
    return -1;
    8000391c:	557d                	li	a0,-1
    8000391e:	bfe1                	j	800038f6 <writei+0xe6>
    return -1;
    80003920:	557d                	li	a0,-1
    80003922:	bfd1                	j	800038f6 <writei+0xe6>

0000000080003924 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003924:	1141                	addi	sp,sp,-16
    80003926:	e406                	sd	ra,8(sp)
    80003928:	e022                	sd	s0,0(sp)
    8000392a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000392c:	4639                	li	a2,14
    8000392e:	bf2fd0ef          	jal	80000d20 <strncmp>
}
    80003932:	60a2                	ld	ra,8(sp)
    80003934:	6402                	ld	s0,0(sp)
    80003936:	0141                	addi	sp,sp,16
    80003938:	8082                	ret

000000008000393a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000393a:	7139                	addi	sp,sp,-64
    8000393c:	fc06                	sd	ra,56(sp)
    8000393e:	f822                	sd	s0,48(sp)
    80003940:	f426                	sd	s1,40(sp)
    80003942:	f04a                	sd	s2,32(sp)
    80003944:	ec4e                	sd	s3,24(sp)
    80003946:	e852                	sd	s4,16(sp)
    80003948:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    8000394a:	04451703          	lh	a4,68(a0)
    8000394e:	4785                	li	a5,1
    80003950:	00f71a63          	bne	a4,a5,80003964 <dirlookup+0x2a>
    80003954:	892a                	mv	s2,a0
    80003956:	89ae                	mv	s3,a1
    80003958:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000395a:	457c                	lw	a5,76(a0)
    8000395c:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000395e:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003960:	e39d                	bnez	a5,80003986 <dirlookup+0x4c>
    80003962:	a095                	j	800039c6 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003964:	00004517          	auipc	a0,0x4
    80003968:	b5c50513          	addi	a0,a0,-1188 # 800074c0 <etext+0x4c0>
    8000396c:	e85fc0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    80003970:	00004517          	auipc	a0,0x4
    80003974:	b6850513          	addi	a0,a0,-1176 # 800074d8 <etext+0x4d8>
    80003978:	e79fc0ef          	jal	800007f0 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000397c:	24c1                	addiw	s1,s1,16
    8000397e:	04c92783          	lw	a5,76(s2)
    80003982:	04f4f163          	bgeu	s1,a5,800039c4 <dirlookup+0x8a>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003986:	4741                	li	a4,16
    80003988:	86a6                	mv	a3,s1
    8000398a:	fc040613          	addi	a2,s0,-64
    8000398e:	4581                	li	a1,0
    80003990:	854a                	mv	a0,s2
    80003992:	d83ff0ef          	jal	80003714 <readi>
    80003996:	47c1                	li	a5,16
    80003998:	fcf51ce3          	bne	a0,a5,80003970 <dirlookup+0x36>
    if (de.inum == 0)
    8000399c:	fc045783          	lhu	a5,-64(s0)
    800039a0:	dff1                	beqz	a5,8000397c <dirlookup+0x42>
    if (namecmp(name, de.name) == 0) {
    800039a2:	fc240593          	addi	a1,s0,-62
    800039a6:	854e                	mv	a0,s3
    800039a8:	f7dff0ef          	jal	80003924 <namecmp>
    800039ac:	f961                	bnez	a0,8000397c <dirlookup+0x42>
      if (poff)
    800039ae:	000a0463          	beqz	s4,800039b6 <dirlookup+0x7c>
        *poff = off;
    800039b2:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    800039b6:	fc045583          	lhu	a1,-64(s0)
    800039ba:	00092503          	lw	a0,0(s2)
    800039be:	f0aff0ef          	jal	800030c8 <iget>
    800039c2:	a011                	j	800039c6 <dirlookup+0x8c>
  return 0;
    800039c4:	4501                	li	a0,0
}
    800039c6:	70e2                	ld	ra,56(sp)
    800039c8:	7442                	ld	s0,48(sp)
    800039ca:	74a2                	ld	s1,40(sp)
    800039cc:	7902                	ld	s2,32(sp)
    800039ce:	69e2                	ld	s3,24(sp)
    800039d0:	6a42                	ld	s4,16(sp)
    800039d2:	6121                	addi	sp,sp,64
    800039d4:	8082                	ret

00000000800039d6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    800039d6:	711d                	addi	sp,sp,-96
    800039d8:	ec86                	sd	ra,88(sp)
    800039da:	e8a2                	sd	s0,80(sp)
    800039dc:	e4a6                	sd	s1,72(sp)
    800039de:	e0ca                	sd	s2,64(sp)
    800039e0:	fc4e                	sd	s3,56(sp)
    800039e2:	f852                	sd	s4,48(sp)
    800039e4:	f456                	sd	s5,40(sp)
    800039e6:	f05a                	sd	s6,32(sp)
    800039e8:	ec5e                	sd	s7,24(sp)
    800039ea:	e862                	sd	s8,16(sp)
    800039ec:	e466                	sd	s9,8(sp)
    800039ee:	1080                	addi	s0,sp,96
    800039f0:	84aa                	mv	s1,a0
    800039f2:	8b2e                	mv	s6,a1
    800039f4:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    800039f6:	00054703          	lbu	a4,0(a0)
    800039fa:	02f00793          	li	a5,47
    800039fe:	00f70e63          	beq	a4,a5,80003a1a <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003a02:	ea1fd0ef          	jal	800018a2 <myproc>
    80003a06:	15053503          	ld	a0,336(a0)
    80003a0a:	8fdff0ef          	jal	80003306 <idup>
    80003a0e:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003a10:	02f00913          	li	s2,47
  if (len >= DIRSIZ)
    80003a14:	4c35                	li	s8,13

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003a16:	4b85                	li	s7,1
    80003a18:	a075                	j	80003ac4 <namex+0xee>
    ip = iget(ROOTDEV, ROOTINO);
    80003a1a:	4585                	li	a1,1
    80003a1c:	4505                	li	a0,1
    80003a1e:	eaaff0ef          	jal	800030c8 <iget>
    80003a22:	8a2a                	mv	s4,a0
    80003a24:	b7f5                	j	80003a10 <namex+0x3a>
      iunlockput(ip);
    80003a26:	8552                	mv	a0,s4
    80003a28:	b67ff0ef          	jal	8000358e <iunlockput>
      return 0;
    80003a2c:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003a2e:	8552                	mv	a0,s4
    80003a30:	60e6                	ld	ra,88(sp)
    80003a32:	6446                	ld	s0,80(sp)
    80003a34:	64a6                	ld	s1,72(sp)
    80003a36:	6906                	ld	s2,64(sp)
    80003a38:	79e2                	ld	s3,56(sp)
    80003a3a:	7a42                	ld	s4,48(sp)
    80003a3c:	7aa2                	ld	s5,40(sp)
    80003a3e:	7b02                	ld	s6,32(sp)
    80003a40:	6be2                	ld	s7,24(sp)
    80003a42:	6c42                	ld	s8,16(sp)
    80003a44:	6ca2                	ld	s9,8(sp)
    80003a46:	6125                	addi	sp,sp,96
    80003a48:	8082                	ret
      iunlockput(ip);
    80003a4a:	8552                	mv	a0,s4
    80003a4c:	b43ff0ef          	jal	8000358e <iunlockput>
      return 0;
    80003a50:	4a01                	li	s4,0
    80003a52:	bff1                	j	80003a2e <namex+0x58>
      iunlock(ip);
    80003a54:	8552                	mv	a0,s4
    80003a56:	995ff0ef          	jal	800033ea <iunlock>
      return ip;
    80003a5a:	bfd1                	j	80003a2e <namex+0x58>
      iunlockput(ip);
    80003a5c:	8552                	mv	a0,s4
    80003a5e:	b31ff0ef          	jal	8000358e <iunlockput>
      return 0;
    80003a62:	8a4e                	mv	s4,s3
    80003a64:	b7e9                	j	80003a2e <namex+0x58>
  len = path - s;
    80003a66:	40998633          	sub	a2,s3,s1
    80003a6a:	00060c9b          	sext.w	s9,a2
  if (len >= DIRSIZ)
    80003a6e:	099c5363          	bge	s8,s9,80003af4 <namex+0x11e>
    memmove(name, s, DIRSIZ);
    80003a72:	4639                	li	a2,14
    80003a74:	85a6                	mv	a1,s1
    80003a76:	8556                	mv	a0,s5
    80003a78:	a38fd0ef          	jal	80000cb0 <memmove>
    80003a7c:	84ce                	mv	s1,s3
  while (*path == '/')
    80003a7e:	0004c783          	lbu	a5,0(s1)
    80003a82:	01279763          	bne	a5,s2,80003a90 <namex+0xba>
    path++;
    80003a86:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a88:	0004c783          	lbu	a5,0(s1)
    80003a8c:	ff278de3          	beq	a5,s2,80003a86 <namex+0xb0>
    ilock(ip);
    80003a90:	8552                	mv	a0,s4
    80003a92:	8abff0ef          	jal	8000333c <ilock>
    if (ip->type != T_DIR) {
    80003a96:	044a1783          	lh	a5,68(s4)
    80003a9a:	f97796e3          	bne	a5,s7,80003a26 <namex+0x50>
    if (ip->nlink == 0) {
    80003a9e:	04aa1783          	lh	a5,74(s4)
    80003aa2:	d7c5                	beqz	a5,80003a4a <namex+0x74>
    if (nameiparent && *path == '\0') {
    80003aa4:	000b0563          	beqz	s6,80003aae <namex+0xd8>
    80003aa8:	0004c783          	lbu	a5,0(s1)
    80003aac:	d7c5                	beqz	a5,80003a54 <namex+0x7e>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003aae:	4601                	li	a2,0
    80003ab0:	85d6                	mv	a1,s5
    80003ab2:	8552                	mv	a0,s4
    80003ab4:	e87ff0ef          	jal	8000393a <dirlookup>
    80003ab8:	89aa                	mv	s3,a0
    80003aba:	d14d                	beqz	a0,80003a5c <namex+0x86>
    iunlockput(ip);
    80003abc:	8552                	mv	a0,s4
    80003abe:	ad1ff0ef          	jal	8000358e <iunlockput>
    ip = next;
    80003ac2:	8a4e                	mv	s4,s3
  while (*path == '/')
    80003ac4:	0004c783          	lbu	a5,0(s1)
    80003ac8:	01279763          	bne	a5,s2,80003ad6 <namex+0x100>
    path++;
    80003acc:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003ace:	0004c783          	lbu	a5,0(s1)
    80003ad2:	ff278de3          	beq	a5,s2,80003acc <namex+0xf6>
  if (*path == 0)
    80003ad6:	cb8d                	beqz	a5,80003b08 <namex+0x132>
  while (*path != '/' && *path != 0)
    80003ad8:	0004c783          	lbu	a5,0(s1)
    80003adc:	89a6                	mv	s3,s1
  len = path - s;
    80003ade:	4c81                	li	s9,0
    80003ae0:	4601                	li	a2,0
  while (*path != '/' && *path != 0)
    80003ae2:	01278963          	beq	a5,s2,80003af4 <namex+0x11e>
    80003ae6:	d3c1                	beqz	a5,80003a66 <namex+0x90>
    path++;
    80003ae8:	0985                	addi	s3,s3,1
  while (*path != '/' && *path != 0)
    80003aea:	0009c783          	lbu	a5,0(s3)
    80003aee:	ff279ce3          	bne	a5,s2,80003ae6 <namex+0x110>
    80003af2:	bf95                	j	80003a66 <namex+0x90>
    memmove(name, s, len);
    80003af4:	2601                	sext.w	a2,a2
    80003af6:	85a6                	mv	a1,s1
    80003af8:	8556                	mv	a0,s5
    80003afa:	9b6fd0ef          	jal	80000cb0 <memmove>
    name[len] = 0;
    80003afe:	9cd6                	add	s9,s9,s5
    80003b00:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003b04:	84ce                	mv	s1,s3
    80003b06:	bfa5                	j	80003a7e <namex+0xa8>
  if (nameiparent) {
    80003b08:	f20b03e3          	beqz	s6,80003a2e <namex+0x58>
    iput(ip);
    80003b0c:	8552                	mv	a0,s4
    80003b0e:	9b1ff0ef          	jal	800034be <iput>
    return 0;
    80003b12:	4a01                	li	s4,0
    80003b14:	bf29                	j	80003a2e <namex+0x58>

0000000080003b16 <dirlink>:
{
    80003b16:	7139                	addi	sp,sp,-64
    80003b18:	fc06                	sd	ra,56(sp)
    80003b1a:	f822                	sd	s0,48(sp)
    80003b1c:	f04a                	sd	s2,32(sp)
    80003b1e:	ec4e                	sd	s3,24(sp)
    80003b20:	e852                	sd	s4,16(sp)
    80003b22:	0080                	addi	s0,sp,64
    80003b24:	892a                	mv	s2,a0
    80003b26:	8a2e                	mv	s4,a1
    80003b28:	89b2                	mv	s3,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003b2a:	4601                	li	a2,0
    80003b2c:	e0fff0ef          	jal	8000393a <dirlookup>
    80003b30:	e535                	bnez	a0,80003b9c <dirlink+0x86>
    80003b32:	f426                	sd	s1,40(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b34:	04c92483          	lw	s1,76(s2)
    80003b38:	c48d                	beqz	s1,80003b62 <dirlink+0x4c>
    80003b3a:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b3c:	4741                	li	a4,16
    80003b3e:	86a6                	mv	a3,s1
    80003b40:	fc040613          	addi	a2,s0,-64
    80003b44:	4581                	li	a1,0
    80003b46:	854a                	mv	a0,s2
    80003b48:	bcdff0ef          	jal	80003714 <readi>
    80003b4c:	47c1                	li	a5,16
    80003b4e:	04f51b63          	bne	a0,a5,80003ba4 <dirlink+0x8e>
    if (de.inum == 0)
    80003b52:	fc045783          	lhu	a5,-64(s0)
    80003b56:	c791                	beqz	a5,80003b62 <dirlink+0x4c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b58:	24c1                	addiw	s1,s1,16
    80003b5a:	04c92783          	lw	a5,76(s2)
    80003b5e:	fcf4efe3          	bltu	s1,a5,80003b3c <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003b62:	4639                	li	a2,14
    80003b64:	85d2                	mv	a1,s4
    80003b66:	fc240513          	addi	a0,s0,-62
    80003b6a:	9ecfd0ef          	jal	80000d56 <strncpy>
  de.inum = inum;
    80003b6e:	fd341023          	sh	s3,-64(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b72:	4741                	li	a4,16
    80003b74:	86a6                	mv	a3,s1
    80003b76:	fc040613          	addi	a2,s0,-64
    80003b7a:	4581                	li	a1,0
    80003b7c:	854a                	mv	a0,s2
    80003b7e:	c93ff0ef          	jal	80003810 <writei>
    80003b82:	1541                	addi	a0,a0,-16
    80003b84:	00a03533          	snez	a0,a0
    80003b88:	40a00533          	neg	a0,a0
    80003b8c:	74a2                	ld	s1,40(sp)
}
    80003b8e:	70e2                	ld	ra,56(sp)
    80003b90:	7442                	ld	s0,48(sp)
    80003b92:	7902                	ld	s2,32(sp)
    80003b94:	69e2                	ld	s3,24(sp)
    80003b96:	6a42                	ld	s4,16(sp)
    80003b98:	6121                	addi	sp,sp,64
    80003b9a:	8082                	ret
    iput(ip);
    80003b9c:	923ff0ef          	jal	800034be <iput>
    return -1;
    80003ba0:	557d                	li	a0,-1
    80003ba2:	b7f5                	j	80003b8e <dirlink+0x78>
      panic("dirlink read");
    80003ba4:	00004517          	auipc	a0,0x4
    80003ba8:	94450513          	addi	a0,a0,-1724 # 800074e8 <etext+0x4e8>
    80003bac:	c45fc0ef          	jal	800007f0 <panic>

0000000080003bb0 <namei>:

struct inode *
namei(char *path)
{
    80003bb0:	1101                	addi	sp,sp,-32
    80003bb2:	ec06                	sd	ra,24(sp)
    80003bb4:	e822                	sd	s0,16(sp)
    80003bb6:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003bb8:	fe040613          	addi	a2,s0,-32
    80003bbc:	4581                	li	a1,0
    80003bbe:	e19ff0ef          	jal	800039d6 <namex>
}
    80003bc2:	60e2                	ld	ra,24(sp)
    80003bc4:	6442                	ld	s0,16(sp)
    80003bc6:	6105                	addi	sp,sp,32
    80003bc8:	8082                	ret

0000000080003bca <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003bca:	1141                	addi	sp,sp,-16
    80003bcc:	e406                	sd	ra,8(sp)
    80003bce:	e022                	sd	s0,0(sp)
    80003bd0:	0800                	addi	s0,sp,16
    80003bd2:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003bd4:	4585                	li	a1,1
    80003bd6:	e01ff0ef          	jal	800039d6 <namex>
}
    80003bda:	60a2                	ld	ra,8(sp)
    80003bdc:	6402                	ld	s0,0(sp)
    80003bde:	0141                	addi	sp,sp,16
    80003be0:	8082                	ret

0000000080003be2 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003be2:	1101                	addi	sp,sp,-32
    80003be4:	ec06                	sd	ra,24(sp)
    80003be6:	e822                	sd	s0,16(sp)
    80003be8:	e426                	sd	s1,8(sp)
    80003bea:	e04a                	sd	s2,0(sp)
    80003bec:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003bee:	0001f917          	auipc	s2,0x1f
    80003bf2:	bf290913          	addi	s2,s2,-1038 # 800227e0 <log>
    80003bf6:	01892583          	lw	a1,24(s2)
    80003bfa:	02492503          	lw	a0,36(s2)
    80003bfe:	872ff0ef          	jal	80002c70 <bread>
    80003c02:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003c04:	02c92603          	lw	a2,44(s2)
    80003c08:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003c0a:	00c05f63          	blez	a2,80003c28 <write_head+0x46>
    80003c0e:	0001f717          	auipc	a4,0x1f
    80003c12:	c0270713          	addi	a4,a4,-1022 # 80022810 <log+0x30>
    80003c16:	87aa                	mv	a5,a0
    80003c18:	060a                	slli	a2,a2,0x2
    80003c1a:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003c1c:	4314                	lw	a3,0(a4)
    80003c1e:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003c20:	0711                	addi	a4,a4,4
    80003c22:	0791                	addi	a5,a5,4
    80003c24:	fec79ce3          	bne	a5,a2,80003c1c <write_head+0x3a>
  }
  bwrite(buf);
    80003c28:	8526                	mv	a0,s1
    80003c2a:	91cff0ef          	jal	80002d46 <bwrite>
  brelse(buf);
    80003c2e:	8526                	mv	a0,s1
    80003c30:	948ff0ef          	jal	80002d78 <brelse>
}
    80003c34:	60e2                	ld	ra,24(sp)
    80003c36:	6442                	ld	s0,16(sp)
    80003c38:	64a2                	ld	s1,8(sp)
    80003c3a:	6902                	ld	s2,0(sp)
    80003c3c:	6105                	addi	sp,sp,32
    80003c3e:	8082                	ret

0000000080003c40 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c40:	0001f797          	auipc	a5,0x1f
    80003c44:	bcc7a783          	lw	a5,-1076(a5) # 8002280c <log+0x2c>
    80003c48:	0af05e63          	blez	a5,80003d04 <install_trans+0xc4>
{
    80003c4c:	715d                	addi	sp,sp,-80
    80003c4e:	e486                	sd	ra,72(sp)
    80003c50:	e0a2                	sd	s0,64(sp)
    80003c52:	fc26                	sd	s1,56(sp)
    80003c54:	f84a                	sd	s2,48(sp)
    80003c56:	f44e                	sd	s3,40(sp)
    80003c58:	f052                	sd	s4,32(sp)
    80003c5a:	ec56                	sd	s5,24(sp)
    80003c5c:	e85a                	sd	s6,16(sp)
    80003c5e:	e45e                	sd	s7,8(sp)
    80003c60:	0880                	addi	s0,sp,80
    80003c62:	8b2a                	mv	s6,a0
    80003c64:	0001fa97          	auipc	s5,0x1f
    80003c68:	baca8a93          	addi	s5,s5,-1108 # 80022810 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c6c:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c6e:	00004b97          	auipc	s7,0x4
    80003c72:	88ab8b93          	addi	s7,s7,-1910 # 800074f8 <etext+0x4f8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c76:	0001fa17          	auipc	s4,0x1f
    80003c7a:	b6aa0a13          	addi	s4,s4,-1174 # 800227e0 <log>
    80003c7e:	a025                	j	80003ca6 <install_trans+0x66>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c80:	000aa603          	lw	a2,0(s5)
    80003c84:	85ce                	mv	a1,s3
    80003c86:	855e                	mv	a0,s7
    80003c88:	883fc0ef          	jal	8000050a <printk>
    80003c8c:	a839                	j	80003caa <install_trans+0x6a>
    brelse(lbuf);
    80003c8e:	854a                	mv	a0,s2
    80003c90:	8e8ff0ef          	jal	80002d78 <brelse>
    brelse(dbuf);
    80003c94:	8526                	mv	a0,s1
    80003c96:	8e2ff0ef          	jal	80002d78 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c9a:	2985                	addiw	s3,s3,1
    80003c9c:	0a91                	addi	s5,s5,4
    80003c9e:	02ca2783          	lw	a5,44(s4)
    80003ca2:	04f9d663          	bge	s3,a5,80003cee <install_trans+0xae>
    if (recovering) {
    80003ca6:	fc0b1de3          	bnez	s6,80003c80 <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003caa:	018a2583          	lw	a1,24(s4)
    80003cae:	013585bb          	addw	a1,a1,s3
    80003cb2:	2585                	addiw	a1,a1,1
    80003cb4:	024a2503          	lw	a0,36(s4)
    80003cb8:	fb9fe0ef          	jal	80002c70 <bread>
    80003cbc:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003cbe:	000aa583          	lw	a1,0(s5)
    80003cc2:	024a2503          	lw	a0,36(s4)
    80003cc6:	fabfe0ef          	jal	80002c70 <bread>
    80003cca:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003ccc:	40000613          	li	a2,1024
    80003cd0:	05890593          	addi	a1,s2,88
    80003cd4:	05850513          	addi	a0,a0,88
    80003cd8:	fd9fc0ef          	jal	80000cb0 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003cdc:	8526                	mv	a0,s1
    80003cde:	868ff0ef          	jal	80002d46 <bwrite>
    if (recovering == 0)
    80003ce2:	fa0b16e3          	bnez	s6,80003c8e <install_trans+0x4e>
      bunpin(dbuf);
    80003ce6:	8526                	mv	a0,s1
    80003ce8:	94cff0ef          	jal	80002e34 <bunpin>
    80003cec:	b74d                	j	80003c8e <install_trans+0x4e>
}
    80003cee:	60a6                	ld	ra,72(sp)
    80003cf0:	6406                	ld	s0,64(sp)
    80003cf2:	74e2                	ld	s1,56(sp)
    80003cf4:	7942                	ld	s2,48(sp)
    80003cf6:	79a2                	ld	s3,40(sp)
    80003cf8:	7a02                	ld	s4,32(sp)
    80003cfa:	6ae2                	ld	s5,24(sp)
    80003cfc:	6b42                	ld	s6,16(sp)
    80003cfe:	6ba2                	ld	s7,8(sp)
    80003d00:	6161                	addi	sp,sp,80
    80003d02:	8082                	ret
    80003d04:	8082                	ret

0000000080003d06 <initlog>:
{
    80003d06:	7179                	addi	sp,sp,-48
    80003d08:	f406                	sd	ra,40(sp)
    80003d0a:	f022                	sd	s0,32(sp)
    80003d0c:	ec26                	sd	s1,24(sp)
    80003d0e:	e84a                	sd	s2,16(sp)
    80003d10:	e44e                	sd	s3,8(sp)
    80003d12:	1800                	addi	s0,sp,48
    80003d14:	892a                	mv	s2,a0
    80003d16:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003d18:	0001f497          	auipc	s1,0x1f
    80003d1c:	ac848493          	addi	s1,s1,-1336 # 800227e0 <log>
    80003d20:	00003597          	auipc	a1,0x3
    80003d24:	7f858593          	addi	a1,a1,2040 # 80007518 <etext+0x518>
    80003d28:	8526                	mv	a0,s1
    80003d2a:	df1fc0ef          	jal	80000b1a <initlock>
  log.start = sb->logstart;
    80003d2e:	0149a583          	lw	a1,20(s3)
    80003d32:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003d34:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003d38:	854a                	mv	a0,s2
    80003d3a:	f37fe0ef          	jal	80002c70 <bread>
  log.lh.n = lh->n;
    80003d3e:	4d30                	lw	a2,88(a0)
    80003d40:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003d42:	00c05f63          	blez	a2,80003d60 <initlog+0x5a>
    80003d46:	87aa                	mv	a5,a0
    80003d48:	0001f717          	auipc	a4,0x1f
    80003d4c:	ac870713          	addi	a4,a4,-1336 # 80022810 <log+0x30>
    80003d50:	060a                	slli	a2,a2,0x2
    80003d52:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003d54:	4ff4                	lw	a3,92(a5)
    80003d56:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003d58:	0791                	addi	a5,a5,4
    80003d5a:	0711                	addi	a4,a4,4
    80003d5c:	fec79ce3          	bne	a5,a2,80003d54 <initlog+0x4e>
  brelse(buf);
    80003d60:	818ff0ef          	jal	80002d78 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003d64:	4505                	li	a0,1
    80003d66:	edbff0ef          	jal	80003c40 <install_trans>
  log.lh.n = 0;
    80003d6a:	0001f797          	auipc	a5,0x1f
    80003d6e:	aa07a123          	sw	zero,-1374(a5) # 8002280c <log+0x2c>
  write_head(); // clear the log
    80003d72:	e71ff0ef          	jal	80003be2 <write_head>
}
    80003d76:	70a2                	ld	ra,40(sp)
    80003d78:	7402                	ld	s0,32(sp)
    80003d7a:	64e2                	ld	s1,24(sp)
    80003d7c:	6942                	ld	s2,16(sp)
    80003d7e:	69a2                	ld	s3,8(sp)
    80003d80:	6145                	addi	sp,sp,48
    80003d82:	8082                	ret

0000000080003d84 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003d84:	1101                	addi	sp,sp,-32
    80003d86:	ec06                	sd	ra,24(sp)
    80003d88:	e822                	sd	s0,16(sp)
    80003d8a:	e426                	sd	s1,8(sp)
    80003d8c:	e04a                	sd	s2,0(sp)
    80003d8e:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003d90:	0001f517          	auipc	a0,0x1f
    80003d94:	a5050513          	addi	a0,a0,-1456 # 800227e0 <log>
    80003d98:	df9fc0ef          	jal	80000b90 <acquire>
  while (1) {
    if (log.committing) {
    80003d9c:	0001f497          	auipc	s1,0x1f
    80003da0:	a4448493          	addi	s1,s1,-1468 # 800227e0 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003da4:	4979                	li	s2,30
    80003da6:	a821                	j	80003dbe <begin_op+0x3a>
      sleep_prepare(&log);
    80003da8:	8526                	mv	a0,s1
    80003daa:	94afe0ef          	jal	80001ef4 <sleep_prepare>
      release(&log.lock);
    80003dae:	8526                	mv	a0,s1
    80003db0:	e6dfc0ef          	jal	80000c1c <release>
      sleep();
    80003db4:	97cfe0ef          	jal	80001f30 <sleep>
      acquire(&log.lock);
    80003db8:	8526                	mv	a0,s1
    80003dba:	dd7fc0ef          	jal	80000b90 <acquire>
    if (log.committing) {
    80003dbe:	509c                	lw	a5,32(s1)
    80003dc0:	f7e5                	bnez	a5,80003da8 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003dc2:	4cd8                	lw	a4,28(s1)
    80003dc4:	2705                	addiw	a4,a4,1
    80003dc6:	0027179b          	slliw	a5,a4,0x2
    80003dca:	9fb9                	addw	a5,a5,a4
    80003dcc:	0017979b          	slliw	a5,a5,0x1
    80003dd0:	54d4                	lw	a3,44(s1)
    80003dd2:	9fb5                	addw	a5,a5,a3
    80003dd4:	00f95e63          	bge	s2,a5,80003df0 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003dd8:	8526                	mv	a0,s1
    80003dda:	91afe0ef          	jal	80001ef4 <sleep_prepare>
      release(&log.lock);
    80003dde:	8526                	mv	a0,s1
    80003de0:	e3dfc0ef          	jal	80000c1c <release>
      sleep();
    80003de4:	94cfe0ef          	jal	80001f30 <sleep>
      acquire(&log.lock);
    80003de8:	8526                	mv	a0,s1
    80003dea:	da7fc0ef          	jal	80000b90 <acquire>
    80003dee:	bfc1                	j	80003dbe <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003df0:	0001f517          	auipc	a0,0x1f
    80003df4:	9f050513          	addi	a0,a0,-1552 # 800227e0 <log>
    80003df8:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003dfa:	e23fc0ef          	jal	80000c1c <release>
      break;
    }
  }
}
    80003dfe:	60e2                	ld	ra,24(sp)
    80003e00:	6442                	ld	s0,16(sp)
    80003e02:	64a2                	ld	s1,8(sp)
    80003e04:	6902                	ld	s2,0(sp)
    80003e06:	6105                	addi	sp,sp,32
    80003e08:	8082                	ret

0000000080003e0a <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003e0a:	7139                	addi	sp,sp,-64
    80003e0c:	fc06                	sd	ra,56(sp)
    80003e0e:	f822                	sd	s0,48(sp)
    80003e10:	f426                	sd	s1,40(sp)
    80003e12:	f04a                	sd	s2,32(sp)
    80003e14:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003e16:	0001f497          	auipc	s1,0x1f
    80003e1a:	9ca48493          	addi	s1,s1,-1590 # 800227e0 <log>
    80003e1e:	8526                	mv	a0,s1
    80003e20:	d71fc0ef          	jal	80000b90 <acquire>
  log.outstanding -= 1;
    80003e24:	4cdc                	lw	a5,28(s1)
    80003e26:	37fd                	addiw	a5,a5,-1
    80003e28:	0007891b          	sext.w	s2,a5
    80003e2c:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003e2e:	509c                	lw	a5,32(s1)
    80003e30:	e3b1                	bnez	a5,80003e74 <end_op+0x6a>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003e32:	04091a63          	bnez	s2,80003e86 <end_op+0x7c>
    do_commit = 1;
    log.committing = 1;
    80003e36:	0001f497          	auipc	s1,0x1f
    80003e3a:	9aa48493          	addi	s1,s1,-1622 # 800227e0 <log>
    80003e3e:	4785                	li	a5,1
    80003e40:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003e42:	8526                	mv	a0,s1
    80003e44:	dd9fc0ef          	jal	80000c1c <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003e48:	54dc                	lw	a5,44(s1)
    80003e4a:	04f04e63          	bgtz	a5,80003ea6 <end_op+0x9c>
    acquire(&log.lock);
    80003e4e:	0001f497          	auipc	s1,0x1f
    80003e52:	99248493          	addi	s1,s1,-1646 # 800227e0 <log>
    80003e56:	8526                	mv	a0,s1
    80003e58:	d39fc0ef          	jal	80000b90 <acquire>
    log.committing = 0;
    80003e5c:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003e60:	549c                	lw	a5,40(s1)
    80003e62:	2785                	addiw	a5,a5,1
    80003e64:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003e66:	8526                	mv	a0,s1
    80003e68:	8f8fe0ef          	jal	80001f60 <wakeup>
    release(&log.lock);
    80003e6c:	8526                	mv	a0,s1
    80003e6e:	daffc0ef          	jal	80000c1c <release>
}
    80003e72:	a025                	j	80003e9a <end_op+0x90>
    80003e74:	ec4e                	sd	s3,24(sp)
    80003e76:	e852                	sd	s4,16(sp)
    80003e78:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003e7a:	00003517          	auipc	a0,0x3
    80003e7e:	6a650513          	addi	a0,a0,1702 # 80007520 <etext+0x520>
    80003e82:	96ffc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80003e86:	0001f497          	auipc	s1,0x1f
    80003e8a:	95a48493          	addi	s1,s1,-1702 # 800227e0 <log>
    80003e8e:	8526                	mv	a0,s1
    80003e90:	8d0fe0ef          	jal	80001f60 <wakeup>
  release(&log.lock);
    80003e94:	8526                	mv	a0,s1
    80003e96:	d87fc0ef          	jal	80000c1c <release>
}
    80003e9a:	70e2                	ld	ra,56(sp)
    80003e9c:	7442                	ld	s0,48(sp)
    80003e9e:	74a2                	ld	s1,40(sp)
    80003ea0:	7902                	ld	s2,32(sp)
    80003ea2:	6121                	addi	sp,sp,64
    80003ea4:	8082                	ret
    80003ea6:	ec4e                	sd	s3,24(sp)
    80003ea8:	e852                	sd	s4,16(sp)
    80003eaa:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003eac:	0001fa97          	auipc	s5,0x1f
    80003eb0:	964a8a93          	addi	s5,s5,-1692 # 80022810 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003eb4:	0001fa17          	auipc	s4,0x1f
    80003eb8:	92ca0a13          	addi	s4,s4,-1748 # 800227e0 <log>
    80003ebc:	018a2583          	lw	a1,24(s4)
    80003ec0:	012585bb          	addw	a1,a1,s2
    80003ec4:	2585                	addiw	a1,a1,1
    80003ec6:	024a2503          	lw	a0,36(s4)
    80003eca:	da7fe0ef          	jal	80002c70 <bread>
    80003ece:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003ed0:	000aa583          	lw	a1,0(s5)
    80003ed4:	024a2503          	lw	a0,36(s4)
    80003ed8:	d99fe0ef          	jal	80002c70 <bread>
    80003edc:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003ede:	40000613          	li	a2,1024
    80003ee2:	05850593          	addi	a1,a0,88
    80003ee6:	05848513          	addi	a0,s1,88
    80003eea:	dc7fc0ef          	jal	80000cb0 <memmove>
    bwrite(to); // write the log
    80003eee:	8526                	mv	a0,s1
    80003ef0:	e57fe0ef          	jal	80002d46 <bwrite>
    brelse(from);
    80003ef4:	854e                	mv	a0,s3
    80003ef6:	e83fe0ef          	jal	80002d78 <brelse>
    brelse(to);
    80003efa:	8526                	mv	a0,s1
    80003efc:	e7dfe0ef          	jal	80002d78 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f00:	2905                	addiw	s2,s2,1
    80003f02:	0a91                	addi	s5,s5,4
    80003f04:	02ca2783          	lw	a5,44(s4)
    80003f08:	faf94ae3          	blt	s2,a5,80003ebc <end_op+0xb2>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003f0c:	cd7ff0ef          	jal	80003be2 <write_head>
    install_trans(0); // Now install writes to home locations
    80003f10:	4501                	li	a0,0
    80003f12:	d2fff0ef          	jal	80003c40 <install_trans>
    log.lh.n = 0;
    80003f16:	0001f797          	auipc	a5,0x1f
    80003f1a:	8e07ab23          	sw	zero,-1802(a5) # 8002280c <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003f1e:	cc5ff0ef          	jal	80003be2 <write_head>
    80003f22:	69e2                	ld	s3,24(sp)
    80003f24:	6a42                	ld	s4,16(sp)
    80003f26:	6aa2                	ld	s5,8(sp)
    80003f28:	b71d                	j	80003e4e <end_op+0x44>

0000000080003f2a <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003f2a:	1101                	addi	sp,sp,-32
    80003f2c:	ec06                	sd	ra,24(sp)
    80003f2e:	e822                	sd	s0,16(sp)
    80003f30:	e426                	sd	s1,8(sp)
    80003f32:	e04a                	sd	s2,0(sp)
    80003f34:	1000                	addi	s0,sp,32
    80003f36:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003f38:	0001f917          	auipc	s2,0x1f
    80003f3c:	8a890913          	addi	s2,s2,-1880 # 800227e0 <log>
    80003f40:	854a                	mv	a0,s2
    80003f42:	c4ffc0ef          	jal	80000b90 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003f46:	02c92603          	lw	a2,44(s2)
    80003f4a:	47f5                	li	a5,29
    80003f4c:	04c7cc63          	blt	a5,a2,80003fa4 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003f50:	0001f797          	auipc	a5,0x1f
    80003f54:	8ac7a783          	lw	a5,-1876(a5) # 800227fc <log+0x1c>
    80003f58:	04f05c63          	blez	a5,80003fb0 <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003f5c:	4781                	li	a5,0
    80003f5e:	04c05f63          	blez	a2,80003fbc <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003f62:	44cc                	lw	a1,12(s1)
    80003f64:	0001f717          	auipc	a4,0x1f
    80003f68:	8ac70713          	addi	a4,a4,-1876 # 80022810 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003f6c:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003f6e:	4314                	lw	a3,0(a4)
    80003f70:	04b68663          	beq	a3,a1,80003fbc <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003f74:	2785                	addiw	a5,a5,1
    80003f76:	0711                	addi	a4,a4,4
    80003f78:	fef61be3          	bne	a2,a5,80003f6e <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003f7c:	0621                	addi	a2,a2,8
    80003f7e:	060a                	slli	a2,a2,0x2
    80003f80:	0001f797          	auipc	a5,0x1f
    80003f84:	86078793          	addi	a5,a5,-1952 # 800227e0 <log>
    80003f88:	97b2                	add	a5,a5,a2
    80003f8a:	44d8                	lw	a4,12(s1)
    80003f8c:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003f8e:	8526                	mv	a0,s1
    80003f90:	e71fe0ef          	jal	80002e00 <bpin>
    log.lh.n++;
    80003f94:	0001f717          	auipc	a4,0x1f
    80003f98:	84c70713          	addi	a4,a4,-1972 # 800227e0 <log>
    80003f9c:	575c                	lw	a5,44(a4)
    80003f9e:	2785                	addiw	a5,a5,1
    80003fa0:	d75c                	sw	a5,44(a4)
    80003fa2:	a80d                	j	80003fd4 <log_write+0xaa>
    panic("too big a transaction");
    80003fa4:	00003517          	auipc	a0,0x3
    80003fa8:	58c50513          	addi	a0,a0,1420 # 80007530 <etext+0x530>
    80003fac:	845fc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    80003fb0:	00003517          	auipc	a0,0x3
    80003fb4:	59850513          	addi	a0,a0,1432 # 80007548 <etext+0x548>
    80003fb8:	839fc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80003fbc:	00878693          	addi	a3,a5,8
    80003fc0:	068a                	slli	a3,a3,0x2
    80003fc2:	0001f717          	auipc	a4,0x1f
    80003fc6:	81e70713          	addi	a4,a4,-2018 # 800227e0 <log>
    80003fca:	9736                	add	a4,a4,a3
    80003fcc:	44d4                	lw	a3,12(s1)
    80003fce:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80003fd0:	faf60fe3          	beq	a2,a5,80003f8e <log_write+0x64>
  }
  release(&log.lock);
    80003fd4:	0001f517          	auipc	a0,0x1f
    80003fd8:	80c50513          	addi	a0,a0,-2036 # 800227e0 <log>
    80003fdc:	c41fc0ef          	jal	80000c1c <release>
}
    80003fe0:	60e2                	ld	ra,24(sp)
    80003fe2:	6442                	ld	s0,16(sp)
    80003fe4:	64a2                	ld	s1,8(sp)
    80003fe6:	6902                	ld	s2,0(sp)
    80003fe8:	6105                	addi	sp,sp,32
    80003fea:	8082                	ret

0000000080003fec <sys_sync>:

uint64
sys_sync(void)
{
    80003fec:	1101                	addi	sp,sp,-32
    80003fee:	ec06                	sd	ra,24(sp)
    80003ff0:	e822                	sd	s0,16(sp)
    80003ff2:	e426                	sd	s1,8(sp)
    80003ff4:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003ff6:	0001e497          	auipc	s1,0x1e
    80003ffa:	7ea48493          	addi	s1,s1,2026 # 800227e0 <log>
    80003ffe:	8526                	mv	a0,s1
    80004000:	b91fc0ef          	jal	80000b90 <acquire>
  if (log.committing || log.outstanding > 0) {
    80004004:	509c                	lw	a5,32(s1)
    80004006:	e799                	bnez	a5,80004014 <sys_sync+0x28>
    80004008:	0001e797          	auipc	a5,0x1e
    8000400c:	7f47a783          	lw	a5,2036(a5) # 800227fc <log+0x1c>
    80004010:	02f05a63          	blez	a5,80004044 <sys_sync+0x58>
    80004014:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80004016:	0001e917          	auipc	s2,0x1e
    8000401a:	7f292903          	lw	s2,2034(s2) # 80022808 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    8000401e:	0001e497          	auipc	s1,0x1e
    80004022:	7c248493          	addi	s1,s1,1986 # 800227e0 <log>
    80004026:	8526                	mv	a0,s1
    80004028:	ecdfd0ef          	jal	80001ef4 <sleep_prepare>
      release(&log.lock);
    8000402c:	8526                	mv	a0,s1
    8000402e:	beffc0ef          	jal	80000c1c <release>
      sleep();
    80004032:	efffd0ef          	jal	80001f30 <sleep>
      acquire(&log.lock);
    80004036:	8526                	mv	a0,s1
    80004038:	b59fc0ef          	jal	80000b90 <acquire>
    while (log.ncommit < n) {
    8000403c:	549c                	lw	a5,40(s1)
    8000403e:	fef954e3          	bge	s2,a5,80004026 <sys_sync+0x3a>
    80004042:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80004044:	0001e517          	auipc	a0,0x1e
    80004048:	79c50513          	addi	a0,a0,1948 # 800227e0 <log>
    8000404c:	bd1fc0ef          	jal	80000c1c <release>
  return 0;
}
    80004050:	4501                	li	a0,0
    80004052:	60e2                	ld	ra,24(sp)
    80004054:	6442                	ld	s0,16(sp)
    80004056:	64a2                	ld	s1,8(sp)
    80004058:	6105                	addi	sp,sp,32
    8000405a:	8082                	ret

000000008000405c <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000405c:	1101                	addi	sp,sp,-32
    8000405e:	ec06                	sd	ra,24(sp)
    80004060:	e822                	sd	s0,16(sp)
    80004062:	e426                	sd	s1,8(sp)
    80004064:	e04a                	sd	s2,0(sp)
    80004066:	1000                	addi	s0,sp,32
    80004068:	84aa                	mv	s1,a0
    8000406a:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000406c:	00003597          	auipc	a1,0x3
    80004070:	4fc58593          	addi	a1,a1,1276 # 80007568 <etext+0x568>
    80004074:	0521                	addi	a0,a0,8
    80004076:	aa5fc0ef          	jal	80000b1a <initlock>
  lk->name = name;
    8000407a:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000407e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004082:	0204a423          	sw	zero,40(s1)
}
    80004086:	60e2                	ld	ra,24(sp)
    80004088:	6442                	ld	s0,16(sp)
    8000408a:	64a2                	ld	s1,8(sp)
    8000408c:	6902                	ld	s2,0(sp)
    8000408e:	6105                	addi	sp,sp,32
    80004090:	8082                	ret

0000000080004092 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004092:	1101                	addi	sp,sp,-32
    80004094:	ec06                	sd	ra,24(sp)
    80004096:	e822                	sd	s0,16(sp)
    80004098:	e426                	sd	s1,8(sp)
    8000409a:	e04a                	sd	s2,0(sp)
    8000409c:	1000                	addi	s0,sp,32
    8000409e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800040a0:	00850913          	addi	s2,a0,8
    800040a4:	854a                	mv	a0,s2
    800040a6:	aebfc0ef          	jal	80000b90 <acquire>
  while (lk->locked) {
    800040aa:	409c                	lw	a5,0(s1)
    800040ac:	cf91                	beqz	a5,800040c8 <acquiresleep+0x36>
    sleep_prepare(lk);
    800040ae:	8526                	mv	a0,s1
    800040b0:	e45fd0ef          	jal	80001ef4 <sleep_prepare>
    release(&lk->lk);
    800040b4:	854a                	mv	a0,s2
    800040b6:	b67fc0ef          	jal	80000c1c <release>
    sleep();
    800040ba:	e77fd0ef          	jal	80001f30 <sleep>
    acquire(&lk->lk);
    800040be:	854a                	mv	a0,s2
    800040c0:	ad1fc0ef          	jal	80000b90 <acquire>
  while (lk->locked) {
    800040c4:	409c                	lw	a5,0(s1)
    800040c6:	f7e5                	bnez	a5,800040ae <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800040c8:	4785                	li	a5,1
    800040ca:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800040cc:	fd6fd0ef          	jal	800018a2 <myproc>
    800040d0:	591c                	lw	a5,48(a0)
    800040d2:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800040d4:	854a                	mv	a0,s2
    800040d6:	b47fc0ef          	jal	80000c1c <release>
}
    800040da:	60e2                	ld	ra,24(sp)
    800040dc:	6442                	ld	s0,16(sp)
    800040de:	64a2                	ld	s1,8(sp)
    800040e0:	6902                	ld	s2,0(sp)
    800040e2:	6105                	addi	sp,sp,32
    800040e4:	8082                	ret

00000000800040e6 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800040e6:	1101                	addi	sp,sp,-32
    800040e8:	ec06                	sd	ra,24(sp)
    800040ea:	e822                	sd	s0,16(sp)
    800040ec:	e426                	sd	s1,8(sp)
    800040ee:	e04a                	sd	s2,0(sp)
    800040f0:	1000                	addi	s0,sp,32
    800040f2:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800040f4:	00850913          	addi	s2,a0,8
    800040f8:	854a                	mv	a0,s2
    800040fa:	a97fc0ef          	jal	80000b90 <acquire>
  lk->locked = 0;
    800040fe:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004102:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004106:	8526                	mv	a0,s1
    80004108:	e59fd0ef          	jal	80001f60 <wakeup>
  release(&lk->lk);
    8000410c:	854a                	mv	a0,s2
    8000410e:	b0ffc0ef          	jal	80000c1c <release>
}
    80004112:	60e2                	ld	ra,24(sp)
    80004114:	6442                	ld	s0,16(sp)
    80004116:	64a2                	ld	s1,8(sp)
    80004118:	6902                	ld	s2,0(sp)
    8000411a:	6105                	addi	sp,sp,32
    8000411c:	8082                	ret

000000008000411e <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000411e:	7179                	addi	sp,sp,-48
    80004120:	f406                	sd	ra,40(sp)
    80004122:	f022                	sd	s0,32(sp)
    80004124:	ec26                	sd	s1,24(sp)
    80004126:	e84a                	sd	s2,16(sp)
    80004128:	1800                	addi	s0,sp,48
    8000412a:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    8000412c:	00850913          	addi	s2,a0,8
    80004130:	854a                	mv	a0,s2
    80004132:	a5ffc0ef          	jal	80000b90 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004136:	409c                	lw	a5,0(s1)
    80004138:	ef81                	bnez	a5,80004150 <holdingsleep+0x32>
    8000413a:	4481                	li	s1,0
  release(&lk->lk);
    8000413c:	854a                	mv	a0,s2
    8000413e:	adffc0ef          	jal	80000c1c <release>
  return r;
}
    80004142:	8526                	mv	a0,s1
    80004144:	70a2                	ld	ra,40(sp)
    80004146:	7402                	ld	s0,32(sp)
    80004148:	64e2                	ld	s1,24(sp)
    8000414a:	6942                	ld	s2,16(sp)
    8000414c:	6145                	addi	sp,sp,48
    8000414e:	8082                	ret
    80004150:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004152:	0284a983          	lw	s3,40(s1)
    80004156:	f4cfd0ef          	jal	800018a2 <myproc>
    8000415a:	5904                	lw	s1,48(a0)
    8000415c:	413484b3          	sub	s1,s1,s3
    80004160:	0014b493          	seqz	s1,s1
    80004164:	69a2                	ld	s3,8(sp)
    80004166:	bfd9                	j	8000413c <holdingsleep+0x1e>

0000000080004168 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004168:	1141                	addi	sp,sp,-16
    8000416a:	e406                	sd	ra,8(sp)
    8000416c:	e022                	sd	s0,0(sp)
    8000416e:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004170:	00003597          	auipc	a1,0x3
    80004174:	40858593          	addi	a1,a1,1032 # 80007578 <etext+0x578>
    80004178:	0001e517          	auipc	a0,0x1e
    8000417c:	7b050513          	addi	a0,a0,1968 # 80022928 <ftable>
    80004180:	99bfc0ef          	jal	80000b1a <initlock>
}
    80004184:	60a2                	ld	ra,8(sp)
    80004186:	6402                	ld	s0,0(sp)
    80004188:	0141                	addi	sp,sp,16
    8000418a:	8082                	ret

000000008000418c <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    8000418c:	1101                	addi	sp,sp,-32
    8000418e:	ec06                	sd	ra,24(sp)
    80004190:	e822                	sd	s0,16(sp)
    80004192:	e426                	sd	s1,8(sp)
    80004194:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004196:	0001e517          	auipc	a0,0x1e
    8000419a:	79250513          	addi	a0,a0,1938 # 80022928 <ftable>
    8000419e:	9f3fc0ef          	jal	80000b90 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800041a2:	0001e497          	auipc	s1,0x1e
    800041a6:	79e48493          	addi	s1,s1,1950 # 80022940 <ftable+0x18>
    800041aa:	0001f717          	auipc	a4,0x1f
    800041ae:	73670713          	addi	a4,a4,1846 # 800238e0 <disk>
    if (f->ref == 0) {
    800041b2:	40dc                	lw	a5,4(s1)
    800041b4:	cf89                	beqz	a5,800041ce <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800041b6:	02848493          	addi	s1,s1,40
    800041ba:	fee49ce3          	bne	s1,a4,800041b2 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800041be:	0001e517          	auipc	a0,0x1e
    800041c2:	76a50513          	addi	a0,a0,1898 # 80022928 <ftable>
    800041c6:	a57fc0ef          	jal	80000c1c <release>
  return 0;
    800041ca:	4481                	li	s1,0
    800041cc:	a809                	j	800041de <filealloc+0x52>
      f->ref = 1;
    800041ce:	4785                	li	a5,1
    800041d0:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800041d2:	0001e517          	auipc	a0,0x1e
    800041d6:	75650513          	addi	a0,a0,1878 # 80022928 <ftable>
    800041da:	a43fc0ef          	jal	80000c1c <release>
}
    800041de:	8526                	mv	a0,s1
    800041e0:	60e2                	ld	ra,24(sp)
    800041e2:	6442                	ld	s0,16(sp)
    800041e4:	64a2                	ld	s1,8(sp)
    800041e6:	6105                	addi	sp,sp,32
    800041e8:	8082                	ret

00000000800041ea <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    800041ea:	1101                	addi	sp,sp,-32
    800041ec:	ec06                	sd	ra,24(sp)
    800041ee:	e822                	sd	s0,16(sp)
    800041f0:	e426                	sd	s1,8(sp)
    800041f2:	1000                	addi	s0,sp,32
    800041f4:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800041f6:	0001e517          	auipc	a0,0x1e
    800041fa:	73250513          	addi	a0,a0,1842 # 80022928 <ftable>
    800041fe:	993fc0ef          	jal	80000b90 <acquire>
  if (f->ref < 1)
    80004202:	40dc                	lw	a5,4(s1)
    80004204:	02f05063          	blez	a5,80004224 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004208:	2785                	addiw	a5,a5,1
    8000420a:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000420c:	0001e517          	auipc	a0,0x1e
    80004210:	71c50513          	addi	a0,a0,1820 # 80022928 <ftable>
    80004214:	a09fc0ef          	jal	80000c1c <release>
  return f;
}
    80004218:	8526                	mv	a0,s1
    8000421a:	60e2                	ld	ra,24(sp)
    8000421c:	6442                	ld	s0,16(sp)
    8000421e:	64a2                	ld	s1,8(sp)
    80004220:	6105                	addi	sp,sp,32
    80004222:	8082                	ret
    panic("filedup");
    80004224:	00003517          	auipc	a0,0x3
    80004228:	35c50513          	addi	a0,a0,860 # 80007580 <etext+0x580>
    8000422c:	dc4fc0ef          	jal	800007f0 <panic>

0000000080004230 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004230:	7139                	addi	sp,sp,-64
    80004232:	fc06                	sd	ra,56(sp)
    80004234:	f822                	sd	s0,48(sp)
    80004236:	f426                	sd	s1,40(sp)
    80004238:	0080                	addi	s0,sp,64
    8000423a:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000423c:	0001e517          	auipc	a0,0x1e
    80004240:	6ec50513          	addi	a0,a0,1772 # 80022928 <ftable>
    80004244:	94dfc0ef          	jal	80000b90 <acquire>
  if (f->ref < 1)
    80004248:	40dc                	lw	a5,4(s1)
    8000424a:	04f05a63          	blez	a5,8000429e <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    8000424e:	37fd                	addiw	a5,a5,-1
    80004250:	0007871b          	sext.w	a4,a5
    80004254:	c0dc                	sw	a5,4(s1)
    80004256:	04e04e63          	bgtz	a4,800042b2 <fileclose+0x82>
    8000425a:	f04a                	sd	s2,32(sp)
    8000425c:	ec4e                	sd	s3,24(sp)
    8000425e:	e852                	sd	s4,16(sp)
    80004260:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004262:	0004a903          	lw	s2,0(s1)
    80004266:	0094ca83          	lbu	s5,9(s1)
    8000426a:	0104ba03          	ld	s4,16(s1)
    8000426e:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004272:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004276:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000427a:	0001e517          	auipc	a0,0x1e
    8000427e:	6ae50513          	addi	a0,a0,1710 # 80022928 <ftable>
    80004282:	99bfc0ef          	jal	80000c1c <release>

  if (ff.type == FD_PIPE) {
    80004286:	4785                	li	a5,1
    80004288:	04f90063          	beq	s2,a5,800042c8 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    8000428c:	3979                	addiw	s2,s2,-2
    8000428e:	4785                	li	a5,1
    80004290:	0527f563          	bgeu	a5,s2,800042da <fileclose+0xaa>
    80004294:	7902                	ld	s2,32(sp)
    80004296:	69e2                	ld	s3,24(sp)
    80004298:	6a42                	ld	s4,16(sp)
    8000429a:	6aa2                	ld	s5,8(sp)
    8000429c:	a00d                	j	800042be <fileclose+0x8e>
    8000429e:	f04a                	sd	s2,32(sp)
    800042a0:	ec4e                	sd	s3,24(sp)
    800042a2:	e852                	sd	s4,16(sp)
    800042a4:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800042a6:	00003517          	auipc	a0,0x3
    800042aa:	2e250513          	addi	a0,a0,738 # 80007588 <etext+0x588>
    800042ae:	d42fc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    800042b2:	0001e517          	auipc	a0,0x1e
    800042b6:	67650513          	addi	a0,a0,1654 # 80022928 <ftable>
    800042ba:	963fc0ef          	jal	80000c1c <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800042be:	70e2                	ld	ra,56(sp)
    800042c0:	7442                	ld	s0,48(sp)
    800042c2:	74a2                	ld	s1,40(sp)
    800042c4:	6121                	addi	sp,sp,64
    800042c6:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800042c8:	85d6                	mv	a1,s5
    800042ca:	8552                	mv	a0,s4
    800042cc:	34c000ef          	jal	80004618 <pipeclose>
    800042d0:	7902                	ld	s2,32(sp)
    800042d2:	69e2                	ld	s3,24(sp)
    800042d4:	6a42                	ld	s4,16(sp)
    800042d6:	6aa2                	ld	s5,8(sp)
    800042d8:	b7dd                	j	800042be <fileclose+0x8e>
    begin_op();
    800042da:	aabff0ef          	jal	80003d84 <begin_op>
    iput(ff.ip);
    800042de:	854e                	mv	a0,s3
    800042e0:	9deff0ef          	jal	800034be <iput>
    end_op();
    800042e4:	b27ff0ef          	jal	80003e0a <end_op>
    800042e8:	7902                	ld	s2,32(sp)
    800042ea:	69e2                	ld	s3,24(sp)
    800042ec:	6a42                	ld	s4,16(sp)
    800042ee:	6aa2                	ld	s5,8(sp)
    800042f0:	b7f9                	j	800042be <fileclose+0x8e>

00000000800042f2 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800042f2:	715d                	addi	sp,sp,-80
    800042f4:	e486                	sd	ra,72(sp)
    800042f6:	e0a2                	sd	s0,64(sp)
    800042f8:	fc26                	sd	s1,56(sp)
    800042fa:	f44e                	sd	s3,40(sp)
    800042fc:	0880                	addi	s0,sp,80
    800042fe:	84aa                	mv	s1,a0
    80004300:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004302:	da0fd0ef          	jal	800018a2 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80004306:	409c                	lw	a5,0(s1)
    80004308:	37f9                	addiw	a5,a5,-2
    8000430a:	4705                	li	a4,1
    8000430c:	04f76263          	bltu	a4,a5,80004350 <filestat+0x5e>
    80004310:	f84a                	sd	s2,48(sp)
    80004312:	892a                	mv	s2,a0
    ilock(f->ip);
    80004314:	6c88                	ld	a0,24(s1)
    80004316:	826ff0ef          	jal	8000333c <ilock>
    stati(f->ip, &st);
    8000431a:	fb840593          	addi	a1,s0,-72
    8000431e:	6c88                	ld	a0,24(s1)
    80004320:	bcaff0ef          	jal	800036ea <stati>
    iunlock(f->ip);
    80004324:	6c88                	ld	a0,24(s1)
    80004326:	8c4ff0ef          	jal	800033ea <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    8000432a:	4761                	li	a4,24
    8000432c:	fb840693          	addi	a3,s0,-72
    80004330:	864e                	mv	a2,s3
    80004332:	04893583          	ld	a1,72(s2)
    80004336:	05093503          	ld	a0,80(s2)
    8000433a:	99efd0ef          	jal	800014d8 <copyout>
    8000433e:	41f5551b          	sraiw	a0,a0,0x1f
    80004342:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004344:	60a6                	ld	ra,72(sp)
    80004346:	6406                	ld	s0,64(sp)
    80004348:	74e2                	ld	s1,56(sp)
    8000434a:	79a2                	ld	s3,40(sp)
    8000434c:	6161                	addi	sp,sp,80
    8000434e:	8082                	ret
  return -1;
    80004350:	557d                	li	a0,-1
    80004352:	bfcd                	j	80004344 <filestat+0x52>

0000000080004354 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004354:	7179                	addi	sp,sp,-48
    80004356:	f406                	sd	ra,40(sp)
    80004358:	f022                	sd	s0,32(sp)
    8000435a:	e84a                	sd	s2,16(sp)
    8000435c:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    8000435e:	00854783          	lbu	a5,8(a0)
    80004362:	c3c5                	beqz	a5,80004402 <fileread+0xae>
    80004364:	ec26                	sd	s1,24(sp)
    80004366:	e44e                	sd	s3,8(sp)
    80004368:	84aa                	mv	s1,a0
    8000436a:	89ae                	mv	s3,a1
    8000436c:	8932                	mv	s2,a2
    8000436e:	08064c63          	bltz	a2,80004406 <fileread+0xb2>
    return -1;

  if (f->type == FD_PIPE) {
    80004372:	411c                	lw	a5,0(a0)
    80004374:	4705                	li	a4,1
    80004376:	04e78363          	beq	a5,a4,800043bc <fileread+0x68>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    8000437a:	470d                	li	a4,3
    8000437c:	04e78763          	beq	a5,a4,800043ca <fileread+0x76>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004380:	4709                	li	a4,2
    80004382:	06e79a63          	bne	a5,a4,800043f6 <fileread+0xa2>
    ilock(f->ip);
    80004386:	6d08                	ld	a0,24(a0)
    80004388:	fb5fe0ef          	jal	8000333c <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000438c:	874a                	mv	a4,s2
    8000438e:	5094                	lw	a3,32(s1)
    80004390:	864e                	mv	a2,s3
    80004392:	4585                	li	a1,1
    80004394:	6c88                	ld	a0,24(s1)
    80004396:	b7eff0ef          	jal	80003714 <readi>
    8000439a:	892a                	mv	s2,a0
    8000439c:	00a05563          	blez	a0,800043a6 <fileread+0x52>
      f->off += r;
    800043a0:	509c                	lw	a5,32(s1)
    800043a2:	9fa9                	addw	a5,a5,a0
    800043a4:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800043a6:	6c88                	ld	a0,24(s1)
    800043a8:	842ff0ef          	jal	800033ea <iunlock>
    800043ac:	64e2                	ld	s1,24(sp)
    800043ae:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800043b0:	854a                	mv	a0,s2
    800043b2:	70a2                	ld	ra,40(sp)
    800043b4:	7402                	ld	s0,32(sp)
    800043b6:	6942                	ld	s2,16(sp)
    800043b8:	6145                	addi	sp,sp,48
    800043ba:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800043bc:	6908                	ld	a0,16(a0)
    800043be:	3b6000ef          	jal	80004774 <piperead>
    800043c2:	892a                	mv	s2,a0
    800043c4:	64e2                	ld	s1,24(sp)
    800043c6:	69a2                	ld	s3,8(sp)
    800043c8:	b7e5                	j	800043b0 <fileread+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800043ca:	02451783          	lh	a5,36(a0)
    800043ce:	03079693          	slli	a3,a5,0x30
    800043d2:	92c1                	srli	a3,a3,0x30
    800043d4:	4725                	li	a4,9
    800043d6:	02d76c63          	bltu	a4,a3,8000440e <fileread+0xba>
    800043da:	0792                	slli	a5,a5,0x4
    800043dc:	0001e717          	auipc	a4,0x1e
    800043e0:	4ac70713          	addi	a4,a4,1196 # 80022888 <devsw>
    800043e4:	97ba                	add	a5,a5,a4
    800043e6:	639c                	ld	a5,0(a5)
    800043e8:	c79d                	beqz	a5,80004416 <fileread+0xc2>
    r = devsw[f->major].read(1, addr, n);
    800043ea:	4505                	li	a0,1
    800043ec:	9782                	jalr	a5
    800043ee:	892a                	mv	s2,a0
    800043f0:	64e2                	ld	s1,24(sp)
    800043f2:	69a2                	ld	s3,8(sp)
    800043f4:	bf75                	j	800043b0 <fileread+0x5c>
    panic("fileread");
    800043f6:	00003517          	auipc	a0,0x3
    800043fa:	1a250513          	addi	a0,a0,418 # 80007598 <etext+0x598>
    800043fe:	bf2fc0ef          	jal	800007f0 <panic>
    return -1;
    80004402:	597d                	li	s2,-1
    80004404:	b775                	j	800043b0 <fileread+0x5c>
    80004406:	597d                	li	s2,-1
    80004408:	64e2                	ld	s1,24(sp)
    8000440a:	69a2                	ld	s3,8(sp)
    8000440c:	b755                	j	800043b0 <fileread+0x5c>
      return -1;
    8000440e:	597d                	li	s2,-1
    80004410:	64e2                	ld	s1,24(sp)
    80004412:	69a2                	ld	s3,8(sp)
    80004414:	bf71                	j	800043b0 <fileread+0x5c>
    80004416:	597d                	li	s2,-1
    80004418:	64e2                	ld	s1,24(sp)
    8000441a:	69a2                	ld	s3,8(sp)
    8000441c:	bf51                	j	800043b0 <fileread+0x5c>

000000008000441e <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    8000441e:	00954783          	lbu	a5,9(a0)
    80004422:	10078663          	beqz	a5,8000452e <filewrite+0x110>
{
    80004426:	715d                	addi	sp,sp,-80
    80004428:	e486                	sd	ra,72(sp)
    8000442a:	e0a2                	sd	s0,64(sp)
    8000442c:	f84a                	sd	s2,48(sp)
    8000442e:	f052                	sd	s4,32(sp)
    80004430:	e85a                	sd	s6,16(sp)
    80004432:	0880                	addi	s0,sp,80
    80004434:	892a                	mv	s2,a0
    80004436:	8b2e                	mv	s6,a1
    80004438:	8a32                	mv	s4,a2
  if (f->writable == 0 || n < 0)
    8000443a:	0e064c63          	bltz	a2,80004532 <filewrite+0x114>
    return -1;

  if (f->type == FD_PIPE) {
    8000443e:	411c                	lw	a5,0(a0)
    80004440:	4705                	li	a4,1
    80004442:	02e78763          	beq	a5,a4,80004470 <filewrite+0x52>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004446:	470d                	li	a4,3
    80004448:	02e78863          	beq	a5,a4,80004478 <filewrite+0x5a>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000444c:	4709                	li	a4,2
    8000444e:	0ce79563          	bne	a5,a4,80004518 <filewrite+0xfa>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    80004452:	0ec05663          	blez	a2,8000453e <filewrite+0x120>
    80004456:	fc26                	sd	s1,56(sp)
    80004458:	f44e                	sd	s3,40(sp)
    8000445a:	ec56                	sd	s5,24(sp)
    8000445c:	e45e                	sd	s7,8(sp)
    8000445e:	e062                	sd	s8,0(sp)
    int i = 0;
    80004460:	4981                	li	s3,0
      int n1 = n - i;
      if (n1 > max)
    80004462:	6b85                	lui	s7,0x1
    80004464:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004468:	6c05                	lui	s8,0x1
    8000446a:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000446e:	a8b5                	j	800044ea <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004470:	6908                	ld	a0,16(a0)
    80004472:	1fe000ef          	jal	80004670 <pipewrite>
    80004476:	a851                	j	8000450a <filewrite+0xec>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004478:	02451783          	lh	a5,36(a0)
    8000447c:	03079693          	slli	a3,a5,0x30
    80004480:	92c1                	srli	a3,a3,0x30
    80004482:	4725                	li	a4,9
    80004484:	0ad76963          	bltu	a4,a3,80004536 <filewrite+0x118>
    80004488:	0792                	slli	a5,a5,0x4
    8000448a:	0001e717          	auipc	a4,0x1e
    8000448e:	3fe70713          	addi	a4,a4,1022 # 80022888 <devsw>
    80004492:	97ba                	add	a5,a5,a4
    80004494:	679c                	ld	a5,8(a5)
    80004496:	c3d5                	beqz	a5,8000453a <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    80004498:	4505                	li	a0,1
    8000449a:	9782                	jalr	a5
    8000449c:	a0bd                	j	8000450a <filewrite+0xec>
      if (n1 > max)
    8000449e:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    800044a2:	8e3ff0ef          	jal	80003d84 <begin_op>
      ilock(f->ip);
    800044a6:	01893503          	ld	a0,24(s2)
    800044aa:	e93fe0ef          	jal	8000333c <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800044ae:	8756                	mv	a4,s5
    800044b0:	02092683          	lw	a3,32(s2)
    800044b4:	01698633          	add	a2,s3,s6
    800044b8:	4585                	li	a1,1
    800044ba:	01893503          	ld	a0,24(s2)
    800044be:	b52ff0ef          	jal	80003810 <writei>
    800044c2:	84aa                	mv	s1,a0
    800044c4:	00a05763          	blez	a0,800044d2 <filewrite+0xb4>
        f->off += r;
    800044c8:	02092783          	lw	a5,32(s2)
    800044cc:	9fa9                	addw	a5,a5,a0
    800044ce:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800044d2:	01893503          	ld	a0,24(s2)
    800044d6:	f15fe0ef          	jal	800033ea <iunlock>
      end_op();
    800044da:	931ff0ef          	jal	80003e0a <end_op>

      if (r != n1) {
    800044de:	009a9e63          	bne	s5,s1,800044fa <filewrite+0xdc>
        // error from writei
        break;
      }
      i += r;
    800044e2:	013489bb          	addw	s3,s1,s3
    while (i < n) {
    800044e6:	0149da63          	bge	s3,s4,800044fa <filewrite+0xdc>
      int n1 = n - i;
    800044ea:	413a04bb          	subw	s1,s4,s3
      if (n1 > max)
    800044ee:	0004879b          	sext.w	a5,s1
    800044f2:	fafbd6e3          	bge	s7,a5,8000449e <filewrite+0x80>
    800044f6:	84e2                	mv	s1,s8
    800044f8:	b75d                	j	8000449e <filewrite+0x80>
    }
    ret = (i == n ? n : -1);
    800044fa:	053a1463          	bne	s4,s3,80004542 <filewrite+0x124>
    800044fe:	8552                	mv	a0,s4
    80004500:	74e2                	ld	s1,56(sp)
    80004502:	79a2                	ld	s3,40(sp)
    80004504:	6ae2                	ld	s5,24(sp)
    80004506:	6ba2                	ld	s7,8(sp)
    80004508:	6c02                	ld	s8,0(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000450a:	60a6                	ld	ra,72(sp)
    8000450c:	6406                	ld	s0,64(sp)
    8000450e:	7942                	ld	s2,48(sp)
    80004510:	7a02                	ld	s4,32(sp)
    80004512:	6b42                	ld	s6,16(sp)
    80004514:	6161                	addi	sp,sp,80
    80004516:	8082                	ret
    80004518:	fc26                	sd	s1,56(sp)
    8000451a:	f44e                	sd	s3,40(sp)
    8000451c:	ec56                	sd	s5,24(sp)
    8000451e:	e45e                	sd	s7,8(sp)
    80004520:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004522:	00003517          	auipc	a0,0x3
    80004526:	08650513          	addi	a0,a0,134 # 800075a8 <etext+0x5a8>
    8000452a:	ac6fc0ef          	jal	800007f0 <panic>
    return -1;
    8000452e:	557d                	li	a0,-1
}
    80004530:	8082                	ret
    return -1;
    80004532:	557d                	li	a0,-1
    80004534:	bfd9                	j	8000450a <filewrite+0xec>
      return -1;
    80004536:	557d                	li	a0,-1
    80004538:	bfc9                	j	8000450a <filewrite+0xec>
    8000453a:	557d                	li	a0,-1
    8000453c:	b7f9                	j	8000450a <filewrite+0xec>
    ret = (i == n ? n : -1);
    8000453e:	8532                	mv	a0,a2
    80004540:	b7e9                	j	8000450a <filewrite+0xec>
    80004542:	557d                	li	a0,-1
    80004544:	74e2                	ld	s1,56(sp)
    80004546:	79a2                	ld	s3,40(sp)
    80004548:	6ae2                	ld	s5,24(sp)
    8000454a:	6ba2                	ld	s7,8(sp)
    8000454c:	6c02                	ld	s8,0(sp)
    8000454e:	bf75                	j	8000450a <filewrite+0xec>

0000000080004550 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004550:	7179                	addi	sp,sp,-48
    80004552:	f406                	sd	ra,40(sp)
    80004554:	f022                	sd	s0,32(sp)
    80004556:	ec26                	sd	s1,24(sp)
    80004558:	e052                	sd	s4,0(sp)
    8000455a:	1800                	addi	s0,sp,48
    8000455c:	84aa                	mv	s1,a0
    8000455e:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004560:	0005b023          	sd	zero,0(a1)
    80004564:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004568:	c25ff0ef          	jal	8000418c <filealloc>
    8000456c:	e088                	sd	a0,0(s1)
    8000456e:	c549                	beqz	a0,800045f8 <pipealloc+0xa8>
    80004570:	c1dff0ef          	jal	8000418c <filealloc>
    80004574:	00aa3023          	sd	a0,0(s4)
    80004578:	cd25                	beqz	a0,800045f0 <pipealloc+0xa0>
    8000457a:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    8000457c:	d4efc0ef          	jal	80000aca <kalloc>
    80004580:	892a                	mv	s2,a0
    80004582:	c12d                	beqz	a0,800045e4 <pipealloc+0x94>
    80004584:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004586:	4985                	li	s3,1
    80004588:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000458c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004590:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004594:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004598:	00003597          	auipc	a1,0x3
    8000459c:	02058593          	addi	a1,a1,32 # 800075b8 <etext+0x5b8>
    800045a0:	d7afc0ef          	jal	80000b1a <initlock>
  (*f0)->type = FD_PIPE;
    800045a4:	609c                	ld	a5,0(s1)
    800045a6:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800045aa:	609c                	ld	a5,0(s1)
    800045ac:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800045b0:	609c                	ld	a5,0(s1)
    800045b2:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800045b6:	609c                	ld	a5,0(s1)
    800045b8:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800045bc:	000a3783          	ld	a5,0(s4)
    800045c0:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800045c4:	000a3783          	ld	a5,0(s4)
    800045c8:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800045cc:	000a3783          	ld	a5,0(s4)
    800045d0:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800045d4:	000a3783          	ld	a5,0(s4)
    800045d8:	0127b823          	sd	s2,16(a5)
  return 0;
    800045dc:	4501                	li	a0,0
    800045de:	6942                	ld	s2,16(sp)
    800045e0:	69a2                	ld	s3,8(sp)
    800045e2:	a01d                	j	80004608 <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    800045e4:	6088                	ld	a0,0(s1)
    800045e6:	c119                	beqz	a0,800045ec <pipealloc+0x9c>
    800045e8:	6942                	ld	s2,16(sp)
    800045ea:	a029                	j	800045f4 <pipealloc+0xa4>
    800045ec:	6942                	ld	s2,16(sp)
    800045ee:	a029                	j	800045f8 <pipealloc+0xa8>
    800045f0:	6088                	ld	a0,0(s1)
    800045f2:	c10d                	beqz	a0,80004614 <pipealloc+0xc4>
    fileclose(*f0);
    800045f4:	c3dff0ef          	jal	80004230 <fileclose>
  if (*f1)
    800045f8:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800045fc:	557d                	li	a0,-1
  if (*f1)
    800045fe:	c789                	beqz	a5,80004608 <pipealloc+0xb8>
    fileclose(*f1);
    80004600:	853e                	mv	a0,a5
    80004602:	c2fff0ef          	jal	80004230 <fileclose>
  return -1;
    80004606:	557d                	li	a0,-1
}
    80004608:	70a2                	ld	ra,40(sp)
    8000460a:	7402                	ld	s0,32(sp)
    8000460c:	64e2                	ld	s1,24(sp)
    8000460e:	6a02                	ld	s4,0(sp)
    80004610:	6145                	addi	sp,sp,48
    80004612:	8082                	ret
  return -1;
    80004614:	557d                	li	a0,-1
    80004616:	bfcd                	j	80004608 <pipealloc+0xb8>

0000000080004618 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004618:	1101                	addi	sp,sp,-32
    8000461a:	ec06                	sd	ra,24(sp)
    8000461c:	e822                	sd	s0,16(sp)
    8000461e:	e426                	sd	s1,8(sp)
    80004620:	e04a                	sd	s2,0(sp)
    80004622:	1000                	addi	s0,sp,32
    80004624:	84aa                	mv	s1,a0
    80004626:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004628:	d68fc0ef          	jal	80000b90 <acquire>
  if (writable) {
    8000462c:	02090763          	beqz	s2,8000465a <pipeclose+0x42>
    pi->writeopen = 0;
    80004630:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004634:	21848513          	addi	a0,s1,536
    80004638:	929fd0ef          	jal	80001f60 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000463c:	2204b783          	ld	a5,544(s1)
    80004640:	e785                	bnez	a5,80004668 <pipeclose+0x50>
    release(&pi->lock);
    80004642:	8526                	mv	a0,s1
    80004644:	dd8fc0ef          	jal	80000c1c <release>
    kfree((char *)pi);
    80004648:	8526                	mv	a0,s1
    8000464a:	b9efc0ef          	jal	800009e8 <kfree>
  } else
    release(&pi->lock);
}
    8000464e:	60e2                	ld	ra,24(sp)
    80004650:	6442                	ld	s0,16(sp)
    80004652:	64a2                	ld	s1,8(sp)
    80004654:	6902                	ld	s2,0(sp)
    80004656:	6105                	addi	sp,sp,32
    80004658:	8082                	ret
    pi->readopen = 0;
    8000465a:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000465e:	21c48513          	addi	a0,s1,540
    80004662:	8fffd0ef          	jal	80001f60 <wakeup>
    80004666:	bfd9                	j	8000463c <pipeclose+0x24>
    release(&pi->lock);
    80004668:	8526                	mv	a0,s1
    8000466a:	db2fc0ef          	jal	80000c1c <release>
}
    8000466e:	b7c5                	j	8000464e <pipeclose+0x36>

0000000080004670 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004670:	711d                	addi	sp,sp,-96
    80004672:	ec86                	sd	ra,88(sp)
    80004674:	e8a2                	sd	s0,80(sp)
    80004676:	e4a6                	sd	s1,72(sp)
    80004678:	e0ca                	sd	s2,64(sp)
    8000467a:	fc4e                	sd	s3,56(sp)
    8000467c:	f852                	sd	s4,48(sp)
    8000467e:	f456                	sd	s5,40(sp)
    80004680:	1080                	addi	s0,sp,96
    80004682:	84aa                	mv	s1,a0
    80004684:	8aae                	mv	s5,a1
    80004686:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004688:	a1afd0ef          	jal	800018a2 <myproc>
    8000468c:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000468e:	8526                	mv	a0,s1
    80004690:	d00fc0ef          	jal	80000b90 <acquire>
  while (i < n) {
    80004694:	0d405e63          	blez	s4,80004770 <pipewrite+0x100>
    80004698:	f05a                	sd	s6,32(sp)
    8000469a:	ec5e                	sd	s7,24(sp)
    8000469c:	e862                	sd	s8,16(sp)
  int i = 0;
    8000469e:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    800046a0:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800046a2:	21848c13          	addi	s8,s1,536
      sleep_prepare(&pi->nwrite);
    800046a6:	21c48b93          	addi	s7,s1,540
    800046aa:	a091                	j	800046ee <pipewrite+0x7e>
      release(&pi->lock);
    800046ac:	8526                	mv	a0,s1
    800046ae:	d6efc0ef          	jal	80000c1c <release>
      return -1;
    800046b2:	597d                	li	s2,-1
    800046b4:	7b02                	ld	s6,32(sp)
    800046b6:	6be2                	ld	s7,24(sp)
    800046b8:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800046ba:	854a                	mv	a0,s2
    800046bc:	60e6                	ld	ra,88(sp)
    800046be:	6446                	ld	s0,80(sp)
    800046c0:	64a6                	ld	s1,72(sp)
    800046c2:	6906                	ld	s2,64(sp)
    800046c4:	79e2                	ld	s3,56(sp)
    800046c6:	7a42                	ld	s4,48(sp)
    800046c8:	7aa2                	ld	s5,40(sp)
    800046ca:	6125                	addi	sp,sp,96
    800046cc:	8082                	ret
      wakeup(&pi->nread);
    800046ce:	8562                	mv	a0,s8
    800046d0:	891fd0ef          	jal	80001f60 <wakeup>
      sleep_prepare(&pi->nwrite);
    800046d4:	855e                	mv	a0,s7
    800046d6:	81ffd0ef          	jal	80001ef4 <sleep_prepare>
      release(&pi->lock);
    800046da:	8526                	mv	a0,s1
    800046dc:	d40fc0ef          	jal	80000c1c <release>
      sleep();
    800046e0:	851fd0ef          	jal	80001f30 <sleep>
      acquire(&pi->lock);
    800046e4:	8526                	mv	a0,s1
    800046e6:	caafc0ef          	jal	80000b90 <acquire>
  while (i < n) {
    800046ea:	07495863          	bge	s2,s4,8000475a <pipewrite+0xea>
    if (pi->readopen == 0 || killed(pr)) {
    800046ee:	2204a783          	lw	a5,544(s1)
    800046f2:	dfcd                	beqz	a5,800046ac <pipewrite+0x3c>
    800046f4:	854e                	mv	a0,s3
    800046f6:	a59fd0ef          	jal	8000214e <killed>
    800046fa:	f94d                	bnez	a0,800046ac <pipewrite+0x3c>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    800046fc:	2184a783          	lw	a5,536(s1)
    80004700:	21c4a703          	lw	a4,540(s1)
    80004704:	2007879b          	addiw	a5,a5,512
    80004708:	fcf703e3          	beq	a4,a5,800046ce <pipewrite+0x5e>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000470c:	4705                	li	a4,1
    8000470e:	015906b3          	add	a3,s2,s5
    80004712:	faf40613          	addi	a2,s0,-81
    80004716:	0489b583          	ld	a1,72(s3)
    8000471a:	0509b503          	ld	a0,80(s3)
    8000471e:	ea7fc0ef          	jal	800015c4 <copyin>
    80004722:	03650163          	beq	a0,s6,80004744 <pipewrite+0xd4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004726:	21c4a783          	lw	a5,540(s1)
    8000472a:	0017871b          	addiw	a4,a5,1
    8000472e:	20e4ae23          	sw	a4,540(s1)
    80004732:	1ff7f793          	andi	a5,a5,511
    80004736:	97a6                	add	a5,a5,s1
    80004738:	faf44703          	lbu	a4,-81(s0)
    8000473c:	00e78c23          	sb	a4,24(a5)
      i++;
    80004740:	2905                	addiw	s2,s2,1
    80004742:	b765                	j	800046ea <pipewrite+0x7a>
        if (i == 0)
    80004744:	00090663          	beqz	s2,80004750 <pipewrite+0xe0>
    80004748:	7b02                	ld	s6,32(sp)
    8000474a:	6be2                	ld	s7,24(sp)
    8000474c:	6c42                	ld	s8,16(sp)
    8000474e:	a809                	j	80004760 <pipewrite+0xf0>
          i = -1;
    80004750:	892a                	mv	s2,a0
        break;
    80004752:	7b02                	ld	s6,32(sp)
    80004754:	6be2                	ld	s7,24(sp)
    80004756:	6c42                	ld	s8,16(sp)
    80004758:	a021                	j	80004760 <pipewrite+0xf0>
    8000475a:	7b02                	ld	s6,32(sp)
    8000475c:	6be2                	ld	s7,24(sp)
    8000475e:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    80004760:	21848513          	addi	a0,s1,536
    80004764:	ffcfd0ef          	jal	80001f60 <wakeup>
  release(&pi->lock);
    80004768:	8526                	mv	a0,s1
    8000476a:	cb2fc0ef          	jal	80000c1c <release>
  return i;
    8000476e:	b7b1                	j	800046ba <pipewrite+0x4a>
  int i = 0;
    80004770:	4901                	li	s2,0
    80004772:	b7fd                	j	80004760 <pipewrite+0xf0>

0000000080004774 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004774:	715d                	addi	sp,sp,-80
    80004776:	e486                	sd	ra,72(sp)
    80004778:	e0a2                	sd	s0,64(sp)
    8000477a:	fc26                	sd	s1,56(sp)
    8000477c:	f84a                	sd	s2,48(sp)
    8000477e:	f44e                	sd	s3,40(sp)
    80004780:	f052                	sd	s4,32(sp)
    80004782:	ec56                	sd	s5,24(sp)
    80004784:	0880                	addi	s0,sp,80
    80004786:	84aa                	mv	s1,a0
    80004788:	89ae                	mv	s3,a1
    8000478a:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000478c:	916fd0ef          	jal	800018a2 <myproc>
    80004790:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    80004792:	8526                	mv	a0,s1
    80004794:	bfcfc0ef          	jal	80000b90 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004798:	2184a703          	lw	a4,536(s1)
    8000479c:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800047a0:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047a4:	02f71c63          	bne	a4,a5,800047dc <piperead+0x68>
    800047a8:	2244a783          	lw	a5,548(s1)
    800047ac:	cf9d                	beqz	a5,800047ea <piperead+0x76>
    if (killed(pr)) {
    800047ae:	854a                	mv	a0,s2
    800047b0:	99ffd0ef          	jal	8000214e <killed>
    800047b4:	e515                	bnez	a0,800047e0 <piperead+0x6c>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800047b6:	8552                	mv	a0,s4
    800047b8:	f3cfd0ef          	jal	80001ef4 <sleep_prepare>
    release(&pi->lock);
    800047bc:	8526                	mv	a0,s1
    800047be:	c5efc0ef          	jal	80000c1c <release>
    sleep();
    800047c2:	f6efd0ef          	jal	80001f30 <sleep>
    acquire(&pi->lock);
    800047c6:	8526                	mv	a0,s1
    800047c8:	bc8fc0ef          	jal	80000b90 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047cc:	2184a703          	lw	a4,536(s1)
    800047d0:	21c4a783          	lw	a5,540(s1)
    800047d4:	fcf70ae3          	beq	a4,a5,800047a8 <piperead+0x34>
    800047d8:	e85a                	sd	s6,16(sp)
    800047da:	a809                	j	800047ec <piperead+0x78>
    800047dc:	e85a                	sd	s6,16(sp)
    800047de:	a039                	j	800047ec <piperead+0x78>
      release(&pi->lock);
    800047e0:	8526                	mv	a0,s1
    800047e2:	c3afc0ef          	jal	80000c1c <release>
      return -1;
    800047e6:	5a7d                	li	s4,-1
    800047e8:	a08d                	j	8000484a <piperead+0xd6>
    800047ea:	e85a                	sd	s6,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047ec:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    800047ee:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047f0:	05505563          	blez	s5,8000483a <piperead+0xc6>
    if (pi->nread == pi->nwrite)
    800047f4:	2184a783          	lw	a5,536(s1)
    800047f8:	21c4a703          	lw	a4,540(s1)
    800047fc:	02f70f63          	beq	a4,a5,8000483a <piperead+0xc6>
    ch = pi->data[pi->nread % PIPESIZE];
    80004800:	1ff7f793          	andi	a5,a5,511
    80004804:	97a6                	add	a5,a5,s1
    80004806:	0187c783          	lbu	a5,24(a5)
    8000480a:	faf40fa3          	sb	a5,-65(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    8000480e:	4705                	li	a4,1
    80004810:	fbf40693          	addi	a3,s0,-65
    80004814:	864e                	mv	a2,s3
    80004816:	04893583          	ld	a1,72(s2)
    8000481a:	05093503          	ld	a0,80(s2)
    8000481e:	cbbfc0ef          	jal	800014d8 <copyout>
    80004822:	03650e63          	beq	a0,s6,8000485e <piperead+0xea>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004826:	2184a783          	lw	a5,536(s1)
    8000482a:	2785                	addiw	a5,a5,1
    8000482c:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004830:	2a05                	addiw	s4,s4,1
    80004832:	0985                	addi	s3,s3,1
    80004834:	fd4a90e3          	bne	s5,s4,800047f4 <piperead+0x80>
    80004838:	8a56                	mv	s4,s5
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    8000483a:	21c48513          	addi	a0,s1,540
    8000483e:	f22fd0ef          	jal	80001f60 <wakeup>
  release(&pi->lock);
    80004842:	8526                	mv	a0,s1
    80004844:	bd8fc0ef          	jal	80000c1c <release>
    80004848:	6b42                	ld	s6,16(sp)
  return i;
}
    8000484a:	8552                	mv	a0,s4
    8000484c:	60a6                	ld	ra,72(sp)
    8000484e:	6406                	ld	s0,64(sp)
    80004850:	74e2                	ld	s1,56(sp)
    80004852:	7942                	ld	s2,48(sp)
    80004854:	79a2                	ld	s3,40(sp)
    80004856:	7a02                	ld	s4,32(sp)
    80004858:	6ae2                	ld	s5,24(sp)
    8000485a:	6161                	addi	sp,sp,80
    8000485c:	8082                	ret
      if (i == 0)
    8000485e:	fc0a1ee3          	bnez	s4,8000483a <piperead+0xc6>
        i = -1;
    80004862:	8a2a                	mv	s4,a0
    80004864:	bfd9                	j	8000483a <piperead+0xc6>

0000000080004866 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    80004866:	1141                	addi	sp,sp,-16
    80004868:	e422                	sd	s0,8(sp)
    8000486a:	0800                	addi	s0,sp,16
    8000486c:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    8000486e:	8905                	andi	a0,a0,1
    80004870:	050e                	slli	a0,a0,0x3
    perm = PTE_X;
  if (flags & 0x2)
    80004872:	8b89                	andi	a5,a5,2
    80004874:	c399                	beqz	a5,8000487a <flags2perm+0x14>
    perm |= PTE_W;
    80004876:	00456513          	ori	a0,a0,4
  return perm;
}
    8000487a:	6422                	ld	s0,8(sp)
    8000487c:	0141                	addi	sp,sp,16
    8000487e:	8082                	ret

0000000080004880 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004880:	df010113          	addi	sp,sp,-528
    80004884:	20113423          	sd	ra,520(sp)
    80004888:	20813023          	sd	s0,512(sp)
    8000488c:	ffa6                	sd	s1,504(sp)
    8000488e:	fbca                	sd	s2,496(sp)
    80004890:	0c00                	addi	s0,sp,528
    80004892:	892a                	mv	s2,a0
    80004894:	dea43c23          	sd	a0,-520(s0)
    80004898:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    8000489c:	806fd0ef          	jal	800018a2 <myproc>
    800048a0:	84aa                	mv	s1,a0

  begin_op();
    800048a2:	ce2ff0ef          	jal	80003d84 <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    800048a6:	854a                	mv	a0,s2
    800048a8:	b08ff0ef          	jal	80003bb0 <namei>
    800048ac:	c931                	beqz	a0,80004900 <kexec+0x80>
    800048ae:	f3d2                	sd	s4,480(sp)
    800048b0:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800048b2:	a8bfe0ef          	jal	8000333c <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800048b6:	04000713          	li	a4,64
    800048ba:	4681                	li	a3,0
    800048bc:	e5040613          	addi	a2,s0,-432
    800048c0:	4581                	li	a1,0
    800048c2:	8552                	mv	a0,s4
    800048c4:	e51fe0ef          	jal	80003714 <readi>
    800048c8:	04000793          	li	a5,64
    800048cc:	00f51a63          	bne	a0,a5,800048e0 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    800048d0:	e5042703          	lw	a4,-432(s0)
    800048d4:	464c47b7          	lui	a5,0x464c4
    800048d8:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800048dc:	02f70663          	beq	a4,a5,80004908 <kexec+0x88>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    800048e0:	8552                	mv	a0,s4
    800048e2:	cadfe0ef          	jal	8000358e <iunlockput>
    end_op();
    800048e6:	d24ff0ef          	jal	80003e0a <end_op>
  }
  return -1;
    800048ea:	557d                	li	a0,-1
    800048ec:	7a1e                	ld	s4,480(sp)
}
    800048ee:	20813083          	ld	ra,520(sp)
    800048f2:	20013403          	ld	s0,512(sp)
    800048f6:	74fe                	ld	s1,504(sp)
    800048f8:	795e                	ld	s2,496(sp)
    800048fa:	21010113          	addi	sp,sp,528
    800048fe:	8082                	ret
    end_op();
    80004900:	d0aff0ef          	jal	80003e0a <end_op>
    return -1;
    80004904:	557d                	li	a0,-1
    80004906:	b7e5                	j	800048ee <kexec+0x6e>
    80004908:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    8000490a:	8526                	mv	a0,s1
    8000490c:	898fd0ef          	jal	800019a4 <proc_pagetable>
    80004910:	8b2a                	mv	s6,a0
    80004912:	2c050963          	beqz	a0,80004be4 <kexec+0x364>
    80004916:	f7ce                	sd	s3,488(sp)
    80004918:	efd6                	sd	s5,472(sp)
    8000491a:	e7de                	sd	s7,456(sp)
    8000491c:	e3e2                	sd	s8,448(sp)
    8000491e:	ff66                	sd	s9,440(sp)
    80004920:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004922:	e7042d03          	lw	s10,-400(s0)
    80004926:	e8845783          	lhu	a5,-376(s0)
    8000492a:	12078863          	beqz	a5,80004a5a <kexec+0x1da>
    8000492e:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004930:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004932:	4d81                	li	s11,0
    if (ph.vaddr % PGSIZE != 0)
    80004934:	6c85                	lui	s9,0x1
    80004936:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    8000493a:	def43823          	sd	a5,-528(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    8000493e:	6a85                	lui	s5,0x1
    80004940:	a085                	j	800049a0 <kexec+0x120>
      panic("loadseg: address should exist");
    80004942:	00003517          	auipc	a0,0x3
    80004946:	c7e50513          	addi	a0,a0,-898 # 800075c0 <etext+0x5c0>
    8000494a:	ea7fb0ef          	jal	800007f0 <panic>
    if (sz - i < PGSIZE)
    8000494e:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004950:	8726                	mv	a4,s1
    80004952:	012c06bb          	addw	a3,s8,s2
    80004956:	4581                	li	a1,0
    80004958:	8552                	mv	a0,s4
    8000495a:	dbbfe0ef          	jal	80003714 <readi>
    8000495e:	2501                	sext.w	a0,a0
    80004960:	24a49863          	bne	s1,a0,80004bb0 <kexec+0x330>
  for (i = 0; i < sz; i += PGSIZE) {
    80004964:	012a893b          	addw	s2,s5,s2
    80004968:	03397363          	bgeu	s2,s3,8000498e <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    8000496c:	02091593          	slli	a1,s2,0x20
    80004970:	9181                	srli	a1,a1,0x20
    80004972:	95de                	add	a1,a1,s7
    80004974:	855a                	mv	a0,s6
    80004976:	deefc0ef          	jal	80000f64 <walkaddr>
    8000497a:	862a                	mv	a2,a0
    if (pa == 0)
    8000497c:	d179                	beqz	a0,80004942 <kexec+0xc2>
    if (sz - i < PGSIZE)
    8000497e:	412984bb          	subw	s1,s3,s2
    80004982:	0004879b          	sext.w	a5,s1
    80004986:	fcfcf4e3          	bgeu	s9,a5,8000494e <kexec+0xce>
    8000498a:	84d6                	mv	s1,s5
    8000498c:	b7c9                	j	8000494e <kexec+0xce>
    sz = sz1;
    8000498e:	e0843903          	ld	s2,-504(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004992:	2d85                	addiw	s11,s11,1
    80004994:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    80004998:	e8845783          	lhu	a5,-376(s0)
    8000499c:	08fdd063          	bge	s11,a5,80004a1c <kexec+0x19c>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800049a0:	2d01                	sext.w	s10,s10
    800049a2:	03800713          	li	a4,56
    800049a6:	86ea                	mv	a3,s10
    800049a8:	e1840613          	addi	a2,s0,-488
    800049ac:	4581                	li	a1,0
    800049ae:	8552                	mv	a0,s4
    800049b0:	d65fe0ef          	jal	80003714 <readi>
    800049b4:	03800793          	li	a5,56
    800049b8:	1cf51463          	bne	a0,a5,80004b80 <kexec+0x300>
    if (ph.type != ELF_PROG_LOAD)
    800049bc:	e1842783          	lw	a5,-488(s0)
    800049c0:	4705                	li	a4,1
    800049c2:	fce798e3          	bne	a5,a4,80004992 <kexec+0x112>
    if (ph.memsz < ph.filesz)
    800049c6:	e4043483          	ld	s1,-448(s0)
    800049ca:	e3843783          	ld	a5,-456(s0)
    800049ce:	1af4ed63          	bltu	s1,a5,80004b88 <kexec+0x308>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    800049d2:	e2843783          	ld	a5,-472(s0)
    800049d6:	94be                	add	s1,s1,a5
    800049d8:	1af4ec63          	bltu	s1,a5,80004b90 <kexec+0x310>
    if (ph.vaddr % PGSIZE != 0)
    800049dc:	df043703          	ld	a4,-528(s0)
    800049e0:	8ff9                	and	a5,a5,a4
    800049e2:	1a079b63          	bnez	a5,80004b98 <kexec+0x318>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    800049e6:	e1c42503          	lw	a0,-484(s0)
    800049ea:	e7dff0ef          	jal	80004866 <flags2perm>
    800049ee:	86aa                	mv	a3,a0
    800049f0:	8626                	mv	a2,s1
    800049f2:	85ca                	mv	a1,s2
    800049f4:	855a                	mv	a0,s6
    800049f6:	847fc0ef          	jal	8000123c <uvmalloc>
    800049fa:	e0a43423          	sd	a0,-504(s0)
    800049fe:	1a050163          	beqz	a0,80004ba0 <kexec+0x320>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a02:	e2843b83          	ld	s7,-472(s0)
    80004a06:	e2042c03          	lw	s8,-480(s0)
    80004a0a:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004a0e:	00098463          	beqz	s3,80004a16 <kexec+0x196>
    80004a12:	4901                	li	s2,0
    80004a14:	bfa1                	j	8000496c <kexec+0xec>
    sz = sz1;
    80004a16:	e0843903          	ld	s2,-504(s0)
    80004a1a:	bfa5                	j	80004992 <kexec+0x112>
    80004a1c:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004a1e:	8552                	mv	a0,s4
    80004a20:	b6ffe0ef          	jal	8000358e <iunlockput>
  end_op();
    80004a24:	be6ff0ef          	jal	80003e0a <end_op>
  p = myproc();
    80004a28:	e7bfc0ef          	jal	800018a2 <myproc>
    80004a2c:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004a2e:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004a32:	6b85                	lui	s7,0x1
    80004a34:	1bfd                	addi	s7,s7,-1 # fff <_entry-0x7ffff001>
    80004a36:	9bca                	add	s7,s7,s2
    80004a38:	77fd                	lui	a5,0xfffff
    80004a3a:	00fbfbb3          	and	s7,s7,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004a3e:	4691                	li	a3,4
    80004a40:	6609                	lui	a2,0x2
    80004a42:	965e                	add	a2,a2,s7
    80004a44:	85de                	mv	a1,s7
    80004a46:	855a                	mv	a0,s6
    80004a48:	ff4fc0ef          	jal	8000123c <uvmalloc>
    80004a4c:	e0a43423          	sd	a0,-504(s0)
    80004a50:	e519                	bnez	a0,80004a5e <kexec+0x1de>
  if (pagetable)
    80004a52:	e1743423          	sd	s7,-504(s0)
    80004a56:	4a01                	li	s4,0
    80004a58:	aaa9                	j	80004bb2 <kexec+0x332>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a5a:	4901                	li	s2,0
    80004a5c:	b7c9                	j	80004a1e <kexec+0x19e>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004a5e:	75f9                	lui	a1,0xffffe
    80004a60:	8baa                	mv	s7,a0
    80004a62:	95aa                	add	a1,a1,a0
    80004a64:	855a                	mv	a0,s6
    80004a66:	9adfc0ef          	jal	80001412 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004a6a:	7afd                	lui	s5,0xfffff
    80004a6c:	9ade                	add	s5,s5,s7
  for (argc = 0; argv[argc]; argc++) {
    80004a6e:	e0043783          	ld	a5,-512(s0)
    80004a72:	6388                	ld	a0,0(a5)
    80004a74:	c15d                	beqz	a0,80004b1a <kexec+0x29a>
    80004a76:	e9040913          	addi	s2,s0,-368
    80004a7a:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004a7c:	b48fc0ef          	jal	80000dc4 <strlen>
    80004a80:	0015079b          	addiw	a5,a0,1
    80004a84:	40fb87b3          	sub	a5,s7,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004a88:	ff07fb93          	andi	s7,a5,-16
    if (sp < stackbase)
    80004a8c:	115bee63          	bltu	s7,s5,80004ba8 <kexec+0x328>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004a90:	e0043c83          	ld	s9,-512(s0)
    80004a94:	000cbc03          	ld	s8,0(s9)
    80004a98:	8562                	mv	a0,s8
    80004a9a:	b2afc0ef          	jal	80000dc4 <strlen>
    80004a9e:	0015071b          	addiw	a4,a0,1
    80004aa2:	86e2                	mv	a3,s8
    80004aa4:	865e                	mv	a2,s7
    80004aa6:	e0843583          	ld	a1,-504(s0)
    80004aaa:	855a                	mv	a0,s6
    80004aac:	a2dfc0ef          	jal	800014d8 <copyout>
    80004ab0:	0e054e63          	bltz	a0,80004bac <kexec+0x32c>
    ustack[argc] = sp;
    80004ab4:	01793023          	sd	s7,0(s2)
  for (argc = 0; argv[argc]; argc++) {
    80004ab8:	0485                	addi	s1,s1,1
    80004aba:	008c8793          	addi	a5,s9,8
    80004abe:	e0f43023          	sd	a5,-512(s0)
    80004ac2:	008cb503          	ld	a0,8(s9)
    80004ac6:	0921                	addi	s2,s2,8
    80004ac8:	f955                	bnez	a0,80004a7c <kexec+0x1fc>
  ustack[argc] = 0;
    80004aca:	00349793          	slli	a5,s1,0x3
    80004ace:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffdb570>
    80004ad2:	97a2                	add	a5,a5,s0
    80004ad4:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004ad8:	00148713          	addi	a4,s1,1
    80004adc:	070e                	slli	a4,a4,0x3
    80004ade:	40eb8933          	sub	s2,s7,a4
  sp -= sp % 16;
    80004ae2:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004ae6:	e0843583          	ld	a1,-504(s0)
    80004aea:	8bae                	mv	s7,a1
  if (sp < stackbase)
    80004aec:	f75963e3          	bltu	s2,s5,80004a52 <kexec+0x1d2>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004af0:	e9040693          	addi	a3,s0,-368
    80004af4:	864a                	mv	a2,s2
    80004af6:	855a                	mv	a0,s6
    80004af8:	9e1fc0ef          	jal	800014d8 <copyout>
    80004afc:	0e054663          	bltz	a0,80004be8 <kexec+0x368>
  p->trapframe->a1 = sp;
    80004b00:	0589b783          	ld	a5,88(s3)
    80004b04:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004b08:	df843783          	ld	a5,-520(s0)
    80004b0c:	0007c703          	lbu	a4,0(a5)
    80004b10:	c315                	beqz	a4,80004b34 <kexec+0x2b4>
    80004b12:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004b14:	02f00693          	li	a3,47
    80004b18:	a809                	j	80004b2a <kexec+0x2aa>
  sp = sz;
    80004b1a:	e0843b83          	ld	s7,-504(s0)
  for (argc = 0; argv[argc]; argc++) {
    80004b1e:	4481                	li	s1,0
    80004b20:	b76d                	j	80004aca <kexec+0x24a>
  for (last = s = path; *s; s++)
    80004b22:	0785                	addi	a5,a5,1
    80004b24:	fff7c703          	lbu	a4,-1(a5)
    80004b28:	c711                	beqz	a4,80004b34 <kexec+0x2b4>
    if (*s == '/')
    80004b2a:	fed71ce3          	bne	a4,a3,80004b22 <kexec+0x2a2>
      last = s + 1;
    80004b2e:	def43c23          	sd	a5,-520(s0)
    80004b32:	bfc5                	j	80004b22 <kexec+0x2a2>
  safestrcpy(p->name, last, sizeof(p->name));
    80004b34:	4641                	li	a2,16
    80004b36:	df843583          	ld	a1,-520(s0)
    80004b3a:	15898513          	addi	a0,s3,344
    80004b3e:	a54fc0ef          	jal	80000d92 <safestrcpy>
  oldpagetable = p->pagetable;
    80004b42:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004b46:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004b4a:	e0843783          	ld	a5,-504(s0)
    80004b4e:	04f9b423          	sd	a5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004b52:	0589b783          	ld	a5,88(s3)
    80004b56:	e6843703          	ld	a4,-408(s0)
    80004b5a:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004b5c:	0589b783          	ld	a5,88(s3)
    80004b60:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004b64:	85d2                	mv	a1,s4
    80004b66:	ec3fc0ef          	jal	80001a28 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004b6a:	0004851b          	sext.w	a0,s1
    80004b6e:	79be                	ld	s3,488(sp)
    80004b70:	7a1e                	ld	s4,480(sp)
    80004b72:	6afe                	ld	s5,472(sp)
    80004b74:	6b5e                	ld	s6,464(sp)
    80004b76:	6bbe                	ld	s7,456(sp)
    80004b78:	6c1e                	ld	s8,448(sp)
    80004b7a:	7cfa                	ld	s9,440(sp)
    80004b7c:	7d5a                	ld	s10,432(sp)
    80004b7e:	bb85                	j	800048ee <kexec+0x6e>
    80004b80:	e1243423          	sd	s2,-504(s0)
    80004b84:	7dba                	ld	s11,424(sp)
    80004b86:	a035                	j	80004bb2 <kexec+0x332>
    80004b88:	e1243423          	sd	s2,-504(s0)
    80004b8c:	7dba                	ld	s11,424(sp)
    80004b8e:	a015                	j	80004bb2 <kexec+0x332>
    80004b90:	e1243423          	sd	s2,-504(s0)
    80004b94:	7dba                	ld	s11,424(sp)
    80004b96:	a831                	j	80004bb2 <kexec+0x332>
    80004b98:	e1243423          	sd	s2,-504(s0)
    80004b9c:	7dba                	ld	s11,424(sp)
    80004b9e:	a811                	j	80004bb2 <kexec+0x332>
    80004ba0:	e1243423          	sd	s2,-504(s0)
    80004ba4:	7dba                	ld	s11,424(sp)
    80004ba6:	a031                	j	80004bb2 <kexec+0x332>
  ip = 0;
    80004ba8:	4a01                	li	s4,0
    80004baa:	a021                	j	80004bb2 <kexec+0x332>
    80004bac:	4a01                	li	s4,0
  if (pagetable)
    80004bae:	a011                	j	80004bb2 <kexec+0x332>
    80004bb0:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004bb2:	e0843583          	ld	a1,-504(s0)
    80004bb6:	855a                	mv	a0,s6
    80004bb8:	e71fc0ef          	jal	80001a28 <proc_freepagetable>
  return -1;
    80004bbc:	557d                	li	a0,-1
  if (ip) {
    80004bbe:	000a1b63          	bnez	s4,80004bd4 <kexec+0x354>
    80004bc2:	79be                	ld	s3,488(sp)
    80004bc4:	7a1e                	ld	s4,480(sp)
    80004bc6:	6afe                	ld	s5,472(sp)
    80004bc8:	6b5e                	ld	s6,464(sp)
    80004bca:	6bbe                	ld	s7,456(sp)
    80004bcc:	6c1e                	ld	s8,448(sp)
    80004bce:	7cfa                	ld	s9,440(sp)
    80004bd0:	7d5a                	ld	s10,432(sp)
    80004bd2:	bb31                	j	800048ee <kexec+0x6e>
    80004bd4:	79be                	ld	s3,488(sp)
    80004bd6:	6afe                	ld	s5,472(sp)
    80004bd8:	6b5e                	ld	s6,464(sp)
    80004bda:	6bbe                	ld	s7,456(sp)
    80004bdc:	6c1e                	ld	s8,448(sp)
    80004bde:	7cfa                	ld	s9,440(sp)
    80004be0:	7d5a                	ld	s10,432(sp)
    80004be2:	b9fd                	j	800048e0 <kexec+0x60>
    80004be4:	6b5e                	ld	s6,464(sp)
    80004be6:	b9ed                	j	800048e0 <kexec+0x60>
  sz = sz1;
    80004be8:	e0843b83          	ld	s7,-504(s0)
    80004bec:	b59d                	j	80004a52 <kexec+0x1d2>

0000000080004bee <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004bee:	7179                	addi	sp,sp,-48
    80004bf0:	f406                	sd	ra,40(sp)
    80004bf2:	f022                	sd	s0,32(sp)
    80004bf4:	ec26                	sd	s1,24(sp)
    80004bf6:	e84a                	sd	s2,16(sp)
    80004bf8:	1800                	addi	s0,sp,48
    80004bfa:	892e                	mv	s2,a1
    80004bfc:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004bfe:	fdc40593          	addi	a1,s0,-36
    80004c02:	ce1fd0ef          	jal	800028e2 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004c06:	fdc42703          	lw	a4,-36(s0)
    80004c0a:	47bd                	li	a5,15
    80004c0c:	02e7e963          	bltu	a5,a4,80004c3e <argfd+0x50>
    80004c10:	c93fc0ef          	jal	800018a2 <myproc>
    80004c14:	fdc42703          	lw	a4,-36(s0)
    80004c18:	01a70793          	addi	a5,a4,26
    80004c1c:	078e                	slli	a5,a5,0x3
    80004c1e:	953e                	add	a0,a0,a5
    80004c20:	611c                	ld	a5,0(a0)
    80004c22:	c385                	beqz	a5,80004c42 <argfd+0x54>
    return -1;
  if (pfd)
    80004c24:	00090463          	beqz	s2,80004c2c <argfd+0x3e>
    *pfd = fd;
    80004c28:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    80004c2c:	4501                	li	a0,0
  if (pf)
    80004c2e:	c091                	beqz	s1,80004c32 <argfd+0x44>
    *pf = f;
    80004c30:	e09c                	sd	a5,0(s1)
}
    80004c32:	70a2                	ld	ra,40(sp)
    80004c34:	7402                	ld	s0,32(sp)
    80004c36:	64e2                	ld	s1,24(sp)
    80004c38:	6942                	ld	s2,16(sp)
    80004c3a:	6145                	addi	sp,sp,48
    80004c3c:	8082                	ret
    return -1;
    80004c3e:	557d                	li	a0,-1
    80004c40:	bfcd                	j	80004c32 <argfd+0x44>
    80004c42:	557d                	li	a0,-1
    80004c44:	b7fd                	j	80004c32 <argfd+0x44>

0000000080004c46 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004c46:	1101                	addi	sp,sp,-32
    80004c48:	ec06                	sd	ra,24(sp)
    80004c4a:	e822                	sd	s0,16(sp)
    80004c4c:	e426                	sd	s1,8(sp)
    80004c4e:	1000                	addi	s0,sp,32
    80004c50:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004c52:	c51fc0ef          	jal	800018a2 <myproc>
    80004c56:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004c58:	0d050793          	addi	a5,a0,208
    80004c5c:	4501                	li	a0,0
    80004c5e:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004c60:	6398                	ld	a4,0(a5)
    80004c62:	cb19                	beqz	a4,80004c78 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004c64:	2505                	addiw	a0,a0,1
    80004c66:	07a1                	addi	a5,a5,8
    80004c68:	fed51ce3          	bne	a0,a3,80004c60 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004c6c:	557d                	li	a0,-1
}
    80004c6e:	60e2                	ld	ra,24(sp)
    80004c70:	6442                	ld	s0,16(sp)
    80004c72:	64a2                	ld	s1,8(sp)
    80004c74:	6105                	addi	sp,sp,32
    80004c76:	8082                	ret
      p->ofile[fd] = f;
    80004c78:	01a50793          	addi	a5,a0,26
    80004c7c:	078e                	slli	a5,a5,0x3
    80004c7e:	963e                	add	a2,a2,a5
    80004c80:	e204                	sd	s1,0(a2)
      return fd;
    80004c82:	b7f5                	j	80004c6e <fdalloc+0x28>

0000000080004c84 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004c84:	715d                	addi	sp,sp,-80
    80004c86:	e486                	sd	ra,72(sp)
    80004c88:	e0a2                	sd	s0,64(sp)
    80004c8a:	fc26                	sd	s1,56(sp)
    80004c8c:	f84a                	sd	s2,48(sp)
    80004c8e:	f44e                	sd	s3,40(sp)
    80004c90:	f052                	sd	s4,32(sp)
    80004c92:	ec56                	sd	s5,24(sp)
    80004c94:	0880                	addi	s0,sp,80
    80004c96:	892e                	mv	s2,a1
    80004c98:	89b2                	mv	s3,a2
    80004c9a:	8a36                	mv	s4,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004c9c:	fb040593          	addi	a1,s0,-80
    80004ca0:	f2bfe0ef          	jal	80003bca <nameiparent>
    80004ca4:	8aaa                	mv	s5,a0
    80004ca6:	cd45                	beqz	a0,80004d5e <create+0xda>
    return 0;

  ilock(dp);
    80004ca8:	e94fe0ef          	jal	8000333c <ilock>

  if (dp->nlink == 0) {
    80004cac:	04aa9783          	lh	a5,74(s5) # fffffffffffff04a <end+0xffffffff7ffdb62a>
    80004cb0:	cf8d                	beqz	a5,80004cea <create+0x66>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004cb2:	4705                	li	a4,1
    80004cb4:	04e91563          	bne	s2,a4,80004cfe <create+0x7a>
    80004cb8:	6721                	lui	a4,0x8
    80004cba:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004cbc:	02e78c63          	beq	a5,a4,80004cf4 <create+0x70>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004cc0:	4601                	li	a2,0
    80004cc2:	fb040593          	addi	a1,s0,-80
    80004cc6:	8556                	mv	a0,s5
    80004cc8:	c73fe0ef          	jal	8000393a <dirlookup>
    80004ccc:	84aa                	mv	s1,a0
    80004cce:	e951                	bnez	a0,80004d62 <create+0xde>
      return ip;
    iunlockput(ip);
    return 0;
  }

  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004cd0:	85ca                	mv	a1,s2
    80004cd2:	000aa503          	lw	a0,0(s5)
    80004cd6:	cf6fe0ef          	jal	800031cc <ialloc>
    80004cda:	84aa                	mv	s1,a0
    80004cdc:	0c051e63          	bnez	a0,80004db8 <create+0x134>
    iunlockput(dp);
    80004ce0:	8556                	mv	a0,s5
    80004ce2:	8adfe0ef          	jal	8000358e <iunlockput>
    return 0;
    80004ce6:	4481                	li	s1,0
    80004ce8:	a0a1                	j	80004d30 <create+0xac>
    iunlockput(dp);
    80004cea:	8556                	mv	a0,s5
    80004cec:	8a3fe0ef          	jal	8000358e <iunlockput>
    return 0;
    80004cf0:	4481                	li	s1,0
    80004cf2:	a83d                	j	80004d30 <create+0xac>
    iunlockput(dp);
    80004cf4:	8556                	mv	a0,s5
    80004cf6:	899fe0ef          	jal	8000358e <iunlockput>
    return 0;
    80004cfa:	4481                	li	s1,0
    80004cfc:	a815                	j	80004d30 <create+0xac>
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004cfe:	4601                	li	a2,0
    80004d00:	fb040593          	addi	a1,s0,-80
    80004d04:	8556                	mv	a0,s5
    80004d06:	c35fe0ef          	jal	8000393a <dirlookup>
    80004d0a:	84aa                	mv	s1,a0
    80004d0c:	c535                	beqz	a0,80004d78 <create+0xf4>
    iunlockput(dp);
    80004d0e:	8556                	mv	a0,s5
    80004d10:	87ffe0ef          	jal	8000358e <iunlockput>
    ilock(ip);
    80004d14:	8526                	mv	a0,s1
    80004d16:	e26fe0ef          	jal	8000333c <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004d1a:	4789                	li	a5,2
    80004d1c:	04f91963          	bne	s2,a5,80004d6e <create+0xea>
    80004d20:	0444d783          	lhu	a5,68(s1)
    80004d24:	37f9                	addiw	a5,a5,-2
    80004d26:	17c2                	slli	a5,a5,0x30
    80004d28:	93c1                	srli	a5,a5,0x30
    80004d2a:	4705                	li	a4,1
    80004d2c:	04f76163          	bltu	a4,a5,80004d6e <create+0xea>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d30:	8526                	mv	a0,s1
    80004d32:	60a6                	ld	ra,72(sp)
    80004d34:	6406                	ld	s0,64(sp)
    80004d36:	74e2                	ld	s1,56(sp)
    80004d38:	7942                	ld	s2,48(sp)
    80004d3a:	79a2                	ld	s3,40(sp)
    80004d3c:	7a02                	ld	s4,32(sp)
    80004d3e:	6ae2                	ld	s5,24(sp)
    80004d40:	6161                	addi	sp,sp,80
    80004d42:	8082                	ret
  ip->nlink = 0;
    80004d44:	04049523          	sh	zero,74(s1)
  iupdate(ip);
    80004d48:	8526                	mv	a0,s1
    80004d4a:	d3efe0ef          	jal	80003288 <iupdate>
  iunlockput(ip);
    80004d4e:	8526                	mv	a0,s1
    80004d50:	83ffe0ef          	jal	8000358e <iunlockput>
  iunlockput(dp);
    80004d54:	8556                	mv	a0,s5
    80004d56:	839fe0ef          	jal	8000358e <iunlockput>
  return 0;
    80004d5a:	4481                	li	s1,0
    80004d5c:	bfd1                	j	80004d30 <create+0xac>
    return 0;
    80004d5e:	84aa                	mv	s1,a0
    80004d60:	bfc1                	j	80004d30 <create+0xac>
    iunlockput(dp);
    80004d62:	8556                	mv	a0,s5
    80004d64:	82bfe0ef          	jal	8000358e <iunlockput>
    ilock(ip);
    80004d68:	8526                	mv	a0,s1
    80004d6a:	dd2fe0ef          	jal	8000333c <ilock>
    iunlockput(ip);
    80004d6e:	8526                	mv	a0,s1
    80004d70:	81ffe0ef          	jal	8000358e <iunlockput>
    return 0;
    80004d74:	4481                	li	s1,0
    80004d76:	bf6d                	j	80004d30 <create+0xac>
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004d78:	85ca                	mv	a1,s2
    80004d7a:	000aa503          	lw	a0,0(s5)
    80004d7e:	c4efe0ef          	jal	800031cc <ialloc>
    80004d82:	84aa                	mv	s1,a0
    80004d84:	dd31                	beqz	a0,80004ce0 <create+0x5c>
  ilock(ip);
    80004d86:	8526                	mv	a0,s1
    80004d88:	db4fe0ef          	jal	8000333c <ilock>
  ip->major = major;
    80004d8c:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004d90:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004d94:	4785                	li	a5,1
    80004d96:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004d9a:	8526                	mv	a0,s1
    80004d9c:	cecfe0ef          	jal	80003288 <iupdate>
  if (dirlink(dp, name, ip->inum) < 0)
    80004da0:	40d0                	lw	a2,4(s1)
    80004da2:	fb040593          	addi	a1,s0,-80
    80004da6:	8556                	mv	a0,s5
    80004da8:	d6ffe0ef          	jal	80003b16 <dirlink>
    80004dac:	f8054ce3          	bltz	a0,80004d44 <create+0xc0>
  iunlockput(dp);
    80004db0:	8556                	mv	a0,s5
    80004db2:	fdcfe0ef          	jal	8000358e <iunlockput>
  return ip;
    80004db6:	bfad                	j	80004d30 <create+0xac>
  ilock(ip);
    80004db8:	8526                	mv	a0,s1
    80004dba:	d82fe0ef          	jal	8000333c <ilock>
  ip->major = major;
    80004dbe:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004dc2:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004dc6:	4785                	li	a5,1
    80004dc8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004dcc:	8526                	mv	a0,s1
    80004dce:	cbafe0ef          	jal	80003288 <iupdate>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004dd2:	40d0                	lw	a2,4(s1)
    80004dd4:	00003597          	auipc	a1,0x3
    80004dd8:	81458593          	addi	a1,a1,-2028 # 800075e8 <etext+0x5e8>
    80004ddc:	8526                	mv	a0,s1
    80004dde:	d39fe0ef          	jal	80003b16 <dirlink>
    80004de2:	f60541e3          	bltz	a0,80004d44 <create+0xc0>
    80004de6:	004aa603          	lw	a2,4(s5)
    80004dea:	00002597          	auipc	a1,0x2
    80004dee:	7f658593          	addi	a1,a1,2038 # 800075e0 <etext+0x5e0>
    80004df2:	8526                	mv	a0,s1
    80004df4:	d23fe0ef          	jal	80003b16 <dirlink>
    80004df8:	f40546e3          	bltz	a0,80004d44 <create+0xc0>
  if (dirlink(dp, name, ip->inum) < 0)
    80004dfc:	40d0                	lw	a2,4(s1)
    80004dfe:	fb040593          	addi	a1,s0,-80
    80004e02:	8556                	mv	a0,s5
    80004e04:	d13fe0ef          	jal	80003b16 <dirlink>
    80004e08:	f2054ee3          	bltz	a0,80004d44 <create+0xc0>
    dp->nlink++; // for ".."
    80004e0c:	04aad783          	lhu	a5,74(s5)
    80004e10:	2785                	addiw	a5,a5,1
    80004e12:	04fa9523          	sh	a5,74(s5)
    iupdate(dp);
    80004e16:	8556                	mv	a0,s5
    80004e18:	c70fe0ef          	jal	80003288 <iupdate>
    80004e1c:	bf51                	j	80004db0 <create+0x12c>

0000000080004e1e <sys_dup>:
{
    80004e1e:	7179                	addi	sp,sp,-48
    80004e20:	f406                	sd	ra,40(sp)
    80004e22:	f022                	sd	s0,32(sp)
    80004e24:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004e26:	fd840613          	addi	a2,s0,-40
    80004e2a:	4581                	li	a1,0
    80004e2c:	4501                	li	a0,0
    80004e2e:	dc1ff0ef          	jal	80004bee <argfd>
    return -1;
    80004e32:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80004e34:	02054363          	bltz	a0,80004e5a <sys_dup+0x3c>
    80004e38:	ec26                	sd	s1,24(sp)
    80004e3a:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004e3c:	fd843903          	ld	s2,-40(s0)
    80004e40:	854a                	mv	a0,s2
    80004e42:	e05ff0ef          	jal	80004c46 <fdalloc>
    80004e46:	84aa                	mv	s1,a0
    return -1;
    80004e48:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80004e4a:	00054d63          	bltz	a0,80004e64 <sys_dup+0x46>
  filedup(f);
    80004e4e:	854a                	mv	a0,s2
    80004e50:	b9aff0ef          	jal	800041ea <filedup>
  return fd;
    80004e54:	87a6                	mv	a5,s1
    80004e56:	64e2                	ld	s1,24(sp)
    80004e58:	6942                	ld	s2,16(sp)
}
    80004e5a:	853e                	mv	a0,a5
    80004e5c:	70a2                	ld	ra,40(sp)
    80004e5e:	7402                	ld	s0,32(sp)
    80004e60:	6145                	addi	sp,sp,48
    80004e62:	8082                	ret
    80004e64:	64e2                	ld	s1,24(sp)
    80004e66:	6942                	ld	s2,16(sp)
    80004e68:	bfcd                	j	80004e5a <sys_dup+0x3c>

0000000080004e6a <sys_read>:
{
    80004e6a:	7179                	addi	sp,sp,-48
    80004e6c:	f406                	sd	ra,40(sp)
    80004e6e:	f022                	sd	s0,32(sp)
    80004e70:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e72:	fd840593          	addi	a1,s0,-40
    80004e76:	4505                	li	a0,1
    80004e78:	a87fd0ef          	jal	800028fe <argaddr>
  argint(2, &n);
    80004e7c:	fe440593          	addi	a1,s0,-28
    80004e80:	4509                	li	a0,2
    80004e82:	a61fd0ef          	jal	800028e2 <argint>
  if (argfd(0, 0, &f) < 0)
    80004e86:	fe840613          	addi	a2,s0,-24
    80004e8a:	4581                	li	a1,0
    80004e8c:	4501                	li	a0,0
    80004e8e:	d61ff0ef          	jal	80004bee <argfd>
    80004e92:	87aa                	mv	a5,a0
    return -1;
    80004e94:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e96:	0007ca63          	bltz	a5,80004eaa <sys_read+0x40>
  return fileread(f, p, n);
    80004e9a:	fe442603          	lw	a2,-28(s0)
    80004e9e:	fd843583          	ld	a1,-40(s0)
    80004ea2:	fe843503          	ld	a0,-24(s0)
    80004ea6:	caeff0ef          	jal	80004354 <fileread>
}
    80004eaa:	70a2                	ld	ra,40(sp)
    80004eac:	7402                	ld	s0,32(sp)
    80004eae:	6145                	addi	sp,sp,48
    80004eb0:	8082                	ret

0000000080004eb2 <sys_write>:
{
    80004eb2:	7179                	addi	sp,sp,-48
    80004eb4:	f406                	sd	ra,40(sp)
    80004eb6:	f022                	sd	s0,32(sp)
    80004eb8:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004eba:	fd840593          	addi	a1,s0,-40
    80004ebe:	4505                	li	a0,1
    80004ec0:	a3ffd0ef          	jal	800028fe <argaddr>
  argint(2, &n);
    80004ec4:	fe440593          	addi	a1,s0,-28
    80004ec8:	4509                	li	a0,2
    80004eca:	a19fd0ef          	jal	800028e2 <argint>
  if (argfd(0, 0, &f) < 0)
    80004ece:	fe840613          	addi	a2,s0,-24
    80004ed2:	4581                	li	a1,0
    80004ed4:	4501                	li	a0,0
    80004ed6:	d19ff0ef          	jal	80004bee <argfd>
    80004eda:	87aa                	mv	a5,a0
    return -1;
    80004edc:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004ede:	0007ca63          	bltz	a5,80004ef2 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ee2:	fe442603          	lw	a2,-28(s0)
    80004ee6:	fd843583          	ld	a1,-40(s0)
    80004eea:	fe843503          	ld	a0,-24(s0)
    80004eee:	d30ff0ef          	jal	8000441e <filewrite>
}
    80004ef2:	70a2                	ld	ra,40(sp)
    80004ef4:	7402                	ld	s0,32(sp)
    80004ef6:	6145                	addi	sp,sp,48
    80004ef8:	8082                	ret

0000000080004efa <sys_close>:
{
    80004efa:	1101                	addi	sp,sp,-32
    80004efc:	ec06                	sd	ra,24(sp)
    80004efe:	e822                	sd	s0,16(sp)
    80004f00:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004f02:	fe040613          	addi	a2,s0,-32
    80004f06:	fec40593          	addi	a1,s0,-20
    80004f0a:	4501                	li	a0,0
    80004f0c:	ce3ff0ef          	jal	80004bee <argfd>
    return -1;
    80004f10:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004f12:	02054063          	bltz	a0,80004f32 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004f16:	98dfc0ef          	jal	800018a2 <myproc>
    80004f1a:	fec42783          	lw	a5,-20(s0)
    80004f1e:	07e9                	addi	a5,a5,26
    80004f20:	078e                	slli	a5,a5,0x3
    80004f22:	953e                	add	a0,a0,a5
    80004f24:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004f28:	fe043503          	ld	a0,-32(s0)
    80004f2c:	b04ff0ef          	jal	80004230 <fileclose>
  return 0;
    80004f30:	4781                	li	a5,0
}
    80004f32:	853e                	mv	a0,a5
    80004f34:	60e2                	ld	ra,24(sp)
    80004f36:	6442                	ld	s0,16(sp)
    80004f38:	6105                	addi	sp,sp,32
    80004f3a:	8082                	ret

0000000080004f3c <sys_fstat>:
{
    80004f3c:	1101                	addi	sp,sp,-32
    80004f3e:	ec06                	sd	ra,24(sp)
    80004f40:	e822                	sd	s0,16(sp)
    80004f42:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f44:	fe040593          	addi	a1,s0,-32
    80004f48:	4505                	li	a0,1
    80004f4a:	9b5fd0ef          	jal	800028fe <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004f4e:	fe840613          	addi	a2,s0,-24
    80004f52:	4581                	li	a1,0
    80004f54:	4501                	li	a0,0
    80004f56:	c99ff0ef          	jal	80004bee <argfd>
    80004f5a:	87aa                	mv	a5,a0
    return -1;
    80004f5c:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004f5e:	0007c863          	bltz	a5,80004f6e <sys_fstat+0x32>
  return filestat(f, st);
    80004f62:	fe043583          	ld	a1,-32(s0)
    80004f66:	fe843503          	ld	a0,-24(s0)
    80004f6a:	b88ff0ef          	jal	800042f2 <filestat>
}
    80004f6e:	60e2                	ld	ra,24(sp)
    80004f70:	6442                	ld	s0,16(sp)
    80004f72:	6105                	addi	sp,sp,32
    80004f74:	8082                	ret

0000000080004f76 <sys_link>:
{
    80004f76:	7169                	addi	sp,sp,-304
    80004f78:	f606                	sd	ra,296(sp)
    80004f7a:	f222                	sd	s0,288(sp)
    80004f7c:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f7e:	08000613          	li	a2,128
    80004f82:	ed040593          	addi	a1,s0,-304
    80004f86:	4501                	li	a0,0
    80004f88:	993fd0ef          	jal	8000291a <argstr>
    return -1;
    80004f8c:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f8e:	10054163          	bltz	a0,80005090 <sys_link+0x11a>
    80004f92:	08000613          	li	a2,128
    80004f96:	f5040593          	addi	a1,s0,-176
    80004f9a:	4505                	li	a0,1
    80004f9c:	97ffd0ef          	jal	8000291a <argstr>
    return -1;
    80004fa0:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004fa2:	0e054763          	bltz	a0,80005090 <sys_link+0x11a>
    80004fa6:	ee26                	sd	s1,280(sp)
  begin_op();
    80004fa8:	dddfe0ef          	jal	80003d84 <begin_op>
  if ((ip = namei(old)) == 0) {
    80004fac:	ed040513          	addi	a0,s0,-304
    80004fb0:	c01fe0ef          	jal	80003bb0 <namei>
    80004fb4:	84aa                	mv	s1,a0
    80004fb6:	cd35                	beqz	a0,80005032 <sys_link+0xbc>
  ilock(ip);
    80004fb8:	b84fe0ef          	jal	8000333c <ilock>
  if (ip->type == T_DIR) {
    80004fbc:	04449703          	lh	a4,68(s1)
    80004fc0:	4785                	li	a5,1
    80004fc2:	06f70d63          	beq	a4,a5,8000503c <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    80004fc6:	04a49783          	lh	a5,74(s1)
    80004fca:	6721                	lui	a4,0x8
    80004fcc:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004fce:	06e78f63          	beq	a5,a4,8000504c <sys_link+0xd6>
    80004fd2:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fd4:	2785                	addiw	a5,a5,1
    80004fd6:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fda:	8526                	mv	a0,s1
    80004fdc:	aacfe0ef          	jal	80003288 <iupdate>
  iunlock(ip);
    80004fe0:	8526                	mv	a0,s1
    80004fe2:	c08fe0ef          	jal	800033ea <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80004fe6:	fd040593          	addi	a1,s0,-48
    80004fea:	f5040513          	addi	a0,s0,-176
    80004fee:	bddfe0ef          	jal	80003bca <nameiparent>
    80004ff2:	892a                	mv	s2,a0
    80004ff4:	c93d                	beqz	a0,8000506a <sys_link+0xf4>
  ilock(dp);
    80004ff6:	b46fe0ef          	jal	8000333c <ilock>
  if (dp->nlink == 0) {
    80004ffa:	04a91783          	lh	a5,74(s2)
    80004ffe:	cfb9                	beqz	a5,8000505c <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80005000:	00092703          	lw	a4,0(s2)
    80005004:	409c                	lw	a5,0(s1)
    80005006:	04f71f63          	bne	a4,a5,80005064 <sys_link+0xee>
    8000500a:	40d0                	lw	a2,4(s1)
    8000500c:	fd040593          	addi	a1,s0,-48
    80005010:	854a                	mv	a0,s2
    80005012:	b05fe0ef          	jal	80003b16 <dirlink>
    80005016:	04054763          	bltz	a0,80005064 <sys_link+0xee>
  iunlockput(dp);
    8000501a:	854a                	mv	a0,s2
    8000501c:	d72fe0ef          	jal	8000358e <iunlockput>
  iput(ip);
    80005020:	8526                	mv	a0,s1
    80005022:	c9cfe0ef          	jal	800034be <iput>
  end_op();
    80005026:	de5fe0ef          	jal	80003e0a <end_op>
  return 0;
    8000502a:	4781                	li	a5,0
    8000502c:	64f2                	ld	s1,280(sp)
    8000502e:	6952                	ld	s2,272(sp)
    80005030:	a085                	j	80005090 <sys_link+0x11a>
    end_op();
    80005032:	dd9fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005036:	57fd                	li	a5,-1
    80005038:	64f2                	ld	s1,280(sp)
    8000503a:	a899                	j	80005090 <sys_link+0x11a>
    iunlockput(ip);
    8000503c:	8526                	mv	a0,s1
    8000503e:	d50fe0ef          	jal	8000358e <iunlockput>
    end_op();
    80005042:	dc9fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005046:	57fd                	li	a5,-1
    80005048:	64f2                	ld	s1,280(sp)
    8000504a:	a099                	j	80005090 <sys_link+0x11a>
    iunlockput(ip);
    8000504c:	8526                	mv	a0,s1
    8000504e:	d40fe0ef          	jal	8000358e <iunlockput>
    end_op();
    80005052:	db9fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005056:	57fd                	li	a5,-1
    80005058:	64f2                	ld	s1,280(sp)
    8000505a:	a81d                	j	80005090 <sys_link+0x11a>
    iunlockput(dp);
    8000505c:	854a                	mv	a0,s2
    8000505e:	d30fe0ef          	jal	8000358e <iunlockput>
    goto bad;
    80005062:	a021                	j	8000506a <sys_link+0xf4>
    iunlockput(dp);
    80005064:	854a                	mv	a0,s2
    80005066:	d28fe0ef          	jal	8000358e <iunlockput>
  ilock(ip);
    8000506a:	8526                	mv	a0,s1
    8000506c:	ad0fe0ef          	jal	8000333c <ilock>
  ip->nlink--;
    80005070:	04a4d783          	lhu	a5,74(s1)
    80005074:	37fd                	addiw	a5,a5,-1
    80005076:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000507a:	8526                	mv	a0,s1
    8000507c:	a0cfe0ef          	jal	80003288 <iupdate>
  iunlockput(ip);
    80005080:	8526                	mv	a0,s1
    80005082:	d0cfe0ef          	jal	8000358e <iunlockput>
  end_op();
    80005086:	d85fe0ef          	jal	80003e0a <end_op>
  return -1;
    8000508a:	57fd                	li	a5,-1
    8000508c:	64f2                	ld	s1,280(sp)
    8000508e:	6952                	ld	s2,272(sp)
}
    80005090:	853e                	mv	a0,a5
    80005092:	70b2                	ld	ra,296(sp)
    80005094:	7412                	ld	s0,288(sp)
    80005096:	6155                	addi	sp,sp,304
    80005098:	8082                	ret

000000008000509a <sys_unlink>:
{
    8000509a:	7151                	addi	sp,sp,-240
    8000509c:	f586                	sd	ra,232(sp)
    8000509e:	f1a2                	sd	s0,224(sp)
    800050a0:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    800050a2:	08000613          	li	a2,128
    800050a6:	f3040593          	addi	a1,s0,-208
    800050aa:	4501                	li	a0,0
    800050ac:	86ffd0ef          	jal	8000291a <argstr>
    800050b0:	16054063          	bltz	a0,80005210 <sys_unlink+0x176>
    800050b4:	eda6                	sd	s1,216(sp)
  begin_op();
    800050b6:	ccffe0ef          	jal	80003d84 <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    800050ba:	fb040593          	addi	a1,s0,-80
    800050be:	f3040513          	addi	a0,s0,-208
    800050c2:	b09fe0ef          	jal	80003bca <nameiparent>
    800050c6:	84aa                	mv	s1,a0
    800050c8:	c945                	beqz	a0,80005178 <sys_unlink+0xde>
  ilock(dp);
    800050ca:	a72fe0ef          	jal	8000333c <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800050ce:	00002597          	auipc	a1,0x2
    800050d2:	51a58593          	addi	a1,a1,1306 # 800075e8 <etext+0x5e8>
    800050d6:	fb040513          	addi	a0,s0,-80
    800050da:	84bfe0ef          	jal	80003924 <namecmp>
    800050de:	10050e63          	beqz	a0,800051fa <sys_unlink+0x160>
    800050e2:	00002597          	auipc	a1,0x2
    800050e6:	4fe58593          	addi	a1,a1,1278 # 800075e0 <etext+0x5e0>
    800050ea:	fb040513          	addi	a0,s0,-80
    800050ee:	837fe0ef          	jal	80003924 <namecmp>
    800050f2:	10050463          	beqz	a0,800051fa <sys_unlink+0x160>
    800050f6:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    800050f8:	f2c40613          	addi	a2,s0,-212
    800050fc:	fb040593          	addi	a1,s0,-80
    80005100:	8526                	mv	a0,s1
    80005102:	839fe0ef          	jal	8000393a <dirlookup>
    80005106:	892a                	mv	s2,a0
    80005108:	0e050863          	beqz	a0,800051f8 <sys_unlink+0x15e>
  ilock(ip);
    8000510c:	a30fe0ef          	jal	8000333c <ilock>
  if (ip->nlink < 1)
    80005110:	04a91783          	lh	a5,74(s2)
    80005114:	06f05763          	blez	a5,80005182 <sys_unlink+0xe8>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    80005118:	04491703          	lh	a4,68(s2)
    8000511c:	4785                	li	a5,1
    8000511e:	06f70963          	beq	a4,a5,80005190 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80005122:	4641                	li	a2,16
    80005124:	4581                	li	a1,0
    80005126:	fc040513          	addi	a0,s0,-64
    8000512a:	b2bfb0ef          	jal	80000c54 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000512e:	4741                	li	a4,16
    80005130:	f2c42683          	lw	a3,-212(s0)
    80005134:	fc040613          	addi	a2,s0,-64
    80005138:	4581                	li	a1,0
    8000513a:	8526                	mv	a0,s1
    8000513c:	ed4fe0ef          	jal	80003810 <writei>
    80005140:	47c1                	li	a5,16
    80005142:	08f51b63          	bne	a0,a5,800051d8 <sys_unlink+0x13e>
  if (ip->type == T_DIR) {
    80005146:	04491703          	lh	a4,68(s2)
    8000514a:	4785                	li	a5,1
    8000514c:	08f70d63          	beq	a4,a5,800051e6 <sys_unlink+0x14c>
  iunlockput(dp);
    80005150:	8526                	mv	a0,s1
    80005152:	c3cfe0ef          	jal	8000358e <iunlockput>
  ip->nlink--;
    80005156:	04a95783          	lhu	a5,74(s2)
    8000515a:	37fd                	addiw	a5,a5,-1
    8000515c:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005160:	854a                	mv	a0,s2
    80005162:	926fe0ef          	jal	80003288 <iupdate>
  iunlockput(ip);
    80005166:	854a                	mv	a0,s2
    80005168:	c26fe0ef          	jal	8000358e <iunlockput>
  end_op();
    8000516c:	c9ffe0ef          	jal	80003e0a <end_op>
  return 0;
    80005170:	4501                	li	a0,0
    80005172:	64ee                	ld	s1,216(sp)
    80005174:	694e                	ld	s2,208(sp)
    80005176:	a849                	j	80005208 <sys_unlink+0x16e>
    end_op();
    80005178:	c93fe0ef          	jal	80003e0a <end_op>
    return -1;
    8000517c:	557d                	li	a0,-1
    8000517e:	64ee                	ld	s1,216(sp)
    80005180:	a061                	j	80005208 <sys_unlink+0x16e>
    80005182:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005184:	00002517          	auipc	a0,0x2
    80005188:	46c50513          	addi	a0,a0,1132 # 800075f0 <etext+0x5f0>
    8000518c:	e64fb0ef          	jal	800007f0 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005190:	04c92703          	lw	a4,76(s2)
    80005194:	02000793          	li	a5,32
    80005198:	f8e7f5e3          	bgeu	a5,a4,80005122 <sys_unlink+0x88>
    8000519c:	e5ce                	sd	s3,200(sp)
    8000519e:	02000993          	li	s3,32
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800051a2:	4741                	li	a4,16
    800051a4:	86ce                	mv	a3,s3
    800051a6:	f1840613          	addi	a2,s0,-232
    800051aa:	4581                	li	a1,0
    800051ac:	854a                	mv	a0,s2
    800051ae:	d66fe0ef          	jal	80003714 <readi>
    800051b2:	47c1                	li	a5,16
    800051b4:	00f51c63          	bne	a0,a5,800051cc <sys_unlink+0x132>
    if (de.inum != 0)
    800051b8:	f1845783          	lhu	a5,-232(s0)
    800051bc:	efa1                	bnez	a5,80005214 <sys_unlink+0x17a>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800051be:	29c1                	addiw	s3,s3,16
    800051c0:	04c92783          	lw	a5,76(s2)
    800051c4:	fcf9efe3          	bltu	s3,a5,800051a2 <sys_unlink+0x108>
    800051c8:	69ae                	ld	s3,200(sp)
    800051ca:	bfa1                	j	80005122 <sys_unlink+0x88>
      panic("isdirempty: readi");
    800051cc:	00002517          	auipc	a0,0x2
    800051d0:	43c50513          	addi	a0,a0,1084 # 80007608 <etext+0x608>
    800051d4:	e1cfb0ef          	jal	800007f0 <panic>
    800051d8:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    800051da:	00002517          	auipc	a0,0x2
    800051de:	44650513          	addi	a0,a0,1094 # 80007620 <etext+0x620>
    800051e2:	e0efb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    800051e6:	04a4d783          	lhu	a5,74(s1)
    800051ea:	37fd                	addiw	a5,a5,-1
    800051ec:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051f0:	8526                	mv	a0,s1
    800051f2:	896fe0ef          	jal	80003288 <iupdate>
    800051f6:	bfa9                	j	80005150 <sys_unlink+0xb6>
    800051f8:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051fa:	8526                	mv	a0,s1
    800051fc:	b92fe0ef          	jal	8000358e <iunlockput>
  end_op();
    80005200:	c0bfe0ef          	jal	80003e0a <end_op>
  return -1;
    80005204:	557d                	li	a0,-1
    80005206:	64ee                	ld	s1,216(sp)
}
    80005208:	70ae                	ld	ra,232(sp)
    8000520a:	740e                	ld	s0,224(sp)
    8000520c:	616d                	addi	sp,sp,240
    8000520e:	8082                	ret
    return -1;
    80005210:	557d                	li	a0,-1
    80005212:	bfdd                	j	80005208 <sys_unlink+0x16e>
    iunlockput(ip);
    80005214:	854a                	mv	a0,s2
    80005216:	b78fe0ef          	jal	8000358e <iunlockput>
    goto bad;
    8000521a:	694e                	ld	s2,208(sp)
    8000521c:	69ae                	ld	s3,200(sp)
    8000521e:	bff1                	j	800051fa <sys_unlink+0x160>

0000000080005220 <sys_open>:

uint64
sys_open(void)
{
    80005220:	7131                	addi	sp,sp,-192
    80005222:	fd06                	sd	ra,184(sp)
    80005224:	f922                	sd	s0,176(sp)
    80005226:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005228:	f4c40593          	addi	a1,s0,-180
    8000522c:	4505                	li	a0,1
    8000522e:	eb4fd0ef          	jal	800028e2 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005232:	08000613          	li	a2,128
    80005236:	f5040593          	addi	a1,s0,-176
    8000523a:	4501                	li	a0,0
    8000523c:	edefd0ef          	jal	8000291a <argstr>
    80005240:	87aa                	mv	a5,a0
    return -1;
    80005242:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005244:	0a07c263          	bltz	a5,800052e8 <sys_open+0xc8>
    80005248:	f526                	sd	s1,168(sp)

  begin_op();
    8000524a:	b3bfe0ef          	jal	80003d84 <begin_op>

  if (omode & O_CREATE) {
    8000524e:	f4c42783          	lw	a5,-180(s0)
    80005252:	2007f793          	andi	a5,a5,512
    80005256:	c3d5                	beqz	a5,800052fa <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80005258:	4681                	li	a3,0
    8000525a:	4601                	li	a2,0
    8000525c:	4589                	li	a1,2
    8000525e:	f5040513          	addi	a0,s0,-176
    80005262:	a23ff0ef          	jal	80004c84 <create>
    80005266:	84aa                	mv	s1,a0
    if (ip == 0) {
    80005268:	c541                	beqz	a0,800052f0 <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    8000526a:	04449703          	lh	a4,68(s1)
    8000526e:	478d                	li	a5,3
    80005270:	00f71763          	bne	a4,a5,8000527e <sys_open+0x5e>
    80005274:	0464d703          	lhu	a4,70(s1)
    80005278:	47a5                	li	a5,9
    8000527a:	0ae7ed63          	bltu	a5,a4,80005334 <sys_open+0x114>
    8000527e:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    80005280:	f0dfe0ef          	jal	8000418c <filealloc>
    80005284:	892a                	mv	s2,a0
    80005286:	c179                	beqz	a0,8000534c <sys_open+0x12c>
    80005288:	ed4e                	sd	s3,152(sp)
    8000528a:	9bdff0ef          	jal	80004c46 <fdalloc>
    8000528e:	89aa                	mv	s3,a0
    80005290:	0a054a63          	bltz	a0,80005344 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    80005294:	04449703          	lh	a4,68(s1)
    80005298:	478d                	li	a5,3
    8000529a:	0cf70263          	beq	a4,a5,8000535e <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000529e:	4789                	li	a5,2
    800052a0:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800052a4:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800052a8:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800052ac:	f4c42783          	lw	a5,-180(s0)
    800052b0:	0017c713          	xori	a4,a5,1
    800052b4:	8b05                	andi	a4,a4,1
    800052b6:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800052ba:	0037f713          	andi	a4,a5,3
    800052be:	00e03733          	snez	a4,a4
    800052c2:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    800052c6:	4007f793          	andi	a5,a5,1024
    800052ca:	c791                	beqz	a5,800052d6 <sys_open+0xb6>
    800052cc:	04449703          	lh	a4,68(s1)
    800052d0:	4789                	li	a5,2
    800052d2:	08f70d63          	beq	a4,a5,8000536c <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    800052d6:	8526                	mv	a0,s1
    800052d8:	912fe0ef          	jal	800033ea <iunlock>
  end_op();
    800052dc:	b2ffe0ef          	jal	80003e0a <end_op>

  return fd;
    800052e0:	854e                	mv	a0,s3
    800052e2:	74aa                	ld	s1,168(sp)
    800052e4:	790a                	ld	s2,160(sp)
    800052e6:	69ea                	ld	s3,152(sp)
}
    800052e8:	70ea                	ld	ra,184(sp)
    800052ea:	744a                	ld	s0,176(sp)
    800052ec:	6129                	addi	sp,sp,192
    800052ee:	8082                	ret
      end_op();
    800052f0:	b1bfe0ef          	jal	80003e0a <end_op>
      return -1;
    800052f4:	557d                	li	a0,-1
    800052f6:	74aa                	ld	s1,168(sp)
    800052f8:	bfc5                	j	800052e8 <sys_open+0xc8>
    if ((ip = namei(path)) == 0) {
    800052fa:	f5040513          	addi	a0,s0,-176
    800052fe:	8b3fe0ef          	jal	80003bb0 <namei>
    80005302:	84aa                	mv	s1,a0
    80005304:	c11d                	beqz	a0,8000532a <sys_open+0x10a>
    ilock(ip);
    80005306:	836fe0ef          	jal	8000333c <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    8000530a:	04449703          	lh	a4,68(s1)
    8000530e:	4785                	li	a5,1
    80005310:	f4f71de3          	bne	a4,a5,8000526a <sys_open+0x4a>
    80005314:	f4c42783          	lw	a5,-180(s0)
    80005318:	d3bd                	beqz	a5,8000527e <sys_open+0x5e>
      iunlockput(ip);
    8000531a:	8526                	mv	a0,s1
    8000531c:	a72fe0ef          	jal	8000358e <iunlockput>
      end_op();
    80005320:	aebfe0ef          	jal	80003e0a <end_op>
      return -1;
    80005324:	557d                	li	a0,-1
    80005326:	74aa                	ld	s1,168(sp)
    80005328:	b7c1                	j	800052e8 <sys_open+0xc8>
      end_op();
    8000532a:	ae1fe0ef          	jal	80003e0a <end_op>
      return -1;
    8000532e:	557d                	li	a0,-1
    80005330:	74aa                	ld	s1,168(sp)
    80005332:	bf5d                	j	800052e8 <sys_open+0xc8>
    iunlockput(ip);
    80005334:	8526                	mv	a0,s1
    80005336:	a58fe0ef          	jal	8000358e <iunlockput>
    end_op();
    8000533a:	ad1fe0ef          	jal	80003e0a <end_op>
    return -1;
    8000533e:	557d                	li	a0,-1
    80005340:	74aa                	ld	s1,168(sp)
    80005342:	b75d                	j	800052e8 <sys_open+0xc8>
      fileclose(f);
    80005344:	854a                	mv	a0,s2
    80005346:	eebfe0ef          	jal	80004230 <fileclose>
    8000534a:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000534c:	8526                	mv	a0,s1
    8000534e:	a40fe0ef          	jal	8000358e <iunlockput>
    end_op();
    80005352:	ab9fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005356:	557d                	li	a0,-1
    80005358:	74aa                	ld	s1,168(sp)
    8000535a:	790a                	ld	s2,160(sp)
    8000535c:	b771                	j	800052e8 <sys_open+0xc8>
    f->type = FD_DEVICE;
    8000535e:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005362:	04649783          	lh	a5,70(s1)
    80005366:	02f91223          	sh	a5,36(s2)
    8000536a:	bf3d                	j	800052a8 <sys_open+0x88>
    itrunc(ip);
    8000536c:	8526                	mv	a0,s1
    8000536e:	8bcfe0ef          	jal	8000342a <itrunc>
    80005372:	b795                	j	800052d6 <sys_open+0xb6>

0000000080005374 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005374:	7175                	addi	sp,sp,-144
    80005376:	e506                	sd	ra,136(sp)
    80005378:	e122                	sd	s0,128(sp)
    8000537a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000537c:	a09fe0ef          	jal	80003d84 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005380:	08000613          	li	a2,128
    80005384:	f7040593          	addi	a1,s0,-144
    80005388:	4501                	li	a0,0
    8000538a:	d90fd0ef          	jal	8000291a <argstr>
    8000538e:	02054363          	bltz	a0,800053b4 <sys_mkdir+0x40>
    80005392:	4681                	li	a3,0
    80005394:	4601                	li	a2,0
    80005396:	4585                	li	a1,1
    80005398:	f7040513          	addi	a0,s0,-144
    8000539c:	8e9ff0ef          	jal	80004c84 <create>
    800053a0:	c911                	beqz	a0,800053b4 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053a2:	9ecfe0ef          	jal	8000358e <iunlockput>
  end_op();
    800053a6:	a65fe0ef          	jal	80003e0a <end_op>
  return 0;
    800053aa:	4501                	li	a0,0
}
    800053ac:	60aa                	ld	ra,136(sp)
    800053ae:	640a                	ld	s0,128(sp)
    800053b0:	6149                	addi	sp,sp,144
    800053b2:	8082                	ret
    end_op();
    800053b4:	a57fe0ef          	jal	80003e0a <end_op>
    return -1;
    800053b8:	557d                	li	a0,-1
    800053ba:	bfcd                	j	800053ac <sys_mkdir+0x38>

00000000800053bc <sys_mknod>:

uint64
sys_mknod(void)
{
    800053bc:	7135                	addi	sp,sp,-160
    800053be:	ed06                	sd	ra,152(sp)
    800053c0:	e922                	sd	s0,144(sp)
    800053c2:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800053c4:	9c1fe0ef          	jal	80003d84 <begin_op>
  argint(1, &major);
    800053c8:	f6c40593          	addi	a1,s0,-148
    800053cc:	4505                	li	a0,1
    800053ce:	d14fd0ef          	jal	800028e2 <argint>
  argint(2, &minor);
    800053d2:	f6840593          	addi	a1,s0,-152
    800053d6:	4509                	li	a0,2
    800053d8:	d0afd0ef          	jal	800028e2 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800053dc:	08000613          	li	a2,128
    800053e0:	f7040593          	addi	a1,s0,-144
    800053e4:	4501                	li	a0,0
    800053e6:	d34fd0ef          	jal	8000291a <argstr>
    800053ea:	02054563          	bltz	a0,80005414 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800053ee:	f6841683          	lh	a3,-152(s0)
    800053f2:	f6c41603          	lh	a2,-148(s0)
    800053f6:	458d                	li	a1,3
    800053f8:	f7040513          	addi	a0,s0,-144
    800053fc:	889ff0ef          	jal	80004c84 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005400:	c911                	beqz	a0,80005414 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005402:	98cfe0ef          	jal	8000358e <iunlockput>
  end_op();
    80005406:	a05fe0ef          	jal	80003e0a <end_op>
  return 0;
    8000540a:	4501                	li	a0,0
}
    8000540c:	60ea                	ld	ra,152(sp)
    8000540e:	644a                	ld	s0,144(sp)
    80005410:	610d                	addi	sp,sp,160
    80005412:	8082                	ret
    end_op();
    80005414:	9f7fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005418:	557d                	li	a0,-1
    8000541a:	bfcd                	j	8000540c <sys_mknod+0x50>

000000008000541c <sys_chdir>:

uint64
sys_chdir(void)
{
    8000541c:	7135                	addi	sp,sp,-160
    8000541e:	ed06                	sd	ra,152(sp)
    80005420:	e922                	sd	s0,144(sp)
    80005422:	e14a                	sd	s2,128(sp)
    80005424:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005426:	c7cfc0ef          	jal	800018a2 <myproc>
    8000542a:	892a                	mv	s2,a0

  begin_op();
    8000542c:	959fe0ef          	jal	80003d84 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005430:	08000613          	li	a2,128
    80005434:	f6040593          	addi	a1,s0,-160
    80005438:	4501                	li	a0,0
    8000543a:	ce0fd0ef          	jal	8000291a <argstr>
    8000543e:	04054363          	bltz	a0,80005484 <sys_chdir+0x68>
    80005442:	e526                	sd	s1,136(sp)
    80005444:	f6040513          	addi	a0,s0,-160
    80005448:	f68fe0ef          	jal	80003bb0 <namei>
    8000544c:	84aa                	mv	s1,a0
    8000544e:	c915                	beqz	a0,80005482 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005450:	eedfd0ef          	jal	8000333c <ilock>
  if (ip->type != T_DIR) {
    80005454:	04449703          	lh	a4,68(s1)
    80005458:	4785                	li	a5,1
    8000545a:	02f71963          	bne	a4,a5,8000548c <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000545e:	8526                	mv	a0,s1
    80005460:	f8bfd0ef          	jal	800033ea <iunlock>
  iput(p->cwd);
    80005464:	15093503          	ld	a0,336(s2)
    80005468:	856fe0ef          	jal	800034be <iput>
  end_op();
    8000546c:	99ffe0ef          	jal	80003e0a <end_op>
  p->cwd = ip;
    80005470:	14993823          	sd	s1,336(s2)
  return 0;
    80005474:	4501                	li	a0,0
    80005476:	64aa                	ld	s1,136(sp)
}
    80005478:	60ea                	ld	ra,152(sp)
    8000547a:	644a                	ld	s0,144(sp)
    8000547c:	690a                	ld	s2,128(sp)
    8000547e:	610d                	addi	sp,sp,160
    80005480:	8082                	ret
    80005482:	64aa                	ld	s1,136(sp)
    end_op();
    80005484:	987fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005488:	557d                	li	a0,-1
    8000548a:	b7fd                	j	80005478 <sys_chdir+0x5c>
    iunlockput(ip);
    8000548c:	8526                	mv	a0,s1
    8000548e:	900fe0ef          	jal	8000358e <iunlockput>
    end_op();
    80005492:	979fe0ef          	jal	80003e0a <end_op>
    return -1;
    80005496:	557d                	li	a0,-1
    80005498:	64aa                	ld	s1,136(sp)
    8000549a:	bff9                	j	80005478 <sys_chdir+0x5c>

000000008000549c <sys_exec>:

uint64
sys_exec(void)
{
    8000549c:	7121                	addi	sp,sp,-448
    8000549e:	ff06                	sd	ra,440(sp)
    800054a0:	fb22                	sd	s0,432(sp)
    800054a2:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800054a4:	e4840593          	addi	a1,s0,-440
    800054a8:	4505                	li	a0,1
    800054aa:	c54fd0ef          	jal	800028fe <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    800054ae:	08000613          	li	a2,128
    800054b2:	f5040593          	addi	a1,s0,-176
    800054b6:	4501                	li	a0,0
    800054b8:	c62fd0ef          	jal	8000291a <argstr>
    800054bc:	87aa                	mv	a5,a0
    return -1;
    800054be:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    800054c0:	0c07c463          	bltz	a5,80005588 <sys_exec+0xec>
    800054c4:	f726                	sd	s1,424(sp)
    800054c6:	f34a                	sd	s2,416(sp)
    800054c8:	ef4e                	sd	s3,408(sp)
    800054ca:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800054cc:	10000613          	li	a2,256
    800054d0:	4581                	li	a1,0
    800054d2:	e5040513          	addi	a0,s0,-432
    800054d6:	f7efb0ef          	jal	80000c54 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800054da:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800054de:	89a6                	mv	s3,s1
    800054e0:	4901                	li	s2,0
    if (i >= NELEM(argv)) {
    800054e2:	02000a13          	li	s4,32
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800054e6:	00391513          	slli	a0,s2,0x3
    800054ea:	e4040593          	addi	a1,s0,-448
    800054ee:	e4843783          	ld	a5,-440(s0)
    800054f2:	953e                	add	a0,a0,a5
    800054f4:	b62fd0ef          	jal	80002856 <fetchaddr>
    800054f8:	02054663          	bltz	a0,80005524 <sys_exec+0x88>
      goto bad;
    }
    if (uarg == 0) {
    800054fc:	e4043783          	ld	a5,-448(s0)
    80005500:	c3a9                	beqz	a5,80005542 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005502:	dc8fb0ef          	jal	80000aca <kalloc>
    80005506:	85aa                	mv	a1,a0
    80005508:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    8000550c:	cd01                	beqz	a0,80005524 <sys_exec+0x88>
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000550e:	6605                	lui	a2,0x1
    80005510:	e4043503          	ld	a0,-448(s0)
    80005514:	b8cfd0ef          	jal	800028a0 <fetchstr>
    80005518:	00054663          	bltz	a0,80005524 <sys_exec+0x88>
    if (i >= NELEM(argv)) {
    8000551c:	0905                	addi	s2,s2,1
    8000551e:	09a1                	addi	s3,s3,8
    80005520:	fd4913e3          	bne	s2,s4,800054e6 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005524:	f5040913          	addi	s2,s0,-176
    80005528:	6088                	ld	a0,0(s1)
    8000552a:	c931                	beqz	a0,8000557e <sys_exec+0xe2>
    kfree(argv[i]);
    8000552c:	cbcfb0ef          	jal	800009e8 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005530:	04a1                	addi	s1,s1,8
    80005532:	ff249be3          	bne	s1,s2,80005528 <sys_exec+0x8c>
  return -1;
    80005536:	557d                	li	a0,-1
    80005538:	74ba                	ld	s1,424(sp)
    8000553a:	791a                	ld	s2,416(sp)
    8000553c:	69fa                	ld	s3,408(sp)
    8000553e:	6a5a                	ld	s4,400(sp)
    80005540:	a0a1                	j	80005588 <sys_exec+0xec>
      argv[i] = 0;
    80005542:	0009079b          	sext.w	a5,s2
    80005546:	078e                	slli	a5,a5,0x3
    80005548:	fd078793          	addi	a5,a5,-48
    8000554c:	97a2                	add	a5,a5,s0
    8000554e:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    80005552:	e5040593          	addi	a1,s0,-432
    80005556:	f5040513          	addi	a0,s0,-176
    8000555a:	b26ff0ef          	jal	80004880 <kexec>
    8000555e:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005560:	f5040993          	addi	s3,s0,-176
    80005564:	6088                	ld	a0,0(s1)
    80005566:	c511                	beqz	a0,80005572 <sys_exec+0xd6>
    kfree(argv[i]);
    80005568:	c80fb0ef          	jal	800009e8 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000556c:	04a1                	addi	s1,s1,8
    8000556e:	ff349be3          	bne	s1,s3,80005564 <sys_exec+0xc8>
  return ret;
    80005572:	854a                	mv	a0,s2
    80005574:	74ba                	ld	s1,424(sp)
    80005576:	791a                	ld	s2,416(sp)
    80005578:	69fa                	ld	s3,408(sp)
    8000557a:	6a5a                	ld	s4,400(sp)
    8000557c:	a031                	j	80005588 <sys_exec+0xec>
  return -1;
    8000557e:	557d                	li	a0,-1
    80005580:	74ba                	ld	s1,424(sp)
    80005582:	791a                	ld	s2,416(sp)
    80005584:	69fa                	ld	s3,408(sp)
    80005586:	6a5a                	ld	s4,400(sp)
}
    80005588:	70fa                	ld	ra,440(sp)
    8000558a:	745a                	ld	s0,432(sp)
    8000558c:	6139                	addi	sp,sp,448
    8000558e:	8082                	ret

0000000080005590 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005590:	7139                	addi	sp,sp,-64
    80005592:	fc06                	sd	ra,56(sp)
    80005594:	f822                	sd	s0,48(sp)
    80005596:	f426                	sd	s1,40(sp)
    80005598:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000559a:	b08fc0ef          	jal	800018a2 <myproc>
    8000559e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800055a0:	fd840593          	addi	a1,s0,-40
    800055a4:	4501                	li	a0,0
    800055a6:	b58fd0ef          	jal	800028fe <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    800055aa:	fc840593          	addi	a1,s0,-56
    800055ae:	fd040513          	addi	a0,s0,-48
    800055b2:	f9ffe0ef          	jal	80004550 <pipealloc>
    return -1;
    800055b6:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    800055b8:	0a054663          	bltz	a0,80005664 <sys_pipe+0xd4>
  fd0 = -1;
    800055bc:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    800055c0:	fd043503          	ld	a0,-48(s0)
    800055c4:	e82ff0ef          	jal	80004c46 <fdalloc>
    800055c8:	fca42223          	sw	a0,-60(s0)
    800055cc:	08054363          	bltz	a0,80005652 <sys_pipe+0xc2>
    800055d0:	fc843503          	ld	a0,-56(s0)
    800055d4:	e72ff0ef          	jal	80004c46 <fdalloc>
    800055d8:	fca42023          	sw	a0,-64(s0)
    800055dc:	06054263          	bltz	a0,80005640 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800055e0:	4711                	li	a4,4
    800055e2:	fc440693          	addi	a3,s0,-60
    800055e6:	fd843603          	ld	a2,-40(s0)
    800055ea:	64ac                	ld	a1,72(s1)
    800055ec:	68a8                	ld	a0,80(s1)
    800055ee:	eebfb0ef          	jal	800014d8 <copyout>
    800055f2:	00054f63          	bltz	a0,80005610 <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    800055f6:	4711                	li	a4,4
    800055f8:	fc040693          	addi	a3,s0,-64
    800055fc:	fd843603          	ld	a2,-40(s0)
    80005600:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005602:	64ac                	ld	a1,72(s1)
    80005604:	68a8                	ld	a0,80(s1)
    80005606:	ed3fb0ef          	jal	800014d8 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000560a:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000560c:	04055c63          	bgez	a0,80005664 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    80005610:	fc442783          	lw	a5,-60(s0)
    80005614:	07e9                	addi	a5,a5,26
    80005616:	078e                	slli	a5,a5,0x3
    80005618:	97a6                	add	a5,a5,s1
    8000561a:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000561e:	fc042783          	lw	a5,-64(s0)
    80005622:	07e9                	addi	a5,a5,26
    80005624:	078e                	slli	a5,a5,0x3
    80005626:	94be                	add	s1,s1,a5
    80005628:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000562c:	fd043503          	ld	a0,-48(s0)
    80005630:	c01fe0ef          	jal	80004230 <fileclose>
    fileclose(wf);
    80005634:	fc843503          	ld	a0,-56(s0)
    80005638:	bf9fe0ef          	jal	80004230 <fileclose>
    return -1;
    8000563c:	57fd                	li	a5,-1
    8000563e:	a01d                	j	80005664 <sys_pipe+0xd4>
    if (fd0 >= 0)
    80005640:	fc442783          	lw	a5,-60(s0)
    80005644:	0007c763          	bltz	a5,80005652 <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    80005648:	07e9                	addi	a5,a5,26
    8000564a:	078e                	slli	a5,a5,0x3
    8000564c:	97a6                	add	a5,a5,s1
    8000564e:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005652:	fd043503          	ld	a0,-48(s0)
    80005656:	bdbfe0ef          	jal	80004230 <fileclose>
    fileclose(wf);
    8000565a:	fc843503          	ld	a0,-56(s0)
    8000565e:	bd3fe0ef          	jal	80004230 <fileclose>
    return -1;
    80005662:	57fd                	li	a5,-1
}
    80005664:	853e                	mv	a0,a5
    80005666:	70e2                	ld	ra,56(sp)
    80005668:	7442                	ld	s0,48(sp)
    8000566a:	74a2                	ld	s1,40(sp)
    8000566c:	6121                	addi	sp,sp,64
    8000566e:	8082                	ret

0000000080005670 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005670:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005672:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005674:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005676:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005678:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000567a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000567c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000567e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005680:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005682:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005684:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005686:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005688:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000568a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000568c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000568e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005690:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005692:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005694:	8d2fd0ef          	jal	80002766 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005698:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000569a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000569c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000569e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800056a0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800056a2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800056a4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800056a6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800056a8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800056aa:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800056ac:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800056ae:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800056b0:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800056b2:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800056b4:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800056b6:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800056b8:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800056ba:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800056bc:	10200073          	sret
	...

00000000800056ce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056ce:	1141                	addi	sp,sp,-16
    800056d0:	e422                	sd	s0,8(sp)
    800056d2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800056d4:	0c0007b7          	lui	a5,0xc000
    800056d8:	4705                	li	a4,1
    800056da:	d798                	sw	a4,40(a5)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800056dc:	0c0007b7          	lui	a5,0xc000
    800056e0:	c3d8                	sw	a4,4(a5)
}
    800056e2:	6422                	ld	s0,8(sp)
    800056e4:	0141                	addi	sp,sp,16
    800056e6:	8082                	ret

00000000800056e8 <plicinithart>:

void
plicinithart(void)
{
    800056e8:	1141                	addi	sp,sp,-16
    800056ea:	e406                	sd	ra,8(sp)
    800056ec:	e022                	sd	s0,0(sp)
    800056ee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056f0:	986fc0ef          	jal	80001876 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    800056f4:	0085179b          	slliw	a5,a0,0x8
    800056f8:	0c002737          	lui	a4,0xc002
    800056fc:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    80005700:	97ba                	add	a5,a5,a4
    80005702:	40200713          	li	a4,1026
    80005706:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005708:	00d5151b          	slliw	a0,a0,0xd
    8000570c:	0c2017b7          	lui	a5,0xc201
    80005710:	953e                	add	a0,a0,a5
    80005712:	00052023          	sw	zero,0(a0)
}
    80005716:	60a2                	ld	ra,8(sp)
    80005718:	6402                	ld	s0,0(sp)
    8000571a:	0141                	addi	sp,sp,16
    8000571c:	8082                	ret

000000008000571e <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000571e:	1141                	addi	sp,sp,-16
    80005720:	e406                	sd	ra,8(sp)
    80005722:	e022                	sd	s0,0(sp)
    80005724:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005726:	950fc0ef          	jal	80001876 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    8000572a:	00d5151b          	slliw	a0,a0,0xd
    8000572e:	0c2017b7          	lui	a5,0xc201
    80005732:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    80005734:	953e                	add	a0,a0,a5
    80005736:	4108                	lw	a0,0(a0)
  return irq;
}
    80005738:	60a2                	ld	ra,8(sp)
    8000573a:	6402                	ld	s0,0(sp)
    8000573c:	0141                	addi	sp,sp,16
    8000573e:	8082                	ret

0000000080005740 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005740:	1101                	addi	sp,sp,-32
    80005742:	ec06                	sd	ra,24(sp)
    80005744:	e822                	sd	s0,16(sp)
    80005746:	e426                	sd	s1,8(sp)
    80005748:	1000                	addi	s0,sp,32
    8000574a:	84aa                	mv	s1,a0
  int hart = cpuid();
    8000574c:	92afc0ef          	jal	80001876 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    80005750:	00d5179b          	slliw	a5,a0,0xd
    80005754:	0c201737          	lui	a4,0xc201
    80005758:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    8000575a:	97ba                	add	a5,a5,a4
    8000575c:	2481                	sext.w	s1,s1
    8000575e:	c384                	sw	s1,0(a5)
}
    80005760:	60e2                	ld	ra,24(sp)
    80005762:	6442                	ld	s0,16(sp)
    80005764:	64a2                	ld	s1,8(sp)
    80005766:	6105                	addi	sp,sp,32
    80005768:	8082                	ret

000000008000576a <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    8000576a:	1141                	addi	sp,sp,-16
    8000576c:	e406                	sd	ra,8(sp)
    8000576e:	e022                	sd	s0,0(sp)
    80005770:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005772:	479d                	li	a5,7
    80005774:	04a7ca63          	blt	a5,a0,800057c8 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005778:	0001e797          	auipc	a5,0x1e
    8000577c:	16878793          	addi	a5,a5,360 # 800238e0 <disk>
    80005780:	97aa                	add	a5,a5,a0
    80005782:	0187c783          	lbu	a5,24(a5)
    80005786:	e7b9                	bnez	a5,800057d4 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005788:	00451693          	slli	a3,a0,0x4
    8000578c:	0001e797          	auipc	a5,0x1e
    80005790:	15478793          	addi	a5,a5,340 # 800238e0 <disk>
    80005794:	6398                	ld	a4,0(a5)
    80005796:	9736                	add	a4,a4,a3
    80005798:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    8000579c:	6398                	ld	a4,0(a5)
    8000579e:	9736                	add	a4,a4,a3
    800057a0:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800057a4:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800057a8:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800057ac:	97aa                	add	a5,a5,a0
    800057ae:	4705                	li	a4,1
    800057b0:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800057b4:	0001e517          	auipc	a0,0x1e
    800057b8:	14450513          	addi	a0,a0,324 # 800238f8 <disk+0x18>
    800057bc:	fa4fc0ef          	jal	80001f60 <wakeup>
}
    800057c0:	60a2                	ld	ra,8(sp)
    800057c2:	6402                	ld	s0,0(sp)
    800057c4:	0141                	addi	sp,sp,16
    800057c6:	8082                	ret
    panic("free_desc 1");
    800057c8:	00002517          	auipc	a0,0x2
    800057cc:	e6850513          	addi	a0,a0,-408 # 80007630 <etext+0x630>
    800057d0:	820fb0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    800057d4:	00002517          	auipc	a0,0x2
    800057d8:	e6c50513          	addi	a0,a0,-404 # 80007640 <etext+0x640>
    800057dc:	814fb0ef          	jal	800007f0 <panic>

00000000800057e0 <virtio_disk_init>:
{
    800057e0:	1101                	addi	sp,sp,-32
    800057e2:	ec06                	sd	ra,24(sp)
    800057e4:	e822                	sd	s0,16(sp)
    800057e6:	e426                	sd	s1,8(sp)
    800057e8:	e04a                	sd	s2,0(sp)
    800057ea:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057ec:	00002597          	auipc	a1,0x2
    800057f0:	e6458593          	addi	a1,a1,-412 # 80007650 <etext+0x650>
    800057f4:	0001e517          	auipc	a0,0x1e
    800057f8:	21450513          	addi	a0,a0,532 # 80023a08 <disk+0x128>
    800057fc:	b1efb0ef          	jal	80000b1a <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005800:	100017b7          	lui	a5,0x10001
    80005804:	4398                	lw	a4,0(a5)
    80005806:	2701                	sext.w	a4,a4
    80005808:	747277b7          	lui	a5,0x74727
    8000580c:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005810:	18f71063          	bne	a4,a5,80005990 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005814:	100017b7          	lui	a5,0x10001
    80005818:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    8000581a:	439c                	lw	a5,0(a5)
    8000581c:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    8000581e:	4709                	li	a4,2
    80005820:	16e79863          	bne	a5,a4,80005990 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005824:	100017b7          	lui	a5,0x10001
    80005828:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    8000582a:	439c                	lw	a5,0(a5)
    8000582c:	2781                	sext.w	a5,a5
    8000582e:	16e79163          	bne	a5,a4,80005990 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005832:	100017b7          	lui	a5,0x10001
    80005836:	47d8                	lw	a4,12(a5)
    80005838:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000583a:	554d47b7          	lui	a5,0x554d4
    8000583e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005842:	14f71763          	bne	a4,a5,80005990 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005846:	100017b7          	lui	a5,0x10001
    8000584a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000584e:	4705                	li	a4,1
    80005850:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005852:	470d                	li	a4,3
    80005854:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005856:	10001737          	lui	a4,0x10001
    8000585a:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    8000585c:	c7ffe737          	lui	a4,0xc7ffe
    80005860:	55f70713          	addi	a4,a4,1375 # ffffffffc7ffe55f <end+0xffffffff47fdab3f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005864:	8ef9                	and	a3,a3,a4
    80005866:	10001737          	lui	a4,0x10001
    8000586a:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000586c:	472d                	li	a4,11
    8000586e:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005870:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005874:	439c                	lw	a5,0(a5)
    80005876:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000587a:	8ba1                	andi	a5,a5,8
    8000587c:	12078063          	beqz	a5,8000599c <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005880:	100017b7          	lui	a5,0x10001
    80005884:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005888:	100017b7          	lui	a5,0x10001
    8000588c:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005890:	439c                	lw	a5,0(a5)
    80005892:	2781                	sext.w	a5,a5
    80005894:	10079a63          	bnez	a5,800059a8 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005898:	100017b7          	lui	a5,0x10001
    8000589c:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    800058a0:	439c                	lw	a5,0(a5)
    800058a2:	2781                	sext.w	a5,a5
  if (max == 0)
    800058a4:	10078863          	beqz	a5,800059b4 <virtio_disk_init+0x1d4>
  if (max < NUM)
    800058a8:	471d                	li	a4,7
    800058aa:	10f77b63          	bgeu	a4,a5,800059c0 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    800058ae:	a1cfb0ef          	jal	80000aca <kalloc>
    800058b2:	0001e497          	auipc	s1,0x1e
    800058b6:	02e48493          	addi	s1,s1,46 # 800238e0 <disk>
    800058ba:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800058bc:	a0efb0ef          	jal	80000aca <kalloc>
    800058c0:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800058c2:	a08fb0ef          	jal	80000aca <kalloc>
    800058c6:	87aa                	mv	a5,a0
    800058c8:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    800058ca:	6088                	ld	a0,0(s1)
    800058cc:	10050063          	beqz	a0,800059cc <virtio_disk_init+0x1ec>
    800058d0:	0001e717          	auipc	a4,0x1e
    800058d4:	01873703          	ld	a4,24(a4) # 800238e8 <disk+0x8>
    800058d8:	0e070a63          	beqz	a4,800059cc <virtio_disk_init+0x1ec>
    800058dc:	0e078863          	beqz	a5,800059cc <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    800058e0:	6605                	lui	a2,0x1
    800058e2:	4581                	li	a1,0
    800058e4:	b70fb0ef          	jal	80000c54 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058e8:	0001e497          	auipc	s1,0x1e
    800058ec:	ff848493          	addi	s1,s1,-8 # 800238e0 <disk>
    800058f0:	6605                	lui	a2,0x1
    800058f2:	4581                	li	a1,0
    800058f4:	6488                	ld	a0,8(s1)
    800058f6:	b5efb0ef          	jal	80000c54 <memset>
  memset(disk.used, 0, PGSIZE);
    800058fa:	6605                	lui	a2,0x1
    800058fc:	4581                	li	a1,0
    800058fe:	6888                	ld	a0,16(s1)
    80005900:	b54fb0ef          	jal	80000c54 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005904:	100017b7          	lui	a5,0x10001
    80005908:	4721                	li	a4,8
    8000590a:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000590c:	4098                	lw	a4,0(s1)
    8000590e:	100017b7          	lui	a5,0x10001
    80005912:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005916:	40d8                	lw	a4,4(s1)
    80005918:	100017b7          	lui	a5,0x10001
    8000591c:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005920:	649c                	ld	a5,8(s1)
    80005922:	0007869b          	sext.w	a3,a5
    80005926:	10001737          	lui	a4,0x10001
    8000592a:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    8000592e:	9781                	srai	a5,a5,0x20
    80005930:	10001737          	lui	a4,0x10001
    80005934:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005938:	689c                	ld	a5,16(s1)
    8000593a:	0007869b          	sext.w	a3,a5
    8000593e:	10001737          	lui	a4,0x10001
    80005942:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005946:	9781                	srai	a5,a5,0x20
    80005948:	10001737          	lui	a4,0x10001
    8000594c:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005950:	10001737          	lui	a4,0x10001
    80005954:	4785                	li	a5,1
    80005956:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005958:	00f48c23          	sb	a5,24(s1)
    8000595c:	00f48ca3          	sb	a5,25(s1)
    80005960:	00f48d23          	sb	a5,26(s1)
    80005964:	00f48da3          	sb	a5,27(s1)
    80005968:	00f48e23          	sb	a5,28(s1)
    8000596c:	00f48ea3          	sb	a5,29(s1)
    80005970:	00f48f23          	sb	a5,30(s1)
    80005974:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005978:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000597c:	100017b7          	lui	a5,0x10001
    80005980:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    80005984:	60e2                	ld	ra,24(sp)
    80005986:	6442                	ld	s0,16(sp)
    80005988:	64a2                	ld	s1,8(sp)
    8000598a:	6902                	ld	s2,0(sp)
    8000598c:	6105                	addi	sp,sp,32
    8000598e:	8082                	ret
    panic("could not find virtio disk");
    80005990:	00002517          	auipc	a0,0x2
    80005994:	cd050513          	addi	a0,a0,-816 # 80007660 <etext+0x660>
    80005998:	e59fa0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    8000599c:	00002517          	auipc	a0,0x2
    800059a0:	ce450513          	addi	a0,a0,-796 # 80007680 <etext+0x680>
    800059a4:	e4dfa0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    800059a8:	00002517          	auipc	a0,0x2
    800059ac:	cf850513          	addi	a0,a0,-776 # 800076a0 <etext+0x6a0>
    800059b0:	e41fa0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    800059b4:	00002517          	auipc	a0,0x2
    800059b8:	d0c50513          	addi	a0,a0,-756 # 800076c0 <etext+0x6c0>
    800059bc:	e35fa0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    800059c0:	00002517          	auipc	a0,0x2
    800059c4:	d2050513          	addi	a0,a0,-736 # 800076e0 <etext+0x6e0>
    800059c8:	e29fa0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    800059cc:	00002517          	auipc	a0,0x2
    800059d0:	d3450513          	addi	a0,a0,-716 # 80007700 <etext+0x700>
    800059d4:	e1dfa0ef          	jal	800007f0 <panic>

00000000800059d8 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800059d8:	7159                	addi	sp,sp,-112
    800059da:	f486                	sd	ra,104(sp)
    800059dc:	f0a2                	sd	s0,96(sp)
    800059de:	eca6                	sd	s1,88(sp)
    800059e0:	e8ca                	sd	s2,80(sp)
    800059e2:	e4ce                	sd	s3,72(sp)
    800059e4:	e0d2                	sd	s4,64(sp)
    800059e6:	fc56                	sd	s5,56(sp)
    800059e8:	f85a                	sd	s6,48(sp)
    800059ea:	f45e                	sd	s7,40(sp)
    800059ec:	f062                	sd	s8,32(sp)
    800059ee:	ec66                	sd	s9,24(sp)
    800059f0:	1880                	addi	s0,sp,112
    800059f2:	8a2a                	mv	s4,a0
    800059f4:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800059f6:	00c52c83          	lw	s9,12(a0)
    800059fa:	001c9c9b          	slliw	s9,s9,0x1
    800059fe:	1c82                	slli	s9,s9,0x20
    80005a00:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005a04:	0001e517          	auipc	a0,0x1e
    80005a08:	00450513          	addi	a0,a0,4 # 80023a08 <disk+0x128>
    80005a0c:	984fb0ef          	jal	80000b90 <acquire>
  for (int i = 0; i < 3; i++) {
    80005a10:	4981                	li	s3,0
  for (int i = 0; i < NUM; i++) {
    80005a12:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005a14:	0001eb17          	auipc	s6,0x1e
    80005a18:	eccb0b13          	addi	s6,s6,-308 # 800238e0 <disk>
  for (int i = 0; i < 3; i++) {
    80005a1c:	4a8d                	li	s5,3
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005a1e:	0001ec17          	auipc	s8,0x1e
    80005a22:	edac0c13          	addi	s8,s8,-294 # 800238f8 <disk+0x18>
    80005a26:	a0bd                	j	80005a94 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80005a28:	00fb0733          	add	a4,s6,a5
    80005a2c:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005a30:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80005a32:	0207c563          	bltz	a5,80005a5c <virtio_disk_rw+0x84>
  for (int i = 0; i < 3; i++) {
    80005a36:	2905                	addiw	s2,s2,1
    80005a38:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005a3a:	07590163          	beq	s2,s5,80005a9c <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005a3e:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005a40:	0001e717          	auipc	a4,0x1e
    80005a44:	ea070713          	addi	a4,a4,-352 # 800238e0 <disk>
    80005a48:	87ce                	mv	a5,s3
    if (disk.free[i]) {
    80005a4a:	01874683          	lbu	a3,24(a4)
    80005a4e:	fee9                	bnez	a3,80005a28 <virtio_disk_rw+0x50>
  for (int i = 0; i < NUM; i++) {
    80005a50:	2785                	addiw	a5,a5,1
    80005a52:	0705                	addi	a4,a4,1
    80005a54:	fe979be3          	bne	a5,s1,80005a4a <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005a58:	57fd                	li	a5,-1
    80005a5a:	c19c                	sw	a5,0(a1)
      for (int j = 0; j < i; j++)
    80005a5c:	01205d63          	blez	s2,80005a76 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a60:	f9042503          	lw	a0,-112(s0)
    80005a64:	d07ff0ef          	jal	8000576a <free_desc>
      for (int j = 0; j < i; j++)
    80005a68:	4785                	li	a5,1
    80005a6a:	0127d663          	bge	a5,s2,80005a76 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a6e:	f9442503          	lw	a0,-108(s0)
    80005a72:	cf9ff0ef          	jal	8000576a <free_desc>
    sleep_prepare(&disk.free[0]);
    80005a76:	8562                	mv	a0,s8
    80005a78:	c7cfc0ef          	jal	80001ef4 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005a7c:	0001e917          	auipc	s2,0x1e
    80005a80:	f8c90913          	addi	s2,s2,-116 # 80023a08 <disk+0x128>
    80005a84:	854a                	mv	a0,s2
    80005a86:	996fb0ef          	jal	80000c1c <release>
    sleep();
    80005a8a:	ca6fc0ef          	jal	80001f30 <sleep>
    acquire(&disk.vdisk_lock);
    80005a8e:	854a                	mv	a0,s2
    80005a90:	900fb0ef          	jal	80000b90 <acquire>
  for (int i = 0; i < 3; i++) {
    80005a94:	f9040613          	addi	a2,s0,-112
    80005a98:	894e                	mv	s2,s3
    80005a9a:	b755                	j	80005a3e <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a9c:	f9042503          	lw	a0,-112(s0)
    80005aa0:	00451693          	slli	a3,a0,0x4

  if (write)
    80005aa4:	0001e797          	auipc	a5,0x1e
    80005aa8:	e3c78793          	addi	a5,a5,-452 # 800238e0 <disk>
    80005aac:	00a50713          	addi	a4,a0,10
    80005ab0:	0712                	slli	a4,a4,0x4
    80005ab2:	973e                	add	a4,a4,a5
    80005ab4:	01703633          	snez	a2,s7
    80005ab8:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005aba:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005abe:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005ac2:	6398                	ld	a4,0(a5)
    80005ac4:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005ac6:	0a868613          	addi	a2,a3,168
    80005aca:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005acc:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005ace:	6390                	ld	a2,0(a5)
    80005ad0:	00d605b3          	add	a1,a2,a3
    80005ad4:	4741                	li	a4,16
    80005ad6:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005ad8:	4805                	li	a6,1
    80005ada:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005ade:	f9442703          	lw	a4,-108(s0)
    80005ae2:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005ae6:	0712                	slli	a4,a4,0x4
    80005ae8:	963a                	add	a2,a2,a4
    80005aea:	058a0593          	addi	a1,s4,88
    80005aee:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005af0:	0007b883          	ld	a7,0(a5)
    80005af4:	9746                	add	a4,a4,a7
    80005af6:	40000613          	li	a2,1024
    80005afa:	c710                	sw	a2,8(a4)
  if (write)
    80005afc:	001bb613          	seqz	a2,s7
    80005b00:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005b04:	00166613          	ori	a2,a2,1
    80005b08:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005b0c:	f9842583          	lw	a1,-104(s0)
    80005b10:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005b14:	00250613          	addi	a2,a0,2
    80005b18:	0612                	slli	a2,a2,0x4
    80005b1a:	963e                	add	a2,a2,a5
    80005b1c:	577d                	li	a4,-1
    80005b1e:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005b22:	0592                	slli	a1,a1,0x4
    80005b24:	98ae                	add	a7,a7,a1
    80005b26:	03068713          	addi	a4,a3,48
    80005b2a:	973e                	add	a4,a4,a5
    80005b2c:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005b30:	6398                	ld	a4,0(a5)
    80005b32:	972e                	add	a4,a4,a1
    80005b34:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005b38:	4689                	li	a3,2
    80005b3a:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005b3e:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005b42:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005b46:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005b4a:	6794                	ld	a3,8(a5)
    80005b4c:	0026d703          	lhu	a4,2(a3)
    80005b50:	8b1d                	andi	a4,a4,7
    80005b52:	0706                	slli	a4,a4,0x1
    80005b54:	96ba                	add	a3,a3,a4
    80005b56:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005b5a:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b5e:	6798                	ld	a4,8(a5)
    80005b60:	00275783          	lhu	a5,2(a4)
    80005b64:	2785                	addiw	a5,a5,1
    80005b66:	00f71123          	sh	a5,2(a4)
    80005b6a:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b6e:	100017b7          	lui	a5,0x10001
    80005b72:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005b76:	004a2783          	lw	a5,4(s4)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005b7a:	0001e497          	auipc	s1,0x1e
    80005b7e:	e8e48493          	addi	s1,s1,-370 # 80023a08 <disk+0x128>
  while (b->disk == 1) {
    80005b82:	4905                	li	s2,1
    80005b84:	03079163          	bne	a5,a6,80005ba6 <virtio_disk_rw+0x1ce>
    sleep_prepare(b);
    80005b88:	8552                	mv	a0,s4
    80005b8a:	b6afc0ef          	jal	80001ef4 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005b8e:	8526                	mv	a0,s1
    80005b90:	88cfb0ef          	jal	80000c1c <release>
    sleep();
    80005b94:	b9cfc0ef          	jal	80001f30 <sleep>
    acquire(&disk.vdisk_lock);
    80005b98:	8526                	mv	a0,s1
    80005b9a:	ff7fa0ef          	jal	80000b90 <acquire>
  while (b->disk == 1) {
    80005b9e:	004a2783          	lw	a5,4(s4)
    80005ba2:	ff2783e3          	beq	a5,s2,80005b88 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80005ba6:	f9042903          	lw	s2,-112(s0)
    80005baa:	00290713          	addi	a4,s2,2
    80005bae:	0712                	slli	a4,a4,0x4
    80005bb0:	0001e797          	auipc	a5,0x1e
    80005bb4:	d3078793          	addi	a5,a5,-720 # 800238e0 <disk>
    80005bb8:	97ba                	add	a5,a5,a4
    80005bba:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005bbe:	0001e997          	auipc	s3,0x1e
    80005bc2:	d2298993          	addi	s3,s3,-734 # 800238e0 <disk>
    80005bc6:	00491713          	slli	a4,s2,0x4
    80005bca:	0009b783          	ld	a5,0(s3)
    80005bce:	97ba                	add	a5,a5,a4
    80005bd0:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005bd4:	854a                	mv	a0,s2
    80005bd6:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005bda:	b91ff0ef          	jal	8000576a <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005bde:	8885                	andi	s1,s1,1
    80005be0:	f0fd                	bnez	s1,80005bc6 <virtio_disk_rw+0x1ee>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005be2:	0001e517          	auipc	a0,0x1e
    80005be6:	e2650513          	addi	a0,a0,-474 # 80023a08 <disk+0x128>
    80005bea:	832fb0ef          	jal	80000c1c <release>
}
    80005bee:	70a6                	ld	ra,104(sp)
    80005bf0:	7406                	ld	s0,96(sp)
    80005bf2:	64e6                	ld	s1,88(sp)
    80005bf4:	6946                	ld	s2,80(sp)
    80005bf6:	69a6                	ld	s3,72(sp)
    80005bf8:	6a06                	ld	s4,64(sp)
    80005bfa:	7ae2                	ld	s5,56(sp)
    80005bfc:	7b42                	ld	s6,48(sp)
    80005bfe:	7ba2                	ld	s7,40(sp)
    80005c00:	7c02                	ld	s8,32(sp)
    80005c02:	6ce2                	ld	s9,24(sp)
    80005c04:	6165                	addi	sp,sp,112
    80005c06:	8082                	ret

0000000080005c08 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005c08:	1101                	addi	sp,sp,-32
    80005c0a:	ec06                	sd	ra,24(sp)
    80005c0c:	e822                	sd	s0,16(sp)
    80005c0e:	e426                	sd	s1,8(sp)
    80005c10:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005c12:	0001e497          	auipc	s1,0x1e
    80005c16:	cce48493          	addi	s1,s1,-818 # 800238e0 <disk>
    80005c1a:	0001e517          	auipc	a0,0x1e
    80005c1e:	dee50513          	addi	a0,a0,-530 # 80023a08 <disk+0x128>
    80005c22:	f6ffa0ef          	jal	80000b90 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005c26:	100017b7          	lui	a5,0x10001
    80005c2a:	53b8                	lw	a4,96(a5)
    80005c2c:	8b0d                	andi	a4,a4,3
    80005c2e:	100017b7          	lui	a5,0x10001
    80005c32:	d3f8                	sw	a4,100(a5)
    80005c34:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005c38:	689c                	ld	a5,16(s1)
    80005c3a:	0204d703          	lhu	a4,32(s1)
    80005c3e:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005c42:	04f70663          	beq	a4,a5,80005c8e <virtio_disk_intr+0x86>
    80005c46:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005c4a:	6898                	ld	a4,16(s1)
    80005c4c:	0204d783          	lhu	a5,32(s1)
    80005c50:	8b9d                	andi	a5,a5,7
    80005c52:	078e                	slli	a5,a5,0x3
    80005c54:	97ba                	add	a5,a5,a4
    80005c56:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005c58:	00278713          	addi	a4,a5,2
    80005c5c:	0712                	slli	a4,a4,0x4
    80005c5e:	9726                	add	a4,a4,s1
    80005c60:	01074703          	lbu	a4,16(a4)
    80005c64:	e321                	bnez	a4,80005ca4 <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c66:	0789                	addi	a5,a5,2
    80005c68:	0792                	slli	a5,a5,0x4
    80005c6a:	97a6                	add	a5,a5,s1
    80005c6c:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005c6e:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c72:	aeefc0ef          	jal	80001f60 <wakeup>

    disk.used_idx += 1;
    80005c76:	0204d783          	lhu	a5,32(s1)
    80005c7a:	2785                	addiw	a5,a5,1
    80005c7c:	17c2                	slli	a5,a5,0x30
    80005c7e:	93c1                	srli	a5,a5,0x30
    80005c80:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005c84:	6898                	ld	a4,16(s1)
    80005c86:	00275703          	lhu	a4,2(a4)
    80005c8a:	faf71ee3          	bne	a4,a5,80005c46 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c8e:	0001e517          	auipc	a0,0x1e
    80005c92:	d7a50513          	addi	a0,a0,-646 # 80023a08 <disk+0x128>
    80005c96:	f87fa0ef          	jal	80000c1c <release>
}
    80005c9a:	60e2                	ld	ra,24(sp)
    80005c9c:	6442                	ld	s0,16(sp)
    80005c9e:	64a2                	ld	s1,8(sp)
    80005ca0:	6105                	addi	sp,sp,32
    80005ca2:	8082                	ret
      panic("virtio_disk_intr status");
    80005ca4:	00002517          	auipc	a0,0x2
    80005ca8:	a7450513          	addi	a0,a0,-1420 # 80007718 <etext+0x718>
    80005cac:	b45fa0ef          	jal	800007f0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
