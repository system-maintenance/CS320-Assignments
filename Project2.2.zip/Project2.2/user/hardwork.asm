
user/_hardwork:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <decide>:
#include "user/user.h"

#define N 3

int decide(int a, int b, int direction)
{
   0:	1141                	addi	sp,sp,-16
   2:	e422                	sd	s0,8(sp)
   4:	0800                	addi	s0,sp,16
    if (direction)
   6:	c611                	beqz	a2,12 <decide+0x12>
        if (a < b) return 1; else return 0;
   8:	00b52533          	slt	a0,a0,a1
    else if (a<b) return 0; else return 1;
}
   c:	6422                	ld	s0,8(sp)
   e:	0141                	addi	sp,sp,16
  10:	8082                	ret
    else if (a<b) return 0; else return 1;
  12:	00b52533          	slt	a0,a0,a1
  16:	00154513          	xori	a0,a0,1
  1a:	bfcd                	j	c <decide+0xc>

000000000000001c <hardWork>:
int hardWork()
{
  1c:	715d                	addi	sp,sp,-80
  1e:	e486                	sd	ra,72(sp)
  20:	e0a2                	sd	s0,64(sp)
  22:	0880                	addi	s0,sp,80
    int bFun[3];
    for (int r = 0; r < N; ++r)
    {
        for (int c = 0; c < N; ++c)
        {
            bigFun[r][c] = r; 
  24:	fc042423          	sw	zero,-56(s0)
  28:	fc042623          	sw	zero,-52(s0)
  2c:	fc042823          	sw	zero,-48(s0)
        }
        bFun[r] = r; 
  30:	fa042c23          	sw	zero,-72(s0)
            bigFun[r][c] = r; 
  34:	4785                	li	a5,1
  36:	fcf42a23          	sw	a5,-44(s0)
  3a:	fcf42c23          	sw	a5,-40(s0)
  3e:	fcf42e23          	sw	a5,-36(s0)
        bFun[r] = r; 
  42:	faf42e23          	sw	a5,-68(s0)
            bigFun[r][c] = r; 
  46:	4789                	li	a5,2
  48:	fef42023          	sw	a5,-32(s0)
  4c:	fef42223          	sw	a5,-28(s0)
  50:	fef42423          	sw	a5,-24(s0)
        bFun[r] = r; 
  54:	fcf42023          	sw	a5,-64(s0)
    }
    printf("initialized\n");
  58:	00001517          	auipc	a0,0x1
  5c:	91850513          	addi	a0,a0,-1768 # 970 <malloc+0xfa>
  60:	762000ef          	jal	7c2 <printf>
    int changes = 1;
  64:	4585                	li	a1,1
    int total = 0;
    int direction = 0;
    for (;;)
    {
        while (changes)
  66:	4e85                	li	t4,1
        {
            changes = 0;
  68:	4f01                	li	t5,0
            for (int r = 0; r < N-1; ++r)
                for (int c =0; c < N; ++c)
  6a:	4e0d                	li	t3,3
  6c:	a0a1                	j	b4 <hardWork+0x98>
                        bigFun[r][c] = bigFun[r+1][c];
                        bigFun[r+1][c] = bFun[r]*temp;
                        changes++;
                        ++total;
                    }
                    else if (c < N-1 && bigFun[r][c] > bigFun[r][c+1])
  6e:	00eecb63          	blt	t4,a4,84 <hardWork+0x68>
  72:	43d0                	lw	a2,4(a5)
  74:	00d65563          	bge	a2,a3,7e <hardWork+0x62>
                    {
                        int temp = bigFun[r][c];
                        bigFun[r][c] = bigFun[r][c+1];
  78:	c390                	sw	a2,0(a5)
                        bigFun[r][c+1] = temp;
  7a:	c3d4                	sw	a3,4(a5)
                        changes++;
  7c:	2585                	addiw	a1,a1,1
                for (int c =0; c < N; ++c)
  7e:	2705                	addiw	a4,a4,1
  80:	0791                	addi	a5,a5,4
  82:	a801                	j	92 <hardWork+0x76>
            for (int r = 0; r < N-1; ++r)
  84:	2885                	addiw	a7,a7,1
  86:	0331                	addi	t1,t1,12
  88:	0811                	addi	a6,a6,4
  8a:	03c88563          	beq	a7,t3,b4 <hardWork+0x98>
{
  8e:	879a                	mv	a5,t1
                for (int c =0; c < N; ++c)
  90:	877a                	mv	a4,t5
                    if (bigFun[r][c] > bigFun[r+1][c])
  92:	4394                	lw	a3,0(a5)
  94:	47d0                	lw	a2,12(a5)
  96:	fcd65ce3          	bge	a2,a3,6e <hardWork+0x52>
                        bigFun[r][c] = bigFun[r+1][c];
  9a:	c390                	sw	a2,0(a5)
                        bigFun[r+1][c] = bFun[r]*temp;
  9c:	00082603          	lw	a2,0(a6)
  a0:	02d606bb          	mulw	a3,a2,a3
  a4:	c7d4                	sw	a3,12(a5)
                        changes++;
  a6:	2585                	addiw	a1,a1,1
                for (int c =0; c < N; ++c)
  a8:	2705                	addiw	a4,a4,1
  aa:	0791                	addi	a5,a5,4
  ac:	ffc713e3          	bne	a4,t3,92 <hardWork+0x76>
  b0:	bfd1                	j	84 <hardWork+0x68>
                        ++total;
                    }
                }
        }
        if (direction == 1) direction = 0; else direction = 1;
        changes = 1;
  b2:	85f6                	mv	a1,t4
        while (changes)
  b4:	ddfd                	beqz	a1,b2 <hardWork+0x96>
  b6:	fc840313          	addi	t1,s0,-56
  ba:	fb840813          	addi	a6,s0,-72
  be:	88f6                	mv	a7,t4
            changes = 0;
  c0:	85fa                	mv	a1,t5
  c2:	b7f1                	j	8e <hardWork+0x72>

00000000000000c4 <main>:
    }
    return total;
}

int main(int argc, char *argv[])
{
  c4:	1141                	addi	sp,sp,-16
  c6:	e406                	sd	ra,8(sp)
  c8:	e022                	sd	s0,0(sp)
  ca:	0800                	addi	s0,sp,16
    int val;
/* uncomment the following to use strides */

    if (argc >1)
  cc:	4785                	li	a5,1
  ce:	00a7ca63          	blt	a5,a0,e2 <main+0x1e>
        setstride(atoi(argv[1]));

    printf("starting main\n");
  d2:	00001517          	auipc	a0,0x1
  d6:	8ae50513          	addi	a0,a0,-1874 # 980 <malloc+0x10a>
  da:	6e8000ef          	jal	7c2 <printf>
    val = hardWork();
  de:	f3fff0ef          	jal	1c <hardWork>
        setstride(atoi(argv[1]));
  e2:	6588                	ld	a0,8(a1)
  e4:	17c000ef          	jal	260 <atoi>
  e8:	34a000ef          	jal	432 <setstride>
  ec:	b7dd                	j	d2 <main+0xe>

00000000000000ee <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  ee:	1141                	addi	sp,sp,-16
  f0:	e406                	sd	ra,8(sp)
  f2:	e022                	sd	s0,0(sp)
  f4:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  f6:	fcfff0ef          	jal	c4 <main>
  exit(r);
  fa:	288000ef          	jal	382 <exit>

00000000000000fe <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
  fe:	1141                	addi	sp,sp,-16
 100:	e422                	sd	s0,8(sp)
 102:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 104:	87aa                	mv	a5,a0
 106:	0585                	addi	a1,a1,1
 108:	0785                	addi	a5,a5,1
 10a:	fff5c703          	lbu	a4,-1(a1)
 10e:	fee78fa3          	sb	a4,-1(a5)
 112:	fb75                	bnez	a4,106 <strcpy+0x8>
    ;
  return os;
}
 114:	6422                	ld	s0,8(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret

000000000000011a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e422                	sd	s0,8(sp)
 11e:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 120:	00054783          	lbu	a5,0(a0)
 124:	cb91                	beqz	a5,138 <strcmp+0x1e>
 126:	0005c703          	lbu	a4,0(a1)
 12a:	00f71763          	bne	a4,a5,138 <strcmp+0x1e>
    p++, q++;
 12e:	0505                	addi	a0,a0,1
 130:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 132:	00054783          	lbu	a5,0(a0)
 136:	fbe5                	bnez	a5,126 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 138:	0005c503          	lbu	a0,0(a1)
}
 13c:	40a7853b          	subw	a0,a5,a0
 140:	6422                	ld	s0,8(sp)
 142:	0141                	addi	sp,sp,16
 144:	8082                	ret

0000000000000146 <strlen>:

uint
strlen(const char *s)
{
 146:	1141                	addi	sp,sp,-16
 148:	e422                	sd	s0,8(sp)
 14a:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 14c:	00054783          	lbu	a5,0(a0)
 150:	cf91                	beqz	a5,16c <strlen+0x26>
 152:	0505                	addi	a0,a0,1
 154:	87aa                	mv	a5,a0
 156:	86be                	mv	a3,a5
 158:	0785                	addi	a5,a5,1
 15a:	fff7c703          	lbu	a4,-1(a5)
 15e:	ff65                	bnez	a4,156 <strlen+0x10>
 160:	40a6853b          	subw	a0,a3,a0
 164:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 166:	6422                	ld	s0,8(sp)
 168:	0141                	addi	sp,sp,16
 16a:	8082                	ret
  for (n = 0; s[n]; n++)
 16c:	4501                	li	a0,0
 16e:	bfe5                	j	166 <strlen+0x20>

0000000000000170 <memset>:

void *
memset(void *dst, int c, uint n)
{
 170:	1141                	addi	sp,sp,-16
 172:	e422                	sd	s0,8(sp)
 174:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 176:	ca19                	beqz	a2,18c <memset+0x1c>
 178:	87aa                	mv	a5,a0
 17a:	1602                	slli	a2,a2,0x20
 17c:	9201                	srli	a2,a2,0x20
 17e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 182:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 186:	0785                	addi	a5,a5,1
 188:	fee79de3          	bne	a5,a4,182 <memset+0x12>
  }
  return dst;
}
 18c:	6422                	ld	s0,8(sp)
 18e:	0141                	addi	sp,sp,16
 190:	8082                	ret

0000000000000192 <strchr>:

char *
strchr(const char *s, char c)
{
 192:	1141                	addi	sp,sp,-16
 194:	e422                	sd	s0,8(sp)
 196:	0800                	addi	s0,sp,16
  for (; *s; s++)
 198:	00054783          	lbu	a5,0(a0)
 19c:	cb99                	beqz	a5,1b2 <strchr+0x20>
    if (*s == c)
 19e:	00f58763          	beq	a1,a5,1ac <strchr+0x1a>
  for (; *s; s++)
 1a2:	0505                	addi	a0,a0,1
 1a4:	00054783          	lbu	a5,0(a0)
 1a8:	fbfd                	bnez	a5,19e <strchr+0xc>
      return (char *)s;
  return 0;
 1aa:	4501                	li	a0,0
}
 1ac:	6422                	ld	s0,8(sp)
 1ae:	0141                	addi	sp,sp,16
 1b0:	8082                	ret
  return 0;
 1b2:	4501                	li	a0,0
 1b4:	bfe5                	j	1ac <strchr+0x1a>

00000000000001b6 <gets>:

char *
gets(char *buf, int max)
{
 1b6:	711d                	addi	sp,sp,-96
 1b8:	ec86                	sd	ra,88(sp)
 1ba:	e8a2                	sd	s0,80(sp)
 1bc:	e4a6                	sd	s1,72(sp)
 1be:	e0ca                	sd	s2,64(sp)
 1c0:	fc4e                	sd	s3,56(sp)
 1c2:	f852                	sd	s4,48(sp)
 1c4:	f456                	sd	s5,40(sp)
 1c6:	f05a                	sd	s6,32(sp)
 1c8:	ec5e                	sd	s7,24(sp)
 1ca:	1080                	addi	s0,sp,96
 1cc:	8baa                	mv	s7,a0
 1ce:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 1d0:	892a                	mv	s2,a0
 1d2:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
 1d4:	4aa9                	li	s5,10
 1d6:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
 1d8:	89a6                	mv	s3,s1
 1da:	2485                	addiw	s1,s1,1
 1dc:	0344d663          	bge	s1,s4,208 <gets+0x52>
    cc = read(0, &c, 1);
 1e0:	4605                	li	a2,1
 1e2:	faf40593          	addi	a1,s0,-81
 1e6:	4501                	li	a0,0
 1e8:	1b2000ef          	jal	39a <read>
    if (cc < 1)
 1ec:	00a05e63          	blez	a0,208 <gets+0x52>
    buf[i++] = c;
 1f0:	faf44783          	lbu	a5,-81(s0)
 1f4:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 1f8:	01578763          	beq	a5,s5,206 <gets+0x50>
 1fc:	0905                	addi	s2,s2,1
 1fe:	fd679de3          	bne	a5,s6,1d8 <gets+0x22>
    buf[i++] = c;
 202:	89a6                	mv	s3,s1
 204:	a011                	j	208 <gets+0x52>
 206:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 208:	99de                	add	s3,s3,s7
 20a:	00098023          	sb	zero,0(s3)
  return buf;
}
 20e:	855e                	mv	a0,s7
 210:	60e6                	ld	ra,88(sp)
 212:	6446                	ld	s0,80(sp)
 214:	64a6                	ld	s1,72(sp)
 216:	6906                	ld	s2,64(sp)
 218:	79e2                	ld	s3,56(sp)
 21a:	7a42                	ld	s4,48(sp)
 21c:	7aa2                	ld	s5,40(sp)
 21e:	7b02                	ld	s6,32(sp)
 220:	6be2                	ld	s7,24(sp)
 222:	6125                	addi	sp,sp,96
 224:	8082                	ret

0000000000000226 <stat>:

int
stat(const char *n, struct stat *st)
{
 226:	1101                	addi	sp,sp,-32
 228:	ec06                	sd	ra,24(sp)
 22a:	e822                	sd	s0,16(sp)
 22c:	e04a                	sd	s2,0(sp)
 22e:	1000                	addi	s0,sp,32
 230:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 232:	4581                	li	a1,0
 234:	18e000ef          	jal	3c2 <open>
  if (fd < 0)
 238:	02054263          	bltz	a0,25c <stat+0x36>
 23c:	e426                	sd	s1,8(sp)
 23e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 240:	85ca                	mv	a1,s2
 242:	198000ef          	jal	3da <fstat>
 246:	892a                	mv	s2,a0
  close(fd);
 248:	8526                	mv	a0,s1
 24a:	160000ef          	jal	3aa <close>
  return r;
 24e:	64a2                	ld	s1,8(sp)
}
 250:	854a                	mv	a0,s2
 252:	60e2                	ld	ra,24(sp)
 254:	6442                	ld	s0,16(sp)
 256:	6902                	ld	s2,0(sp)
 258:	6105                	addi	sp,sp,32
 25a:	8082                	ret
    return -1;
 25c:	597d                	li	s2,-1
 25e:	bfcd                	j	250 <stat+0x2a>

0000000000000260 <atoi>:

int
atoi(const char *s)
{
 260:	1141                	addi	sp,sp,-16
 262:	e422                	sd	s0,8(sp)
 264:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 266:	00054683          	lbu	a3,0(a0)
 26a:	fd06879b          	addiw	a5,a3,-48
 26e:	0ff7f793          	zext.b	a5,a5
 272:	4625                	li	a2,9
 274:	02f66863          	bltu	a2,a5,2a4 <atoi+0x44>
 278:	872a                	mv	a4,a0
  n = 0;
 27a:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 27c:	0705                	addi	a4,a4,1
 27e:	0025179b          	slliw	a5,a0,0x2
 282:	9fa9                	addw	a5,a5,a0
 284:	0017979b          	slliw	a5,a5,0x1
 288:	9fb5                	addw	a5,a5,a3
 28a:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 28e:	00074683          	lbu	a3,0(a4)
 292:	fd06879b          	addiw	a5,a3,-48
 296:	0ff7f793          	zext.b	a5,a5
 29a:	fef671e3          	bgeu	a2,a5,27c <atoi+0x1c>
  return n;
}
 29e:	6422                	ld	s0,8(sp)
 2a0:	0141                	addi	sp,sp,16
 2a2:	8082                	ret
  n = 0;
 2a4:	4501                	li	a0,0
 2a6:	bfe5                	j	29e <atoi+0x3e>

00000000000002a8 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 2a8:	1141                	addi	sp,sp,-16
 2aa:	e422                	sd	s0,8(sp)
 2ac:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2ae:	02b57463          	bgeu	a0,a1,2d6 <memmove+0x2e>
    while (n-- > 0)
 2b2:	00c05f63          	blez	a2,2d0 <memmove+0x28>
 2b6:	1602                	slli	a2,a2,0x20
 2b8:	9201                	srli	a2,a2,0x20
 2ba:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2be:	872a                	mv	a4,a0
      *dst++ = *src++;
 2c0:	0585                	addi	a1,a1,1
 2c2:	0705                	addi	a4,a4,1
 2c4:	fff5c683          	lbu	a3,-1(a1)
 2c8:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 2cc:	fef71ae3          	bne	a4,a5,2c0 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2d0:	6422                	ld	s0,8(sp)
 2d2:	0141                	addi	sp,sp,16
 2d4:	8082                	ret
    dst += n;
 2d6:	00c50733          	add	a4,a0,a2
    src += n;
 2da:	95b2                	add	a1,a1,a2
    while (n-- > 0)
 2dc:	fec05ae3          	blez	a2,2d0 <memmove+0x28>
 2e0:	fff6079b          	addiw	a5,a2,-1
 2e4:	1782                	slli	a5,a5,0x20
 2e6:	9381                	srli	a5,a5,0x20
 2e8:	fff7c793          	not	a5,a5
 2ec:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2ee:	15fd                	addi	a1,a1,-1
 2f0:	177d                	addi	a4,a4,-1
 2f2:	0005c683          	lbu	a3,0(a1)
 2f6:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 2fa:	fee79ae3          	bne	a5,a4,2ee <memmove+0x46>
 2fe:	bfc9                	j	2d0 <memmove+0x28>

0000000000000300 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 300:	1141                	addi	sp,sp,-16
 302:	e422                	sd	s0,8(sp)
 304:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 306:	ca05                	beqz	a2,336 <memcmp+0x36>
 308:	fff6069b          	addiw	a3,a2,-1
 30c:	1682                	slli	a3,a3,0x20
 30e:	9281                	srli	a3,a3,0x20
 310:	0685                	addi	a3,a3,1
 312:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 314:	00054783          	lbu	a5,0(a0)
 318:	0005c703          	lbu	a4,0(a1)
 31c:	00e79863          	bne	a5,a4,32c <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 320:	0505                	addi	a0,a0,1
    p2++;
 322:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 324:	fed518e3          	bne	a0,a3,314 <memcmp+0x14>
  }
  return 0;
 328:	4501                	li	a0,0
 32a:	a019                	j	330 <memcmp+0x30>
      return *p1 - *p2;
 32c:	40e7853b          	subw	a0,a5,a4
}
 330:	6422                	ld	s0,8(sp)
 332:	0141                	addi	sp,sp,16
 334:	8082                	ret
  return 0;
 336:	4501                	li	a0,0
 338:	bfe5                	j	330 <memcmp+0x30>

000000000000033a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 33a:	1141                	addi	sp,sp,-16
 33c:	e406                	sd	ra,8(sp)
 33e:	e022                	sd	s0,0(sp)
 340:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 342:	f67ff0ef          	jal	2a8 <memmove>
}
 346:	60a2                	ld	ra,8(sp)
 348:	6402                	ld	s0,0(sp)
 34a:	0141                	addi	sp,sp,16
 34c:	8082                	ret

000000000000034e <sbrk>:

char *
sbrk(int n)
{
 34e:	1141                	addi	sp,sp,-16
 350:	e406                	sd	ra,8(sp)
 352:	e022                	sd	s0,0(sp)
 354:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 356:	4585                	li	a1,1
 358:	0b2000ef          	jal	40a <sys_sbrk>
}
 35c:	60a2                	ld	ra,8(sp)
 35e:	6402                	ld	s0,0(sp)
 360:	0141                	addi	sp,sp,16
 362:	8082                	ret

0000000000000364 <sbrklazy>:

char *
sbrklazy(int n)
{
 364:	1141                	addi	sp,sp,-16
 366:	e406                	sd	ra,8(sp)
 368:	e022                	sd	s0,0(sp)
 36a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 36c:	4589                	li	a1,2
 36e:	09c000ef          	jal	40a <sys_sbrk>
}
 372:	60a2                	ld	ra,8(sp)
 374:	6402                	ld	s0,0(sp)
 376:	0141                	addi	sp,sp,16
 378:	8082                	ret

000000000000037a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 37a:	4885                	li	a7,1
 ecall
 37c:	00000073          	ecall
 ret
 380:	8082                	ret

0000000000000382 <exit>:
.global exit
exit:
 li a7, SYS_exit
 382:	4889                	li	a7,2
 ecall
 384:	00000073          	ecall
 ret
 388:	8082                	ret

000000000000038a <wait>:
.global wait
wait:
 li a7, SYS_wait
 38a:	488d                	li	a7,3
 ecall
 38c:	00000073          	ecall
 ret
 390:	8082                	ret

0000000000000392 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 392:	4891                	li	a7,4
 ecall
 394:	00000073          	ecall
 ret
 398:	8082                	ret

000000000000039a <read>:
.global read
read:
 li a7, SYS_read
 39a:	4895                	li	a7,5
 ecall
 39c:	00000073          	ecall
 ret
 3a0:	8082                	ret

00000000000003a2 <write>:
.global write
write:
 li a7, SYS_write
 3a2:	48c1                	li	a7,16
 ecall
 3a4:	00000073          	ecall
 ret
 3a8:	8082                	ret

00000000000003aa <close>:
.global close
close:
 li a7, SYS_close
 3aa:	48d5                	li	a7,21
 ecall
 3ac:	00000073          	ecall
 ret
 3b0:	8082                	ret

00000000000003b2 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3b2:	4899                	li	a7,6
 ecall
 3b4:	00000073          	ecall
 ret
 3b8:	8082                	ret

00000000000003ba <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ba:	489d                	li	a7,7
 ecall
 3bc:	00000073          	ecall
 ret
 3c0:	8082                	ret

00000000000003c2 <open>:
.global open
open:
 li a7, SYS_open
 3c2:	48bd                	li	a7,15
 ecall
 3c4:	00000073          	ecall
 ret
 3c8:	8082                	ret

00000000000003ca <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3ca:	48c5                	li	a7,17
 ecall
 3cc:	00000073          	ecall
 ret
 3d0:	8082                	ret

00000000000003d2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3d2:	48c9                	li	a7,18
 ecall
 3d4:	00000073          	ecall
 ret
 3d8:	8082                	ret

00000000000003da <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3da:	48a1                	li	a7,8
 ecall
 3dc:	00000073          	ecall
 ret
 3e0:	8082                	ret

00000000000003e2 <link>:
.global link
link:
 li a7, SYS_link
 3e2:	48cd                	li	a7,19
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3ea:	48d1                	li	a7,20
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3f2:	48a5                	li	a7,9
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <dup>:
.global dup
dup:
 li a7, SYS_dup
 3fa:	48a9                	li	a7,10
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 402:	48ad                	li	a7,11
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 40a:	48b1                	li	a7,12
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <pause>:
.global pause
pause:
 li a7, SYS_pause
 412:	48b5                	li	a7,13
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 41a:	48b9                	li	a7,14
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <sync>:
.global sync
sync:
 li a7, SYS_sync
 422:	48d9                	li	a7,22
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <getpinfo>:
.global getpinfo
getpinfo:
 li a7, SYS_getpinfo
 42a:	48dd                	li	a7,23
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <setstride>:
.global setstride
setstride:
 li a7, SYS_setstride
 432:	48e1                	li	a7,24
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 43a:	1101                	addi	sp,sp,-32
 43c:	ec06                	sd	ra,24(sp)
 43e:	e822                	sd	s0,16(sp)
 440:	1000                	addi	s0,sp,32
 442:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 446:	4605                	li	a2,1
 448:	fef40593          	addi	a1,s0,-17
 44c:	f57ff0ef          	jal	3a2 <write>
}
 450:	60e2                	ld	ra,24(sp)
 452:	6442                	ld	s0,16(sp)
 454:	6105                	addi	sp,sp,32
 456:	8082                	ret

0000000000000458 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 458:	715d                	addi	sp,sp,-80
 45a:	e486                	sd	ra,72(sp)
 45c:	e0a2                	sd	s0,64(sp)
 45e:	f84a                	sd	s2,48(sp)
 460:	0880                	addi	s0,sp,80
 462:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 464:	c299                	beqz	a3,46a <printint+0x12>
 466:	0805c363          	bltz	a1,4ec <printint+0x94>
  neg = 0;
 46a:	4881                	li	a7,0
 46c:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 470:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
 472:	00000517          	auipc	a0,0x0
 476:	52650513          	addi	a0,a0,1318 # 998 <digits>
 47a:	883e                	mv	a6,a5
 47c:	2785                	addiw	a5,a5,1
 47e:	02c5f733          	remu	a4,a1,a2
 482:	972a                	add	a4,a4,a0
 484:	00074703          	lbu	a4,0(a4)
 488:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
 48c:	872e                	mv	a4,a1
 48e:	02c5d5b3          	divu	a1,a1,a2
 492:	0685                	addi	a3,a3,1
 494:	fec773e3          	bgeu	a4,a2,47a <printint+0x22>
  if (neg)
 498:	00088b63          	beqz	a7,4ae <printint+0x56>
    buf[i++] = '-';
 49c:	fd078793          	addi	a5,a5,-48
 4a0:	97a2                	add	a5,a5,s0
 4a2:	02d00713          	li	a4,45
 4a6:	fee78423          	sb	a4,-24(a5)
 4aa:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
 4ae:	02f05a63          	blez	a5,4e2 <printint+0x8a>
 4b2:	fc26                	sd	s1,56(sp)
 4b4:	f44e                	sd	s3,40(sp)
 4b6:	fb840713          	addi	a4,s0,-72
 4ba:	00f704b3          	add	s1,a4,a5
 4be:	fff70993          	addi	s3,a4,-1
 4c2:	99be                	add	s3,s3,a5
 4c4:	37fd                	addiw	a5,a5,-1
 4c6:	1782                	slli	a5,a5,0x20
 4c8:	9381                	srli	a5,a5,0x20
 4ca:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 4ce:	fff4c583          	lbu	a1,-1(s1)
 4d2:	854a                	mv	a0,s2
 4d4:	f67ff0ef          	jal	43a <putc>
  while (--i >= 0)
 4d8:	14fd                	addi	s1,s1,-1
 4da:	ff349ae3          	bne	s1,s3,4ce <printint+0x76>
 4de:	74e2                	ld	s1,56(sp)
 4e0:	79a2                	ld	s3,40(sp)
}
 4e2:	60a6                	ld	ra,72(sp)
 4e4:	6406                	ld	s0,64(sp)
 4e6:	7942                	ld	s2,48(sp)
 4e8:	6161                	addi	sp,sp,80
 4ea:	8082                	ret
    x = -xx;
 4ec:	40b005b3          	neg	a1,a1
    neg = 1;
 4f0:	4885                	li	a7,1
    x = -xx;
 4f2:	bfad                	j	46c <printint+0x14>

00000000000004f4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4f4:	711d                	addi	sp,sp,-96
 4f6:	ec86                	sd	ra,88(sp)
 4f8:	e8a2                	sd	s0,80(sp)
 4fa:	e0ca                	sd	s2,64(sp)
 4fc:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 4fe:	0005c903          	lbu	s2,0(a1)
 502:	28090663          	beqz	s2,78e <vprintf+0x29a>
 506:	e4a6                	sd	s1,72(sp)
 508:	fc4e                	sd	s3,56(sp)
 50a:	f852                	sd	s4,48(sp)
 50c:	f456                	sd	s5,40(sp)
 50e:	f05a                	sd	s6,32(sp)
 510:	ec5e                	sd	s7,24(sp)
 512:	e862                	sd	s8,16(sp)
 514:	e466                	sd	s9,8(sp)
 516:	8b2a                	mv	s6,a0
 518:	8a2e                	mv	s4,a1
 51a:	8bb2                	mv	s7,a2
  state = 0;
 51c:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 51e:	4481                	li	s1,0
 520:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 522:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 526:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 52a:	06c00c93          	li	s9,108
 52e:	a005                	j	54e <vprintf+0x5a>
        putc(fd, c0);
 530:	85ca                	mv	a1,s2
 532:	855a                	mv	a0,s6
 534:	f07ff0ef          	jal	43a <putc>
 538:	a019                	j	53e <vprintf+0x4a>
    } else if (state == '%') {
 53a:	03598263          	beq	s3,s5,55e <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
 53e:	2485                	addiw	s1,s1,1
 540:	8726                	mv	a4,s1
 542:	009a07b3          	add	a5,s4,s1
 546:	0007c903          	lbu	s2,0(a5)
 54a:	22090a63          	beqz	s2,77e <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 54e:	0009079b          	sext.w	a5,s2
    if (state == 0) {
 552:	fe0994e3          	bnez	s3,53a <vprintf+0x46>
      if (c0 == '%') {
 556:	fd579de3          	bne	a5,s5,530 <vprintf+0x3c>
        state = '%';
 55a:	89be                	mv	s3,a5
 55c:	b7cd                	j	53e <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
 55e:	00ea06b3          	add	a3,s4,a4
 562:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 566:	8636                	mv	a2,a3
      if (c1)
 568:	c681                	beqz	a3,570 <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
 56a:	9752                	add	a4,a4,s4
 56c:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
 570:	05878363          	beq	a5,s8,5b6 <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
 574:	05978d63          	beq	a5,s9,5ce <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 578:	07500713          	li	a4,117
 57c:	0ee78763          	beq	a5,a4,66a <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 580:	07800713          	li	a4,120
 584:	12e78963          	beq	a5,a4,6b6 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 588:	07000713          	li	a4,112
 58c:	14e78e63          	beq	a5,a4,6e8 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 590:	06300713          	li	a4,99
 594:	18e78e63          	beq	a5,a4,730 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 598:	07300713          	li	a4,115
 59c:	1ae78463          	beq	a5,a4,744 <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 5a0:	02500713          	li	a4,37
 5a4:	04e79563          	bne	a5,a4,5ee <vprintf+0xfa>
        putc(fd, '%');
 5a8:	02500593          	li	a1,37
 5ac:	855a                	mv	a0,s6
 5ae:	e8dff0ef          	jal	43a <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5b2:	4981                	li	s3,0
 5b4:	b769                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 5b6:	008b8913          	addi	s2,s7,8
 5ba:	4685                	li	a3,1
 5bc:	4629                	li	a2,10
 5be:	000ba583          	lw	a1,0(s7)
 5c2:	855a                	mv	a0,s6
 5c4:	e95ff0ef          	jal	458 <printint>
 5c8:	8bca                	mv	s7,s2
      state = 0;
 5ca:	4981                	li	s3,0
 5cc:	bf8d                	j	53e <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
 5ce:	06400793          	li	a5,100
 5d2:	02f68963          	beq	a3,a5,604 <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 5d6:	06c00793          	li	a5,108
 5da:	04f68263          	beq	a3,a5,61e <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
 5de:	07500793          	li	a5,117
 5e2:	0af68063          	beq	a3,a5,682 <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
 5e6:	07800793          	li	a5,120
 5ea:	0ef68263          	beq	a3,a5,6ce <vprintf+0x1da>
        putc(fd, '%');
 5ee:	02500593          	li	a1,37
 5f2:	855a                	mv	a0,s6
 5f4:	e47ff0ef          	jal	43a <putc>
        putc(fd, c0);
 5f8:	85ca                	mv	a1,s2
 5fa:	855a                	mv	a0,s6
 5fc:	e3fff0ef          	jal	43a <putc>
      state = 0;
 600:	4981                	li	s3,0
 602:	bf35                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 604:	008b8913          	addi	s2,s7,8
 608:	4685                	li	a3,1
 60a:	4629                	li	a2,10
 60c:	000bb583          	ld	a1,0(s7)
 610:	855a                	mv	a0,s6
 612:	e47ff0ef          	jal	458 <printint>
        i += 1;
 616:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 618:	8bca                	mv	s7,s2
      state = 0;
 61a:	4981                	li	s3,0
        i += 1;
 61c:	b70d                	j	53e <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 61e:	06400793          	li	a5,100
 622:	02f60763          	beq	a2,a5,650 <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 626:	07500793          	li	a5,117
 62a:	06f60963          	beq	a2,a5,69c <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 62e:	07800793          	li	a5,120
 632:	faf61ee3          	bne	a2,a5,5ee <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 636:	008b8913          	addi	s2,s7,8
 63a:	4681                	li	a3,0
 63c:	4641                	li	a2,16
 63e:	000bb583          	ld	a1,0(s7)
 642:	855a                	mv	a0,s6
 644:	e15ff0ef          	jal	458 <printint>
        i += 2;
 648:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 64a:	8bca                	mv	s7,s2
      state = 0;
 64c:	4981                	li	s3,0
        i += 2;
 64e:	bdc5                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 650:	008b8913          	addi	s2,s7,8
 654:	4685                	li	a3,1
 656:	4629                	li	a2,10
 658:	000bb583          	ld	a1,0(s7)
 65c:	855a                	mv	a0,s6
 65e:	dfbff0ef          	jal	458 <printint>
        i += 2;
 662:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 664:	8bca                	mv	s7,s2
      state = 0;
 666:	4981                	li	s3,0
        i += 2;
 668:	bdd9                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 66a:	008b8913          	addi	s2,s7,8
 66e:	4681                	li	a3,0
 670:	4629                	li	a2,10
 672:	000be583          	lwu	a1,0(s7)
 676:	855a                	mv	a0,s6
 678:	de1ff0ef          	jal	458 <printint>
 67c:	8bca                	mv	s7,s2
      state = 0;
 67e:	4981                	li	s3,0
 680:	bd7d                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 682:	008b8913          	addi	s2,s7,8
 686:	4681                	li	a3,0
 688:	4629                	li	a2,10
 68a:	000bb583          	ld	a1,0(s7)
 68e:	855a                	mv	a0,s6
 690:	dc9ff0ef          	jal	458 <printint>
        i += 1;
 694:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 696:	8bca                	mv	s7,s2
      state = 0;
 698:	4981                	li	s3,0
        i += 1;
 69a:	b555                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 69c:	008b8913          	addi	s2,s7,8
 6a0:	4681                	li	a3,0
 6a2:	4629                	li	a2,10
 6a4:	000bb583          	ld	a1,0(s7)
 6a8:	855a                	mv	a0,s6
 6aa:	dafff0ef          	jal	458 <printint>
        i += 2;
 6ae:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6b0:	8bca                	mv	s7,s2
      state = 0;
 6b2:	4981                	li	s3,0
        i += 2;
 6b4:	b569                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6b6:	008b8913          	addi	s2,s7,8
 6ba:	4681                	li	a3,0
 6bc:	4641                	li	a2,16
 6be:	000be583          	lwu	a1,0(s7)
 6c2:	855a                	mv	a0,s6
 6c4:	d95ff0ef          	jal	458 <printint>
 6c8:	8bca                	mv	s7,s2
      state = 0;
 6ca:	4981                	li	s3,0
 6cc:	bd8d                	j	53e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ce:	008b8913          	addi	s2,s7,8
 6d2:	4681                	li	a3,0
 6d4:	4641                	li	a2,16
 6d6:	000bb583          	ld	a1,0(s7)
 6da:	855a                	mv	a0,s6
 6dc:	d7dff0ef          	jal	458 <printint>
        i += 1;
 6e0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6e2:	8bca                	mv	s7,s2
      state = 0;
 6e4:	4981                	li	s3,0
        i += 1;
 6e6:	bda1                	j	53e <vprintf+0x4a>
 6e8:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 6ea:	008b8d13          	addi	s10,s7,8
 6ee:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6f2:	03000593          	li	a1,48
 6f6:	855a                	mv	a0,s6
 6f8:	d43ff0ef          	jal	43a <putc>
  putc(fd, 'x');
 6fc:	07800593          	li	a1,120
 700:	855a                	mv	a0,s6
 702:	d39ff0ef          	jal	43a <putc>
 706:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 708:	00000b97          	auipc	s7,0x0
 70c:	290b8b93          	addi	s7,s7,656 # 998 <digits>
 710:	03c9d793          	srli	a5,s3,0x3c
 714:	97de                	add	a5,a5,s7
 716:	0007c583          	lbu	a1,0(a5)
 71a:	855a                	mv	a0,s6
 71c:	d1fff0ef          	jal	43a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 720:	0992                	slli	s3,s3,0x4
 722:	397d                	addiw	s2,s2,-1
 724:	fe0916e3          	bnez	s2,710 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 728:	8bea                	mv	s7,s10
      state = 0;
 72a:	4981                	li	s3,0
 72c:	6d02                	ld	s10,0(sp)
 72e:	bd01                	j	53e <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 730:	008b8913          	addi	s2,s7,8
 734:	000bc583          	lbu	a1,0(s7)
 738:	855a                	mv	a0,s6
 73a:	d01ff0ef          	jal	43a <putc>
 73e:	8bca                	mv	s7,s2
      state = 0;
 740:	4981                	li	s3,0
 742:	bbf5                	j	53e <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
 744:	008b8993          	addi	s3,s7,8
 748:	000bb903          	ld	s2,0(s7)
 74c:	00090f63          	beqz	s2,76a <vprintf+0x276>
        for (; *s; s++)
 750:	00094583          	lbu	a1,0(s2)
 754:	c195                	beqz	a1,778 <vprintf+0x284>
          putc(fd, *s);
 756:	855a                	mv	a0,s6
 758:	ce3ff0ef          	jal	43a <putc>
        for (; *s; s++)
 75c:	0905                	addi	s2,s2,1
 75e:	00094583          	lbu	a1,0(s2)
 762:	f9f5                	bnez	a1,756 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 764:	8bce                	mv	s7,s3
      state = 0;
 766:	4981                	li	s3,0
 768:	bbd9                	j	53e <vprintf+0x4a>
          s = "(null)";
 76a:	00000917          	auipc	s2,0x0
 76e:	22690913          	addi	s2,s2,550 # 990 <malloc+0x11a>
        for (; *s; s++)
 772:	02800593          	li	a1,40
 776:	b7c5                	j	756 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 778:	8bce                	mv	s7,s3
      state = 0;
 77a:	4981                	li	s3,0
 77c:	b3c9                	j	53e <vprintf+0x4a>
 77e:	64a6                	ld	s1,72(sp)
 780:	79e2                	ld	s3,56(sp)
 782:	7a42                	ld	s4,48(sp)
 784:	7aa2                	ld	s5,40(sp)
 786:	7b02                	ld	s6,32(sp)
 788:	6be2                	ld	s7,24(sp)
 78a:	6c42                	ld	s8,16(sp)
 78c:	6ca2                	ld	s9,8(sp)
    }
  }
}
 78e:	60e6                	ld	ra,88(sp)
 790:	6446                	ld	s0,80(sp)
 792:	6906                	ld	s2,64(sp)
 794:	6125                	addi	sp,sp,96
 796:	8082                	ret

0000000000000798 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 798:	715d                	addi	sp,sp,-80
 79a:	ec06                	sd	ra,24(sp)
 79c:	e822                	sd	s0,16(sp)
 79e:	1000                	addi	s0,sp,32
 7a0:	e010                	sd	a2,0(s0)
 7a2:	e414                	sd	a3,8(s0)
 7a4:	e818                	sd	a4,16(s0)
 7a6:	ec1c                	sd	a5,24(s0)
 7a8:	03043023          	sd	a6,32(s0)
 7ac:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7b0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7b4:	8622                	mv	a2,s0
 7b6:	d3fff0ef          	jal	4f4 <vprintf>
}
 7ba:	60e2                	ld	ra,24(sp)
 7bc:	6442                	ld	s0,16(sp)
 7be:	6161                	addi	sp,sp,80
 7c0:	8082                	ret

00000000000007c2 <printf>:

void
printf(const char *fmt, ...)
{
 7c2:	711d                	addi	sp,sp,-96
 7c4:	ec06                	sd	ra,24(sp)
 7c6:	e822                	sd	s0,16(sp)
 7c8:	1000                	addi	s0,sp,32
 7ca:	e40c                	sd	a1,8(s0)
 7cc:	e810                	sd	a2,16(s0)
 7ce:	ec14                	sd	a3,24(s0)
 7d0:	f018                	sd	a4,32(s0)
 7d2:	f41c                	sd	a5,40(s0)
 7d4:	03043823          	sd	a6,48(s0)
 7d8:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7dc:	00840613          	addi	a2,s0,8
 7e0:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7e4:	85aa                	mv	a1,a0
 7e6:	4505                	li	a0,1
 7e8:	d0dff0ef          	jal	4f4 <vprintf>
}
 7ec:	60e2                	ld	ra,24(sp)
 7ee:	6442                	ld	s0,16(sp)
 7f0:	6125                	addi	sp,sp,96
 7f2:	8082                	ret

00000000000007f4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7f4:	1141                	addi	sp,sp,-16
 7f6:	e422                	sd	s0,8(sp)
 7f8:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 7fa:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7fe:	00001797          	auipc	a5,0x1
 802:	8027b783          	ld	a5,-2046(a5) # 1000 <freep>
 806:	a02d                	j	830 <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
 808:	4618                	lw	a4,8(a2)
 80a:	9f2d                	addw	a4,a4,a1
 80c:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 810:	6398                	ld	a4,0(a5)
 812:	6310                	ld	a2,0(a4)
 814:	a83d                	j	852 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
 816:	ff852703          	lw	a4,-8(a0)
 81a:	9f31                	addw	a4,a4,a2
 81c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 81e:	ff053683          	ld	a3,-16(a0)
 822:	a091                	j	866 <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 824:	6398                	ld	a4,0(a5)
 826:	00e7e463          	bltu	a5,a4,82e <free+0x3a>
 82a:	00e6ea63          	bltu	a3,a4,83e <free+0x4a>
{
 82e:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 830:	fed7fae3          	bgeu	a5,a3,824 <free+0x30>
 834:	6398                	ld	a4,0(a5)
 836:	00e6e463          	bltu	a3,a4,83e <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 83a:	fee7eae3          	bltu	a5,a4,82e <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
 83e:	ff852583          	lw	a1,-8(a0)
 842:	6390                	ld	a2,0(a5)
 844:	02059813          	slli	a6,a1,0x20
 848:	01c85713          	srli	a4,a6,0x1c
 84c:	9736                	add	a4,a4,a3
 84e:	fae60de3          	beq	a2,a4,808 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 852:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
 856:	4790                	lw	a2,8(a5)
 858:	02061593          	slli	a1,a2,0x20
 85c:	01c5d713          	srli	a4,a1,0x1c
 860:	973e                	add	a4,a4,a5
 862:	fae68ae3          	beq	a3,a4,816 <free+0x22>
    p->s.ptr = bp->s.ptr;
 866:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 868:	00000717          	auipc	a4,0x0
 86c:	78f73c23          	sd	a5,1944(a4) # 1000 <freep>
}
 870:	6422                	ld	s0,8(sp)
 872:	0141                	addi	sp,sp,16
 874:	8082                	ret

0000000000000876 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 876:	7139                	addi	sp,sp,-64
 878:	fc06                	sd	ra,56(sp)
 87a:	f822                	sd	s0,48(sp)
 87c:	f426                	sd	s1,40(sp)
 87e:	ec4e                	sd	s3,24(sp)
 880:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 882:	02051493          	slli	s1,a0,0x20
 886:	9081                	srli	s1,s1,0x20
 888:	04bd                	addi	s1,s1,15
 88a:	8091                	srli	s1,s1,0x4
 88c:	0014899b          	addiw	s3,s1,1
 890:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
 892:	00000517          	auipc	a0,0x0
 896:	76e53503          	ld	a0,1902(a0) # 1000 <freep>
 89a:	c915                	beqz	a0,8ce <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 89c:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 89e:	4798                	lw	a4,8(a5)
 8a0:	08977a63          	bgeu	a4,s1,934 <malloc+0xbe>
 8a4:	f04a                	sd	s2,32(sp)
 8a6:	e852                	sd	s4,16(sp)
 8a8:	e456                	sd	s5,8(sp)
 8aa:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 8ac:	8a4e                	mv	s4,s3
 8ae:	0009871b          	sext.w	a4,s3
 8b2:	6685                	lui	a3,0x1
 8b4:	00d77363          	bgeu	a4,a3,8ba <malloc+0x44>
 8b8:	6a05                	lui	s4,0x1
 8ba:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8be:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 8c2:	00000917          	auipc	s2,0x0
 8c6:	73e90913          	addi	s2,s2,1854 # 1000 <freep>
  if (p == SBRK_ERROR)
 8ca:	5afd                	li	s5,-1
 8cc:	a081                	j	90c <malloc+0x96>
 8ce:	f04a                	sd	s2,32(sp)
 8d0:	e852                	sd	s4,16(sp)
 8d2:	e456                	sd	s5,8(sp)
 8d4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8d6:	00000797          	auipc	a5,0x0
 8da:	73a78793          	addi	a5,a5,1850 # 1010 <base>
 8de:	00000717          	auipc	a4,0x0
 8e2:	72f73123          	sd	a5,1826(a4) # 1000 <freep>
 8e6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8e8:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 8ec:	b7c1                	j	8ac <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 8ee:	6398                	ld	a4,0(a5)
 8f0:	e118                	sd	a4,0(a0)
 8f2:	a8a9                	j	94c <malloc+0xd6>
  hp->s.size = nu;
 8f4:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 8f8:	0541                	addi	a0,a0,16
 8fa:	efbff0ef          	jal	7f4 <free>
  return freep;
 8fe:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
 902:	c12d                	beqz	a0,964 <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 904:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 906:	4798                	lw	a4,8(a5)
 908:	02977263          	bgeu	a4,s1,92c <malloc+0xb6>
    if (p == freep)
 90c:	00093703          	ld	a4,0(s2)
 910:	853e                	mv	a0,a5
 912:	fef719e3          	bne	a4,a5,904 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 916:	8552                	mv	a0,s4
 918:	a37ff0ef          	jal	34e <sbrk>
  if (p == SBRK_ERROR)
 91c:	fd551ce3          	bne	a0,s5,8f4 <malloc+0x7e>
        return 0;
 920:	4501                	li	a0,0
 922:	7902                	ld	s2,32(sp)
 924:	6a42                	ld	s4,16(sp)
 926:	6aa2                	ld	s5,8(sp)
 928:	6b02                	ld	s6,0(sp)
 92a:	a03d                	j	958 <malloc+0xe2>
 92c:	7902                	ld	s2,32(sp)
 92e:	6a42                	ld	s4,16(sp)
 930:	6aa2                	ld	s5,8(sp)
 932:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 934:	fae48de3          	beq	s1,a4,8ee <malloc+0x78>
        p->s.size -= nunits;
 938:	4137073b          	subw	a4,a4,s3
 93c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 93e:	02071693          	slli	a3,a4,0x20
 942:	01c6d713          	srli	a4,a3,0x1c
 946:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 948:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 94c:	00000717          	auipc	a4,0x0
 950:	6aa73a23          	sd	a0,1716(a4) # 1000 <freep>
      return (void *)(p + 1);
 954:	01078513          	addi	a0,a5,16
  }
}
 958:	70e2                	ld	ra,56(sp)
 95a:	7442                	ld	s0,48(sp)
 95c:	74a2                	ld	s1,40(sp)
 95e:	69e2                	ld	s3,24(sp)
 960:	6121                	addi	sp,sp,64
 962:	8082                	ret
 964:	7902                	ld	s2,32(sp)
 966:	6a42                	ld	s4,16(sp)
 968:	6aa2                	ld	s5,8(sp)
 96a:	6b02                	ld	s6,0(sp)
 96c:	b7f5                	j	958 <malloc+0xe2>
